import { describe, expect, it } from "vitest";
import { Chess } from "chess.js";
import { classifyMove, isSacrifice, type PositionEval } from "@/lib/chess/classify";
import type { EngineLine, Score } from "@/lib/chess/types";
import { bookPlies } from "@/lib/chess/openings";
import { buildReview } from "@/lib/review/buildReview";
import { parsePgn } from "@/lib/chess/pgn";
import { see } from "@/lib/chess/material";
import { explainMove } from "@/lib/chess/coach";

function line(multipv: number, score: Score, pv: string[]): EngineLine {
  return { multipv, depth: 18, score, pv };
}

/** Play `uci` from `fen`; return the move and the resulting position. */
function play(fen: string, uci: string) {
  const c = new Chess(fen);
  const move = c.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), promotion: uci[4] });
  return { move, fenAfter: c.fen() };
}

function classify(opts: {
  fen: string;
  played: string;
  before: EngineLine[];
  after: EngineLine[];
  inBook?: boolean;
  prev?: Parameters<typeof classifyMove>[0]["prevClassification"];
  prevMoverWinPct?: number;
}) {
  const { move, fenAfter } = play(opts.fen, opts.played);
  const before: PositionEval = { fen: opts.fen, lines: opts.before };
  const c = new Chess(fenAfter);
  const after: PositionEval = { fen: fenAfter, lines: opts.after, terminal: c.isCheckmate() ? "checkmate" : undefined };
  return { ...classifyMove({ before, after, move, inBook: !!opts.inBook, prevClassification: opts.prev, prevMoverWinPct: opts.prevMoverWinPct }), move, before, after };
}

const START = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
// Italian-ish middlegame position used for the plain EPL buckets. White to move.
const MID = "r1bqkb1r/pppp1ppp/2n2n2/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R w KQkq - 4 4";

describe("classification rules", () => {
  it("Book: 1.e4 is in the opening database", () => {
    const r = classify({
      fen: START,
      played: "e2e4",
      before: [line(1, { cp: 30 }, ["e2e4"]), line(2, { cp: 25 }, ["d2d4"])],
      after: [line(1, { cp: -30 }, ["e7e5"])],
      inBook: true,
    });
    expect(r.classification).toBe("book");
    const { fenAfter } = play(START, "e2e4");
    expect(bookPlies([fenAfter])).toBe(1);
  });

  it("Brilliant: the Greek gift Bxh7+ (real Stockfish 17.1 evals, depth 18)", () => {
    // 1.e4 e6 2.d4 d5 3.e5 Nd7 4.Nf3 Be7 5.Bd3 O-O 6.h4?! ... Bxh7+! is the engine's top move.
    const fen = "rnbq1rk1/pppnbppp/4p3/3pP3/3P3P/3B1N2/PPP2PP1/RNBQK2R w KQ - 1 7";
    expect(isSacrifice(fen, { from: "d3", to: "h7" })).toBe(true);
    const r = classify({
      fen,
      played: "d3h7",
      before: [
        line(1, { cp: 449 }, "d3h7 g8h8 f3g5 d7e5 d4e5 g7g6 g5f7 f8f7".split(" ")),
        line(2, { cp: 191 }, "f3g5 h7h6 g5h7 f7f5 h7f8 d7f8".split(" ")),
      ],
      after: [
        line(1, { cp: -549 }, "g8h7 f3g5 h7h6 d1d3 f7f5 e5f6 g7g6".split(" ")),
        line(2, { cp: -550 }, "g8h8 f3g5 g7g6 h7g6 f7g6".split(" ")),
      ],
    });
    expect(r.winBefore).toBeLessThan(90);
    expect(r.winAfter).toBeGreaterThanOrEqual(50);
    expect(r.classification).toBe("brilliant");
  });

  it("not Brilliant when the player was already completely winning", () => {
    const fen = "rnbq1rk1/pppnbppp/4p3/3pP3/3P3P/3B1N2/PPP2PP1/RNBQK2R w KQ - 1 7";
    const r = classify({
      fen,
      played: "d3h7",
      before: [line(1, { cp: 900 }, ["d3h7"]), line(2, { cp: 850 }, ["f3g5"])],
      after: [line(1, { cp: -900 }, ["g8h7"])],
    });
    expect(r.classification).not.toBe("brilliant");
  });

  it("Great: the only good move (second best is ≥ 0.10 EPL worse)", () => {
    // 1.e4 d5 2.exd5 — Black must recapture; in this test line the alternative is much worse.
    const fen = "rnbqkbnr/ppp1pppp/8/3P4/8/8/PPPP1PPP/RNBQKBNR b KQkq - 0 2";
    const r = classify({
      fen,
      played: "d8d5",
      before: [line(1, { cp: -40 }, ["d8d5", "b1c3"]), line(2, { cp: -200 }, ["c7c6", "d5c6"])],
      after: [line(1, { cp: 40 }, ["b1c3"])],
    });
    expect(r.classification).toBe("great");
  });

  it("Great: turns an equal position into a winning one", () => {
    const fen = "rnb1kbnr/pppp1ppp/8/4p3/4P2q/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3";
    const r = classify({
      fen,
      played: "f3h4",
      before: [line(1, { cp: 900 }, ["f3h4"]), line(2, { cp: 860 }, ["b1c3"])],
      after: [line(1, { cp: -900 }, ["d7d5"])],
      prevMoverWinPct: 50,
    });
    expect(r.classification).toBe("great");
  });

  it("Best: matches the engine's top move", () => {
    const r = classify({
      fen: MID,
      played: "d2d3",
      before: [line(1, { cp: 30 }, ["d2d3"]), line(2, { cp: 25 }, ["b1c3"])],
      after: [line(1, { cp: -30 }, ["f8c5"])],
    });
    expect(r.classification).toBe("best");
  });

  it("Excellent: EPL ≤ 0.02", () => {
    const r = classify({
      fen: MID,
      played: "b1c3",
      before: [line(1, { cp: 0 }, ["d2d3"]), line(2, { cp: -5 }, ["b1c3"])],
      after: [line(1, { cp: 10 }, ["f8c5"])],
    });
    expect(r.epl).toBeGreaterThan(0.002);
    expect(r.epl).toBeLessThanOrEqual(0.02);
    expect(r.classification).toBe("excellent");
  });

  it("Good: EPL ≤ 0.05", () => {
    const r = classify({
      fen: MID,
      played: "h2h3",
      before: [line(1, { cp: 0 }, ["d2d3"]), line(2, { cp: -5 }, ["b1c3"])],
      after: [line(1, { cp: 40 }, ["d7d5"])],
    });
    expect(r.epl).toBeGreaterThan(0.02);
    expect(r.classification).toBe("good");
  });

  it("Inaccuracy: EPL ≤ 0.10", () => {
    const r = classify({
      fen: MID,
      played: "a2a3",
      before: [line(1, { cp: 0 }, ["d2d3"]), line(2, { cp: -5 }, ["b1c3"])],
      after: [line(1, { cp: 80 }, ["d7d5"])],
    });
    expect(r.classification).toBe("inaccuracy");
  });

  it("Mistake: EPL ≤ 0.20", () => {
    const r = classify({
      fen: MID,
      played: "c4f7",
      before: [line(1, { cp: 0 }, ["d2d3"]), line(2, { cp: -5 }, ["b1c3"])],
      after: [line(1, { cp: 180 }, ["e8f7"])],
    });
    expect(r.epl).toBeGreaterThan(0.1);
    expect(r.classification).toBe("mistake");
  });

  it("Blunder: EPL > 0.20", () => {
    const r = classify({
      fen: MID,
      played: "f3g5",
      before: [line(1, { cp: 0 }, ["d2d3"]), line(2, { cp: -5 }, ["b1c3"])],
      after: [line(1, { cp: 400 }, ["d8g5"])],
    });
    expect(r.epl).toBeGreaterThan(0.2);
    expect(r.classification).toBe("blunder");
  });

  it("Miss: fails to punish the opponent's blunder", () => {
    // 1.e4 e5 2.Nf3 Qh4?? — White should take the queen but plays Nc3.
    const fen = "rnb1kbnr/pppp1ppp/8/4p3/4P2q/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3";
    const r = classify({
      fen,
      played: "b1c3",
      before: [line(1, { cp: 900 }, ["f3h4"]), line(2, { cp: 60 }, ["b1c3"])],
      after: [line(1, { cp: -60 }, ["h4e7"])],
      prev: "blunder",
    });
    expect(r.classification).toBe("miss");
  });

  it("Forced: the only legal move", () => {
    const fen = "k7/8/8/8/8/8/1r6/K7 w - - 0 1";
    expect(new Chess(fen).moves()).toEqual(["Kxb2"]);
    const r = classify({
      fen,
      played: "a1b2",
      before: [line(1, { cp: 0 }, ["a1b2"])],
      after: [line(1, { cp: 0 }, ["a8b7"])],
    });
    expect(r.classification).toBe("forced");
  });

  it("checkmate is classified with full win after the move", () => {
    // Fool's mate: 1.f3 e5 2.g4 Qh4#
    const fen = "rnbqkbnr/pppp1ppp/8/4p3/6P1/5P2/PPPPP2P/RNBQKBNR b KQkq - 0 2";
    const r = classify({ fen, played: "d8h4", before: [line(1, { mate: 1 }, ["d8h4"])], after: [] });
    expect(r.winAfter).toBe(100);
    expect(["best", "great"]).toContain(r.classification);
  });
});

describe("static exchange evaluation", () => {
  it("a pawn defended by a pawn is not won by a knight", () => {
    // Knight on f3 can take e5, defended by d6 pawn.
    const fen = "4k3/8/3p4/4p3/8/5N2/8/4K3 w - - 0 1";
    expect(see(new Chess(fen), "e5", "w")).toBe(0);
  });
  it("an undefended piece is won outright", () => {
    const fen = "4k3/8/8/4n3/8/5N2/8/4K3 w - - 0 1";
    expect(see(new Chess(fen), "e5", "w")).toBe(3);
  });
});

describe("buildReview", () => {
  it("marks opening moves as Book and computes per-side accuracy", () => {
    const pgn = "1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 Nf6 5. O-O Be7 6. Re1 b5";
    const g = parsePgn(pgn);
    const fens = [g.startFen, ...g.fens];
    const positions: PositionEval[] = fens.map((fen, i) => ({
      fen,
      lines: [line(1, { cp: 0 }, g.moves[i] ? [`${g.moves[i].from}${g.moves[i].to}`] : ["a2a3"])],
    }));
    const review = buildReview({ startFen: g.startFen, moves: g.moves, positions, depth: 18 });
    expect(review.moves[0].classification).toBe("book");
    expect(review.moves.filter((m) => m.classification === "book").length).toBeGreaterThanOrEqual(10);
    expect(review.opening?.eco).toMatch(/^C\d\d$/);
    expect(review.accuracy.w).toBeGreaterThan(90);
    expect(review.moves[0].coach).toMatch(/book/i);
  });

  it("skips Book detection for custom-FEN games", () => {
    const g = parsePgn('[FEN "4k3/8/8/8/8/8/4P3/4K3 w - - 0 1"]\n\n1. e4 Kd7 2. e5 Ke6 *');
    const positions: PositionEval[] = [g.startFen, ...g.fens].map((fen) => ({ fen, lines: [line(1, { cp: 100 }, ["e1d2"])] }));
    const review = buildReview({ startFen: g.startFen, moves: g.moves, positions, depth: 12, customStart: true });
    expect(review.bookSkipped).toBe(true);
    expect(review.moves.some((m) => m.classification === "book")).toBe(false);
  });
});

describe("coach explanations", () => {
  it("explains a hung piece", () => {
    // 4.Nxe5?? grabs a pawn but the knight is simply taken by ...Nxe5.
    const fen = MID;
    const { move, fenAfter } = play(fen, "f3e5");
    const out = explainMove({
      classification: "blunder",
      san: move.san,
      before: { fen, lines: [line(1, { cp: 30 }, ["d2d3"])] },
      after: { fen: fenAfter, lines: [line(1, { cp: 250 }, ["c6e5", "d2d4"])] },
      move,
    });
    expect(out.text).toMatch(/hangs a knight on e5/);
    expect(out.text).toMatch(/best move was d3/);
  });
  it("explains a missed mate", () => {
    const fen = "6k1/5ppp/8/8/8/8/5PPP/R5K1 w - - 0 1";
    const { move, fenAfter } = play(fen, "g1f1");
    const out = explainMove({
      classification: "blunder",
      san: move.san,
      before: { fen, lines: [line(1, { mate: 1 }, ["a1a8"])] },
      after: { fen: fenAfter, lines: [line(1, { cp: -500 }, ["g8f8"])] },
      move,
    });
    expect(out.text).toMatch(/misses mate in 1/);
    expect(out.bestSan).toBe("Ra8#");
  });
});
