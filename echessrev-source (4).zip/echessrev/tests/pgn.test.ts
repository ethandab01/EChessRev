import { describe, expect, it } from "vitest";
import { ChessParseError, buildPgn, parseFen, parseMultiPgn, parsePgn, splitPgnGames } from "@/lib/chess/pgn";

describe("PGN parsing", () => {
  it("parses a header-less PGN", () => {
    const g = parsePgn("1. e4 e5 2. Nf3 Nc6 3. Bb5 *");
    expect(g.moves.map((m) => m.san)).toEqual(["e4", "e5", "Nf3", "Nc6", "Bb5"]);
    expect(g.customStart).toBe(false);
  });
  it("strips comments, variations, NAGs and annotations", () => {
    const g = parsePgn(
      '[Event "Test"]\n[Result "1-0"]\n\n1. e4 {best by test} e5 (1... c5 2. Nf3 (2. c3)) 2. Nf3!? $1 Nc6?! ; line comment\n3. Bb5 1-0',
    );
    expect(g.moves.map((m) => m.san)).toEqual(["e4", "e5", "Nf3", "Nc6", "Bb5"]);
    expect(g.headers.Event).toBe("Test");
    expect(g.result).toBe("1-0");
  });
  it("handles castling with zeros, promotions and compact move numbers", () => {
    const g = parsePgn('[FEN "4k3/1P6/8/8/8/8/8/4K2R w K - 0 1"]\n\n1.0-0 Kd7 2.b8=N+ *');
    expect(g.moves.map((m) => m.san)).toEqual(["O-O", "Kd7", "b8=N+"]);
    expect(g.moves[2].promotion).toBe("n");
    expect(g.customStart).toBe(true);
  });
  it("reports which move is illegal and why", () => {
    expect(() => parsePgn("1. e4 e5 2. Nf3 Nc6 3. Bb6")).toThrowError(/Move 3\. Bb6 \(White\): "Bb6" is illegal/);
    expect(() => parsePgn("1. e4 e5 2. Ke3")).toThrowError(/Move 2\. Ke3/);
    expect(() => parsePgn("1. e4 Nf9")).toThrowError(/Move 1\.\.\. Nf9 \(Black\): "Nf9" is not valid move notation/);
  });
  it("reports an illegal move while in check", () => {
    // 1.e4 e5 2.Qh5 Nc6 3.Qxf7+ — Black is in check; 3...Nf6 does not resolve it.
    expect(() => parsePgn("1. e4 e5 2. Qh5 Nc6 3. Qxf7+ Nf6")).toThrowError(/does not resolve the check/);
  });
  it("rejects empty and move-less PGNs", () => {
    expect(() => parsePgn("   ")).toThrowError(ChessParseError);
    expect(() => parsePgn('[Event "x"]')).toThrowError(/no moves/);
  });
  it("reports an invalid [FEN] header", () => {
    expect(() => parsePgn('[FEN "8/8/8/8 w - - 0 1"]\n\n1. e4')).toThrowError(/\[FEN .*header is invalid.*8 ranks/);
  });
  it("splits multiple games, with and without headers", () => {
    const text = '[Event "A"]\n\n1. e4 e5 1-0\n\n[Event "B"]\n\n1. d4 d5 0-1\n';
    expect(splitPgnGames(text)).toHaveLength(2);
    const parsed = parseMultiPgn("1. e4 e5 1-0\n1. d4 d5 2. Bxh7 0-1\n1. c4 *");
    expect(parsed).toHaveLength(3);
    expect(parsed[0].game).toBeDefined();
    expect(parsed[1].error).toMatch(/Move 2\. Bxh7/);
  });
  it("round-trips through buildPgn", () => {
    const g = parsePgn("1. e4 e5 2. Nf3 Nc6 *");
    const out = buildPgn({ moves: g.moves, result: "*", headers: { White: "Me", Black: "Bot" } });
    expect(out).toContain('[White "Me"]');
    expect(parsePgn(out).moves).toHaveLength(4);
  });
  it("writes FEN headers and black-first move numbers", () => {
    const fen = "4k3/8/8/8/8/8/4P3/4K3 b - - 0 12";
    const out = buildPgn({ moves: [{ san: "Kd7" }, { san: "e4" }], startFen: fen });
    expect(out).toContain('[FEN "4k3/8/8/8/8/8/4P3/4K3 b - - 0 12"]');
    expect(out).toContain("12... Kd7 13. e4");
  });
});

describe("FEN parsing", () => {
  it("accepts a valid FEN and a 4-field EPD", () => {
    expect(parseFen("rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1")).toContain(" b ");
    expect(parseFen("4k3/8/8/8/8/8/8/4K3 w - -")).toBe("4k3/8/8/8/8/8/8/4K3 w - - 0 1");
  });
  it("names the failing field", () => {
    expect(() => parseFen("4k3/8/8/8/8/8/8/4K3 w - - 0")).toThrowError(/6 space-separated fields/);
    expect(() => parseFen("4k3/8/8/8/8/8/8 w - - 0 1")).toThrowError(/field 1 .*8 ranks.*found 7/);
    expect(() => parseFen("4k3/8/8/8/8/8/8/4K4 w - - 0 1")).toThrowError(/rank 1 .*9 squares/);
    expect(() => parseFen("4k3/8/8/8/8/8/8/4X3 w - - 0 1")).toThrowError(/invalid character "X" in rank 1/);
    expect(() => parseFen("4k3/8/8/8/8/8/8/4K3 x - - 0 1")).toThrowError(/field 2 \(active color\)/);
    expect(() => parseFen("4k3/8/8/8/8/8/8/4K3 w KX - 0 1")).toThrowError(/field 3 \(castling/);
    expect(() => parseFen("4k3/8/8/8/8/8/8/4K3 w - e4 0 1")).toThrowError(/field 4 \(en passant/);
    expect(() => parseFen("4k3/8/8/8/8/8/8/4K3 w - - x 1")).toThrowError(/field 5 \(halfmove/);
    expect(() => parseFen("4k3/8/8/8/8/8/8/4K3 w - - 0 0")).toThrowError(/field 6 \(fullmove/);
  });
  it("rejects missing kings, pawns on back ranks, and the wrong side in check", () => {
    expect(() => parseFen("8/8/8/8/8/8/8/4K3 w - - 0 1")).toThrowError(/Black must have exactly one king/);
    expect(() => parseFen("P3k3/8/8/8/8/8/8/4K3 w - - 0 1")).toThrowError(/pawns cannot stand/);
    expect(() => parseFen("4k3/8/8/8/8/8/8/R3K3 w - - 0 1")).not.toThrow();
    expect(() => parseFen("4k3/4R3/8/8/8/8/8/4K3 w - - 0 1")).toThrowError(/side not to move \(Black\) is in check/);
  });
});

import { parseLichessGameId } from "@/lib/chess/lichess";

describe("Lichess URL parsing", () => {
  it("extracts the 8-character game id", () => {
    expect(parseLichessGameId("https://lichess.org/q7ZvsdUF")).toBe("q7ZvsdUF");
    expect(parseLichessGameId("https://lichess.org/q7ZvsdUFabcd")).toBe("q7ZvsdUF");
    expect(parseLichessGameId("lichess.org/q7ZvsdUF/black#32")).toBe("q7ZvsdUF");
    expect(parseLichessGameId("https://lichess.org/game/export/q7ZvsdUF")).toBe("q7ZvsdUF");
    expect(parseLichessGameId("q7ZvsdUF")).toBe("q7ZvsdUF");
  });
  it("rejects other hosts and malformed ids", () => {
    expect(parseLichessGameId("https://example.com/q7ZvsdUF")).toBeNull();
    expect(parseLichessGameId("https://lichess.org/@/someone")).toBeNull();
    expect(parseLichessGameId("not a url")).toBeNull();
  });
});
