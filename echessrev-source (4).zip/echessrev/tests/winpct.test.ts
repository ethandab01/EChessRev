import { describe, expect, it } from "vitest";
import { expectedPointsLoss, formatScore, scoreToWhiteCp, scoreToWinPct, winPct } from "@/lib/chess/winpct";

describe("winPct", () => {
  it("is 50 at equality", () => {
    expect(winPct(0)).toBeCloseTo(50, 10);
  });
  it("matches the formula 50 + 50 * (2 / (1 + exp(-0.00368208 * cp)) - 1)", () => {
    for (const cp of [-900, -250, -37, 12, 100, 333, 1500]) {
      expect(winPct(cp)).toBeCloseTo(50 + 50 * (2 / (1 + Math.exp(-0.00368208 * cp)) - 1), 10);
    }
    expect(winPct(100)).toBeCloseTo(59.1, 1);
    expect(winPct(-300)).toBeCloseTo(24.9, 1);
  });
  it("is symmetric and monotonic", () => {
    expect(winPct(200) + winPct(-200)).toBeCloseTo(100, 10);
    expect(winPct(201)).toBeGreaterThan(winPct(200));
  });
  it("maps mate scores to 100 / 0", () => {
    expect(scoreToWinPct({ mate: 3 })).toBe(100);
    expect(scoreToWinPct({ mate: -2 })).toBe(0);
    expect(scoreToWinPct({ mate: 0 })).toBe(0);
    expect(scoreToWinPct({ cp: 0 })).toBe(50);
  });
});

describe("expected points loss", () => {
  it("is (before - after) / 100", () => {
    expect(expectedPointsLoss(60, 45)).toBeCloseTo(0.15, 10);
  });
  it("is never negative", () => {
    expect(expectedPointsLoss(40, 55)).toBe(0);
  });
  it("is 1 for throwing away a forced mate into getting mated", () => {
    expect(expectedPointsLoss(scoreToWinPct({ mate: 2 }), 100 - scoreToWinPct({ mate: 1 }))).toBe(1);
  });
});

describe("score formatting", () => {
  it("formats from White's perspective", () => {
    expect(formatScore({ cp: 125 }, "w")).toBe("+1.25");
    expect(formatScore({ cp: 125 }, "b")).toBe("-1.25");
    expect(formatScore({ mate: 3 }, "b")).toBe("-M3");
    expect(formatScore({ mate: 0 }, "w")).toBe("0-1");
  });
  it("converts to white cp", () => {
    expect(scoreToWhiteCp({ cp: 40 }, "b")).toBe(-40);
    expect(scoreToWhiteCp({ mate: 2 }, "w")).toBe(9998);
    expect(scoreToWhiteCp({ mate: 0 }, "w")).toBe(-10000);
  });
});
