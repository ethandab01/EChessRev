import { describe, expect, it } from "vitest";
import { estimatePerformance, estimateRating, gameAccuracy, harmonicMean, moveAccuracy, ratingFromAcpl, weightedMean } from "@/lib/chess/accuracy";

describe("move accuracy", () => {
  it("is ~100 when no win% is lost", () => {
    expect(moveAccuracy(55, 55)).toBeCloseTo(99.9999, 3);
    expect(moveAccuracy(40, 70)).toBeCloseTo(99.9999, 3);
  });
  it("follows 103.1668 * exp(-0.04354 * diff) - 3.1669", () => {
    expect(moveAccuracy(60, 50)).toBeCloseTo(103.1668 * Math.exp(-0.4354) - 3.1669, 8);
    expect(moveAccuracy(60, 50)).toBeCloseTo(63.58, 1);
  });
  it("is clamped to 0", () => {
    expect(moveAccuracy(100, 0)).toBe(0);
  });
});

describe("means", () => {
  it("harmonic mean", () => {
    expect(harmonicMean([50, 100])).toBeCloseTo(66.667, 2);
  });
  it("weighted mean", () => {
    expect(weightedMean([[100, 1], [0, 3]])).toBe(25);
  });
});

describe("game accuracy (Lichess method)", () => {
  it("is 100 for both sides when the evaluation never changes", () => {
    const a = gameAccuracy(Array(21).fill(50));
    expect(a.white).toBeCloseTo(100, 2);
    expect(a.black).toBeCloseTo(100, 2);
    expect(a.moves).toHaveLength(20);
  });
  it("penalises the side that drops win%", () => {
    // White blunders on ply 3 (index 2): 50 → 20; Black plays perfectly.
    const w = [50, 50, 50, 20, 20, 20, 20, 20, 20, 20, 20];
    const a = gameAccuracy(w);
    expect(a.black).toBeCloseTo(100, 2);
    expect(a.white).toBeLessThan(80);
    expect(a.moves[2]).toBeCloseTo(moveAccuracy(50, 20), 8);
  });
  it("is the average of the harmonic and volatility-weighted means", () => {
    const w = [50, 52, 45, 47, 30, 31, 33, 60, 58, 58, 40, 41];
    const a = gameAccuracy(w);
    const whiteMoves = a.moves.filter((_, i) => i % 2 === 0);
    const h = harmonicMean(whiteMoves);
    expect(a.white).toBeGreaterThanOrEqual(Math.min(h, ...whiteMoves) - 1e-9);
    expect(a.white).toBeLessThanOrEqual(100);
  });
  it("handles games that start with Black to move", () => {
    const a = gameAccuracy([50, 50, 10], "b");
    expect(a.black).toBeCloseTo(100, 2);
    expect(a.white).toBeLessThan(50);
  });
  it("handles very short games", () => {
    const a = gameAccuracy([50, 48]);
    expect(a.white).toBeGreaterThan(90);
    expect(a.black).toBe(0);
  });
});

describe("estimated rating", () => {
  it("accuracy table is monotonic and conservative", () => {
    expect(estimateRating(0)).toBe(100);
    expect(estimateRating(100)).toBe(2900);
    expect(estimateRating(80)).toBe(1400);
    let prev = 0;
    for (let a = 0; a <= 100; a += 2.5) {
      const r = estimateRating(a);
      expect(r).toBeGreaterThanOrEqual(prev);
      prev = r;
    }
  });
  it("maps ACPL to rating", () => {
    expect(ratingFromAcpl(20)).toBeCloseTo(2538, -1);
    expect(ratingFromAcpl(60)).toBeCloseTo(1701, -1);
    expect(ratingFromAcpl(0)).toBe(3000);
  });
  it("does not overshoot on short games", () => {
    // 6 accurate moves (the old estimate called this ~2450).
    const short = estimatePerformance({ accuracy: 93.3, acpl: 12, moves: 6 });
    expect(short).toBeLessThan(1900);
    // The same quality sustained over 40 moves earns a much higher estimate.
    const long = estimatePerformance({ accuracy: 93.3, acpl: 12, moves: 40 });
    expect(long).toBeGreaterThan(short);
    expect(long).toBeLessThanOrEqual(2600);
  });
  it("rates a sloppy game low", () => {
    expect(estimatePerformance({ accuracy: 62, acpl: 110, moves: 30 })).toBeLessThan(1000);
  });
});
