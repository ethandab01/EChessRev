import { describe, expect, it } from "vitest";
import { botAcceptsDraw, botStrength, mistakeChance, pickWeakMove, thinkDelayMs, timeBudgetMs } from "@/lib/chess/botMove";
import { botForElo, clampElo, getBot } from "@/lib/chess/bots";
import { resultPoints, reviewBonus } from "@/lib/chess/points";
import { hasMatingMaterial } from "@/lib/chess/material";
import { Chess } from "chess.js";

describe("Elo bots", () => {
  it("builds a bot for any Elo on the slider", () => {
    expect(clampElo(1234)).toBe(1250);
    expect(clampElo(100)).toBe(400);
    expect(clampElo(9999)).toBe(3200);
    expect(botForElo(1500)).toMatchObject({ id: "elo-1500", elo: 1500, name: "Club Bot" });
    expect(botForElo(3200).name).toBe("Max");
    expect(getBot("elo-1800")?.elo).toBe(1800);
    expect(getBot("elo-1801")).toBeUndefined();
    expect(getBot("elo-5000")).toBeUndefined();
    expect(getBot("bruno")?.elo).toBe(1200); // legacy saved games still resolve
  });
  it("maps Elo to engine strength", () => {
    expect(botStrength(1400)).toEqual({ mode: "limit", elo: 1400 });
    expect(botStrength(2800)).toEqual({ mode: "limit", elo: 2800 });
    expect(botStrength(3200)).toEqual({ mode: "full" });
    const weak = botStrength(400);
    expect(weak.mode).toBe("weak");
    if (weak.mode === "weak") {
      expect(weak.depth).toBe(1);
      expect(weak.multipv).toBe(5);
    }
    const w1200 = botStrength(1200);
    if (w1200.mode === "weak") expect(w1200.depth).toBe(4);
  });
  it("mistake chance is ~25% at 400 falling to ~5% at 1200", () => {
    expect(mistakeChance(400)).toBeCloseTo(0.25);
    expect(mistakeChance(800)).toBeCloseTo(0.15);
    expect(mistakeChance(1200)).toBeCloseTo(0.05);
  });
  it("weak bots sometimes play clearly inferior moves", () => {
    const lines = [
      { multipv: 1, depth: 2, score: { cp: 300 }, pv: ["e2e4"] },
      { multipv: 2, depth: 2, score: { cp: 280 }, pv: ["d2d4"] },
      { multipv: 3, depth: 2, score: { cp: -200 }, pv: ["g2g4"] },
    ];
    const legal = ["e2e4", "d2d4", "g2g4", "a2a3"];
    expect(pickWeakMove(lines, legal, { mistakeChance: 0.25, temperature: 8 }, () => 0.1)).toEqual({ move: "g2g4", deliberateMistake: true });
    const normal = pickWeakMove(lines, legal, { mistakeChance: 0.25, temperature: 8 }, () => 0.5);
    expect(["e2e4", "d2d4"]).toContain(normal.move);
  });
  it("thinking delay is 0.4–2.0 s unlimited and shrinks with low clocks", () => {
    const fen = new Chess().fen();
    for (const r of [0, 0.5, 0.99]) {
      const d = thinkDelayMs(fen, {}, () => r);
      expect(d).toBeGreaterThanOrEqual(400);
      expect(d).toBeLessThanOrEqual(2000);
    }
    expect(thinkDelayMs(fen, { remainingMs: 3000 }, () => 0.5)).toBeLessThan(400);
    expect(timeBudgetMs(60000, 0)).toBeCloseTo(60000 / 35);
  });
  it("accepts draws only when equal after move 30", () => {
    expect(botAcceptsDraw(30, null, 31)).toBe(true);
    expect(botAcceptsDraw(30, null, 30)).toBe(false);
    expect(botAcceptsDraw(-51, null, 40)).toBe(false);
    expect(botAcceptsDraw(null, 3, 40)).toBe(false);
  });
  it("detects mating material for timeout-vs-insufficient-material draws", () => {
    expect(hasMatingMaterial(new Chess("4k3/8/8/8/8/8/8/4KN2 w - - 0 1"), "w")).toBe(false);
    expect(hasMatingMaterial(new Chess("4k3/8/8/8/8/8/8/4KNN1 w - - 0 1"), "w")).toBe(true);
    expect(hasMatingMaterial(new Chess("4k3/8/8/8/8/8/4P3/4K3 w - - 0 1"), "w")).toBe(true);
  });
});

import { detectGameEnd, timeoutResult } from "@/lib/chess/gameEnd";

describe("game end rules", () => {
  it("detects checkmate, stalemate and insufficient material", () => {
    const mate = new Chess();
    for (const m of ["f3", "e5", "g4", "Qh4#"]) mate.move(m);
    expect(detectGameEnd(mate)).toEqual({ result: "0-1", termination: "checkmate" });
    expect(detectGameEnd(new Chess("7k/5Q2/6K1/8/8/8/8/8 b - - 0 1"))?.termination).toBe("stalemate");
    expect(detectGameEnd(new Chess("7k/8/6K1/8/8/8/8/8 b - - 0 1"))?.termination).toBe("insufficient");
  });
  it("detects threefold repetition and the 50-move rule", () => {
    const c = new Chess();
    for (const m of ["Nf3", "Nf6", "Ng1", "Ng8", "Nf3", "Nf6", "Ng1", "Ng8"]) c.move(m);
    expect(detectGameEnd(c)?.termination).toBe("threefold");
    expect(detectGameEnd(new Chess("7k/8/6K1/8/8/8/8/R7 w - - 100 80"))?.termination).toBe("fifty-move");
  });
  it("timeout vs insufficient material is a draw", () => {
    expect(timeoutResult(new Chess("7k/8/6K1/8/8/8/8/R7 w - - 0 1"), "b")).toEqual({ result: "1-0", termination: "timeout" });
    expect(timeoutResult(new Chess("7k/8/6K1/8/8/8/8/N7 w - - 0 1"), "b")).toEqual({ result: "1/2-1/2", termination: "timeout-insufficient" });
  });
});

describe("points", () => {
  it("rewards wins against stronger bots more", () => {
    expect(resultPoints("win", 400)).toBe(40);
    expect(resultPoints("win", 2000)).toBe(200);
    expect(resultPoints("win", 3200)).toBe(320);
    expect(resultPoints("draw", 2000)).toBe(100);
    expect(resultPoints("loss", 3200)).toBe(0);
  });
  it("gives review bonuses for Brilliant, Great and Best moves", () => {
    const b = reviewBonus({ brilliant: 1, great: 2, best: 10, blunder: 3 });
    expect(b.total).toBe(25 + 20 + 10);
    expect(b.lines.map((l) => l.c)).toEqual(["brilliant", "great", "best"]);
    expect(reviewBonus({}).total).toBe(0);
  });
});

import { checkPuzzleMove, puzzlePoints, puzzleRatingUpdate, rowToPuzzle } from "@/lib/chess/puzzles";

describe("puzzles", () => {
  // Lichess puzzle 0000D: after ...Rf8? White wins with Qd6 ... (setup move is the first UCI move).
  const p = rowToPuzzle(["0000D", "5rk1/1p3ppp/pq3b2/8/8/1P1Q1N2/P4PPP/3R2K1 w - - 2 27", "d3d6 f8d8 d6d8 f6d8", 1429, "advantage endgame short"]);
  it("checks moves against the solution", () => {
    const c = new Chess(p.fen);
    c.move({ from: "d3", to: "d6" });
    expect(checkPuzzleMove(p, 1, c.fen(), "f8d8")).toBe("correct");
    expect(checkPuzzleMove(p, 1, c.fen(), "b6c7")).toBe("wrong");
    c.move({ from: "f8", to: "d8" });
    c.move({ from: "d6", to: "d8" });
    expect(checkPuzzleMove(p, 3, c.fen(), "f6d8")).toBe("solved");
  });
  it("accepts any checkmating move", () => {
    const mate = rowToPuzzle(["x", "6k1/5ppp/8/8/8/8/5PPP/R5K1 b - - 0 1", "g8h8 a1a8", 600, "mateIn1"]);
    const c = new Chess(mate.fen);
    c.move("Kh8");
    expect(checkPuzzleMove(mate, 1, c.fen(), "a1a8")).toBe("solved");
  });
  it("updates puzzle rating like Elo", () => {
    expect(puzzleRatingUpdate(1200, 1200, true)).toBe(1216);
    expect(puzzleRatingUpdate(1200, 1200, false)).toBe(1184);
    expect(puzzleRatingUpdate(1200, 2000, true)).toBeGreaterThan(1230);
    expect(puzzlePoints(1450, true)).toBe(15);
    expect(puzzlePoints(1450, false)).toBe(0);
  });
});

import { eloDeltas, rankFor } from "@/lib/chess/ranks";

describe("friend ranks", () => {
  it("computes zero-sum Elo deltas", () => {
    expect(eloDeltas(1200, 1200, 1)).toEqual({ white: 16, black: -16 });
    expect(eloDeltas(1200, 1200, 0.5)).toEqual({ white: 0, black: -0 });
    const upset = eloDeltas(1000, 1600, 1);
    expect(upset.white).toBeGreaterThan(28);
    expect(upset.white + upset.black).toBe(0);
  });
  it("maps ratings to rank tiers", () => {
    expect(rankFor(1200).name).toBe("Silver");
    expect(rankFor(900).name).toBe("Bronze");
    expect(rankFor(2100).name).toBe("Champion");
    expect(rankFor(1200).progress).toBeCloseTo(0.5);
  });
});

import { parseTimeControl, speedOf } from "@/lib/chess/bots";

describe("time controls", () => {
  it("parses any minutes+increment", () => {
    expect(parseTimeControl("5+3")).toMatchObject({ initial: 300, increment: 3 });
    expect(parseTimeControl("unlimited")?.initial).toBe(0);
    expect(parseTimeControl("0+3")).toBeNull();
    expect(parseTimeControl("5+99")).toBeNull();
    expect(parseTimeControl("abc")).toBeNull();
  });
  it("classifies speed like Lichess", () => {
    expect(speedOf(parseTimeControl("1+0")!)).toBe("Bullet");
    expect(speedOf(parseTimeControl("2+1")!)).toBe("Bullet");
    expect(speedOf(parseTimeControl("3+2")!)).toBe("Blitz");
    expect(speedOf(parseTimeControl("10+5")!)).toBe("Rapid");
    expect(speedOf(parseTimeControl("30+20")!)).toBe("Classical");
  });
});
