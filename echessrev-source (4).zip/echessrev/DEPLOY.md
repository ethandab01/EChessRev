# Putting EChessREV online with your own domain

This takes about 30–45 minutes the first time. You'll use four free services:

| What | Service | Cost |
| --- | --- | --- |
| Stores your code | **GitHub** | Free |
| Runs the website | **Vercel** | Free (Hobby plan) |
| Database (accounts, games) | **Neon Postgres**, created inside Vercel | Free tier |
| Password-reset emails | **Resend** | Free tier |
| Your domain name | Cloudflare, Porkbun or Namecheap | ~$10–15 / year |

Once it's set up, every time you change the code and push it to GitHub, Vercel updates the live site automatically.

---

## 1. Put the code on GitHub

1. Make a free account at **github.com**.
2. Install **GitHub Desktop** from **desktop.github.com** and sign in.
3. In GitHub Desktop: **File → Add local repository…** and choose your `echessrev` folder
   (the one with `package.json` in it).
   It will say "this directory does not appear to be a Git repository" — click **create a repository**, then **Create Repository**.
4. Click **Publish repository**. Leave **Keep this code private** ticked. Click **Publish**.

Your `.env` file and `node_modules` folder are **not** uploaded (they're in `.gitignore`), which is what you want.

---

## 2. Create the site on Vercel

1. Go to **vercel.com** → **Sign Up** → **Continue with GitHub**.
2. Click **Add New… → Project**, find `echessrev` and click **Import**.
3. **Don't click Deploy yet.** Open **Build and Output Settings**, turn on the override for **Build Command** and enter:

   ```
   npm run vercel-build
   ```

4. Open **Environment Variables** and add these:

   | Name | Value |
   | --- | --- |
   | `DATABASE_PROVIDER` | `postgresql` |
   | `AUTH_SECRET` | a long random string (see below) |

   To make a random secret, paste this into PowerShell and copy the output:

   ```powershell
   [Convert]::ToBase64String((1..32 | ForEach-Object { [byte](Get-Random -Maximum 256) }))
   ```

5. Click **Deploy**. **The first deploy will fail** with a database error — that's expected, because there's no database yet. Continue to step 3.

---

## 3. Add the database

1. In your Vercel project, open the **Storage** tab → **Create Database** → choose **Neon** (Serverless Postgres) → accept the defaults → **Create**.
2. When it asks which project to connect, pick `echessrev` and keep all environments ticked → **Connect**.

   This automatically adds `DATABASE_URL` and `DATABASE_URL_UNPOOLED` to your project's environment variables.
3. Go to the **Deployments** tab, click the **⋯** next to the failed deployment → **Redeploy**.

When it finishes, click **Visit**. Your site is live at an address like `echessrev-yourname.vercel.app`. Sign up and try it out.

> The build command creates and updates the database tables automatically on every deploy, so you never have to run database commands yourself.

---

## 4. Connect your own domain

1. **Buy a domain.** Cloudflare Registrar, Porkbun and Namecheap are all good and cheap. Pick a name like `echessrev.com`.
2. In Vercel: your project → **Settings → Domains** → type your domain (e.g. `echessrev.com`) → **Add**. Choose the recommended option that also adds `www.echessrev.com`.
3. Vercel now shows the DNS records you need — usually:
   - an **A** record for `@` pointing to an IP address Vercel gives you, and
   - a **CNAME** record for `www` pointing to a `vercel-dns` address.

   **Use exactly the values Vercel shows you.**
4. Log in to where you bought the domain, open its **DNS** settings, and add those two records. (Delete any old "parking" A or CNAME records for `@` and `www` if they exist.)
   - On **Cloudflare**, set the records to **DNS only** (grey cloud), not proxied.
5. Back in Vercel, wait until the domain shows **Valid Configuration** — usually a few minutes, occasionally up to a few hours. HTTPS (the padlock) is set up for you automatically.
6. Add one more environment variable in **Settings → Environment Variables**:

   | Name | Value |
   | --- | --- |
   | `APP_URL` | `https://echessrev.com` (your domain) |

   Then **Redeploy** (Deployments → ⋯ → Redeploy) so password-reset links use your domain.

---

## 5. Turn on password-reset emails

Without this step everything works except "Forgot password?" emails.

1. Make a free account at **resend.com**.
2. **Domains → Add Domain** → enter your domain. Resend shows a few DNS records (TXT/MX, for SPF and DKIM).
3. Add those records at your domain registrar's DNS page, the same place as step 4. Click **Verify** in Resend once they're in (can take a few minutes).
4. **API Keys → Create API Key** (sending access is enough) and copy it.
5. In Vercel → **Settings → Environment Variables**, add:

   | Name | Value |
   | --- | --- |
   | `RESEND_API_KEY` | the key from Resend |
   | `EMAIL_FROM` | `EChessREV <noreply@echessrev.com>` (use your domain) |

6. **Redeploy**. Test it: log out → **Log in → Forgot password?**

---

## 6. (Optional) "Continue with Google"

1. Go to **console.cloud.google.com** → create a project → **APIs & Services → OAuth consent screen** (External, fill in the app name and your email).
2. **Credentials → Create Credentials → OAuth client ID** → *Web application*.
   - Authorized redirect URI: `https://echessrev.com/api/auth/callback/google`
3. Copy the client ID and secret into Vercel as `AUTH_GOOGLE_ID` and `AUTH_GOOGLE_SECRET`, then redeploy. The Google button appears on the login page automatically.

---

## Updating the live site

Change code on your computer → open GitHub Desktop → write a short summary → **Commit to main** → **Push origin**. Vercel rebuilds and updates the site in a minute or two. If a build fails, the previous version stays live, and the error is shown in the Vercel **Deployments** tab.

## Good to know

- **Free-plan limits.** Live games check for new moves every second, and each check is a request to your Vercel functions. That's fine for you and your friends; if the site gets popular, check Vercel's current Hobby limits (and that the Hobby plan is for non-commercial use) and consider upgrading.
- **Players online** counts browsers that had the site open in the last minute.
- **Rate limits** (sign-in attempts, Lichess imports) are counted per server instance. That's enough to stop casual abuse.
- **Your local copy** keeps using its own SQLite database (`.env` with `DATABASE_PROVIDER="sqlite"`); the live site uses Postgres. They don't share accounts.
- **Backups.** Neon keeps short-term history on the free tier. For anything important, look at Neon's backup/branching options.
