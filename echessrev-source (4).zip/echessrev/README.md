# EChessREV

Play chess against computer bots at any Elo from 400 to 3200, keep a Lichess-style game history, and get a full
move-by-move **Game Review** — Brilliant to Blunder, accuracy, estimated performance, eval graph, coach notes,
retry mode — for any bot game, pasted PGN, uploaded `.pgn`, FEN or Lichess link.

Stockfish 17.1 (single-threaded *lite* WASM build) runs in a Web Worker in the browser, so bots and analysis cost
nothing server-side and no COOP/COEP headers are needed.

## Architecture

```
Browser ─ Next.js App Router pages (React, Tailwind)
   ├─ /play       PlayClient  → StockfishEngine (worker) → botMove.ts (UCI_Elo / weak-bot sampling)
   ├─ /review     ReviewClient → runReview (depth 12–24, MultiPV 2) → buildReview → classify/coach/accuracy
   ├─ /analysis   live engine (MultiPV 3) + ImportPanel (PGN / file / FEN / Lichess URL)
   └─ IndexedDB review cache, localStorage in-progress game, sessionStorage page hand-off
Server ─ Route handlers (Node runtime)
   ├─ Auth.js v5: credentials (bcrypt) + optional Google, JWT sessions, Prisma adapter
   ├─ /api/games, /api/analyses   save games/reviews for signed-in users
   ├─ /api/import/lichess          server-side fetch of lichess.org/game/export/<id> (rate limited)
   └─ Prisma → SQLite (dev) or PostgreSQL (prod), chosen by DATABASE_PROVIDER
Pure logic (unit-tested): src/lib/chess/* — winPct, EPL, SEE, classification, accuracy, PGN/FEN, bots, openings
```

## Requirements

- Node.js 20.9+ (22 recommended), npm 10+
- For production: a PostgreSQL database (Neon, Supabase, Vercel Postgres, RDS…)

## Local setup

```bash
git clone <your-fork-url> echessrev && cd echessrev
cp .env.example .env          # AUTH_SECRET is optional locally; required in production
npm install                   # also generates prisma/schema.prisma, copies the engine, runs prisma generate
npx prisma migrate dev        # creates prisma/dev.db (SQLite)
npm run dev                   # http://localhost:3000
```

`npm install` runs `postinstall`, which:

1. `scripts/select-prisma-schema.mjs` writes `prisma/schema.prisma` from `prisma/schema.base.prisma` using
   `DATABASE_PROVIDER` (`sqlite` or `postgresql`). Prisma can't read the provider from `env()`, so it is templated.
2. `scripts/copy-engine.mjs` copies `stockfish-17.1-lite-single-*.js/.wasm` from `node_modules/stockfish` to
   `public/engine/stockfish.js` and `stockfish.wasm`.
3. `prisma generate`.

Other scripts:

| command | what it does |
| --- | --- |
| `npm test` | Vitest unit tests |
| `npm run typecheck` | `tsc --noEmit` |
| `npm run build` / `npm start` | production build / server |
| `npm run openings:build` | rebuild `src/data/openings.json` from the CC0 [lichess-org/chess-openings](https://github.com/lichess-org/chess-openings) TSVs |
| `npm run db:select` | regenerate `prisma/schema.prisma` after changing `DATABASE_PROVIDER` |

## Deploying (Vercel + Postgres + your own domain)

**Step-by-step guide: [DEPLOY.md](DEPLOY.md)** — GitHub → Vercel → Neon Postgres → custom domain → Resend email.

In short: set the Vercel build command to `npm run vercel-build` (selects the Postgres schema, runs
`prisma db push`, then `next build`) and set `DATABASE_PROVIDER=postgresql`, `DATABASE_URL`
(+ `DATABASE_URL_UNPOOLED` for Neon), `AUTH_SECRET`, `APP_URL`, and optionally `RESEND_API_KEY` /
`EMAIL_FROM` and the Google OAuth variables.

> Migrations: because the provider is switchable, the repo doesn't commit a migration history
> (`prisma/migrations` is git-ignored). Dev uses `prisma migrate dev` against SQLite; production uses
> `prisma db push`.

## Bots, points, puzzles and friends

- **Bots:** pick any strength from 400 to 3200 on the Elo slider (steps of 50). Each rating band has a name
  (Beginner, Novice, Club, Advanced, Expert, Master, Grandmaster, Max) in `TIERS` in `src/lib/chess/bots.ts`.
  Strength is derived from the Elo in `src/lib/chess/botMove.ts`:
  - **3200 (Max)** — full-strength Stockfish.
  - **1320–3199** — `UCI_LimitStrength=true`, `UCI_Elo=<elo>` (capped at Stockfish's 3190).
  - **below 1320** — `Skill Level 0`, depth 1–4, MultiPV 5, weighted random choice, and a deliberate
    clearly-inferior move 25 % of the time at 400 falling to 5 % at 1200.
  - Every bot "thinks" 0.4–2.0 s; with a clock it spends ≈ remaining/35 + 0.8×increment.
- **Points** (signed-in players, `src/lib/chess/points.ts`): a win is worth bot Elo ÷ 10, a draw half that.
  Reviewing a saved game gives a one-time bonus for your own moves: Brilliant +25, Great +10, Best +1.
  Solving a puzzle on the first try gives puzzle rating ÷ 100.
- **Puzzles** (`/puzzles`): 7,348 puzzles from the [Lichess puzzle database](https://database.lichess.org/#puzzles)
  (CC0), bundled in `src/data/puzzles.json` and served only from the server. Your puzzle rating is an Elo
  (K = 32) against each puzzle's rating; the first attempt counts. Any checkmating move is accepted. Rebuild
  from a newer CSV with `node scripts/build-puzzles.mjs path/to/lichess_db_puzzle.csv`.
- **Friends** (`/friends`): send requests by username; friends get public profiles at `/u/<username>`.
- **Friend games** (`/game/<id>`): challenge a friend with a time control, colour and rated/casual. Games are
  played over HTTP polling (1 s), so they work on serverless hosting with no WebSocket server. The server
  validates every move, keeps the clocks (the clock starts after White's first move), handles timeouts, draw
  offers, resignation and aborts (before both players have moved), and applies Elo changes once.
- **Play online** (`/play`): Lichess-style quick-pairing tiles (bullet → classical + custom), a live lobby
  of open games, and a "players online / games in play" counter (browser heartbeats every 25 s). Quick
  pairing joins a matching open seek or creates one; seeks expire if the page stops pinging them. Online
  games share the friend-game engine and rating. Bots live at `/play/computer`.
- **Shop** (`/shop`): spend ◆ on board themes, avatar icons, name flair and win effects
  (`src/lib/shop.ts`). Balance = points earned − points spent; leaderboards use points earned.
- **Accounts:** sign in with email *or* username; "Forgot password?" emails a one-hour reset link
  (token stored hashed) via Resend's HTTP API, or prints it to the server console when no key is set.
- **Ranks:** rated friend and online games update a separate live rating (start 1200, K = 32) shown as a rank:
  Bronze < 1100 ≤ Silver < 1300 ≤ Gold < 1500 ≤ Platinum < 1700 ≤ Diamond < 1900 ≤ Champion
  (`src/lib/chess/ranks.ts`).

## How the review works

- Every position is searched at the chosen depth with MultiPV 2. Win% = `50 + 50·(2/(1+e^(−0.00368208·cp)) − 1)`
  from the mover's side; mate = 100/0. Expected-points loss (EPL) = (win% before with best play − win% after) / 100.
- Classification (`src/lib/chess/classify.ts`), in priority order:
  **Forced** (only legal move) → **Book** → **Brilliant** → **Great** → **Best** → **Excellent** (EPL ≤ 0.02) →
  **Good** (≤ 0.05) → **Miss** → **Inaccuracy** (≤ 0.10) → **Mistake** (≤ 0.20) → **Blunder**.
  - *Book*: every ply up to the last position found in the opening DB within the first 30 plies. Skipped for
    custom-FEN games and games shorter than 5 moves.
  - *Brilliant*: best or within 0.02 EPL, gives up ≥ 2 pawn units by static exchange evaluation, win% < 90 before
    and ≥ 50 after.
  - *Great*: best move and the second-best is ≥ 0.10 EPL worse, or it turns a ≤ 50 % position (after the player's
    previous move) into ≥ 70 %.
  - *Miss*: the opponent's previous move was a Mistake/Blunder and this move loses ≥ 0.10 EPL against the punishing line.
  - Forced is checked first (otherwise the only legal move would always be "Best"), and Miss is checked before the
    Inaccuracy/Mistake buckets so that failing to punish an error is reported as a Miss.
- Accuracy: per move `103.1668·e^(−0.04354·Δwin%) − 3.1669` clamped 0–100; per game the mean of the harmonic mean
  and the volatility-weighted mean (Lichess method, window = plies/10 clamped 2–8, weight = std-dev clamped 0.5–12).
- Estimated performance (`estimatePerformance` in `src/lib/chess/accuracy.ts`): the average of an
  accuracy-table estimate and an ACPL estimate (3100·e^(−0.01·ACPL)), shrunk toward 1200 by
  moves/(moves + 10) so short games can't claim master strength. Book and forced moves are excluded.
- Coach notes are templated from engine data plus simple tactical checks (hung pieces via SEE, forks, mates
  missed/allowed, material won, missed wins, promotions) — no external AI.
- Reviews are cached in IndexedDB keyed by moves + depth; for signed-in users bot-game reviews are also stored on
  the game row, and imported games can be saved as "analyses".

## Notes & limits

- The lite engine is weaker than full Stockfish (smaller NNUE) but still far stronger than any human; depth 18
  reviews of a 40-move game take roughly 10–40 s depending on the device.
- When you leave a game, it is stored in `localStorage` (moves + clocks) and offered for resume on `/play`.
  Clocks are paused while you're away.
- Book detection depends on the named positions in the lichess dataset (≈ 3,900 positions).
