"use client";

import { Chessboard } from "react-chessboard";
import type { Arrow, Square as BoardSquare } from "react-chessboard/dist/chessboard/types";
import { Chess, type Square } from "chess.js";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { PromotionDialog } from "./PromotionDialog";
import { ClassificationIcon } from "./ClassificationIcon";
import type { Classification } from "@/lib/chess/types";

export interface BoardArrow {
  from: string;
  to: string;
  color: string;
}

export interface BoardProps {
  fen: string;
  orientation: "white" | "black";
  /** Which side the user may move: a color, "both" (analysis), or null (read-only). */
  movable: "w" | "b" | "both" | null;
  /** Return true if the move was accepted. */
  onMove?: (from: string, to: string, promotion?: "q" | "r" | "b" | "n") => boolean;
  lastMove?: { from: string; to: string } | null;
  arrows?: BoardArrow[];
  badge?: { square: string; classification: Classification } | null;
  /** Show a text input for typing moves (keyboard accessibility). */
  typedMoves?: boolean;
  id?: string;
  /** Rendered to the left of the board at the board's height (e.g. an eval bar). */
  side?: React.ReactNode;
  /** Extra square highlights: square → CSS color. */
  highlights?: Record<string, string>;
}

const FILES = "abcdefgh";

export function Board({ fen, orientation, movable, onMove, lastMove, arrows = [], badge, typedMoves = true, id = "board", side, highlights }: BoardProps) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(480);
  const [selected, setSelected] = useState<Square | null>(null);
  const [pendingPromo, setPendingPromo] = useState<{ from: Square; to: Square } | null>(null);
  const [typed, setTyped] = useState("");
  const [typedError, setTypedError] = useState("");

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const ro = new ResizeObserver(([entry]) => setWidth(Math.max(240, Math.floor(entry.contentRect.width))));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const chess = useMemo(() => {
    try {
      return new Chess(fen);
    } catch {
      return new Chess();
    }
  }, [fen]);

  // Clear selection whenever the position changes.
  useEffect(() => {
    setSelected(null);
    setPendingPromo(null);
  }, [fen]);

  const canMoveColor = useCallback(
    (color: "w" | "b") => movable === "both" ? color === chess.turn() : movable === color && chess.turn() === color,
    [movable, chess],
  );

  const legalTargets = useMemo(() => {
    if (!selected) return [];
    return chess.moves({ square: selected, verbose: true });
  }, [chess, selected]);

  const tryMove = useCallback(
    (from: Square, to: Square): boolean => {
      const piece = chess.get(from);
      if (!piece || !canMoveColor(piece.color)) return false;
      const moves = chess.moves({ square: from, verbose: true }).filter((m) => m.to === to);
      if (moves.length === 0) return false;
      if (moves.some((m) => m.promotion)) {
        setPendingPromo({ from, to });
        return false;
      }
      const ok = onMove?.(from, to) ?? false;
      setSelected(null);
      return ok;
    },
    [chess, canMoveColor, onMove],
  );

  const onSquareClick = (square: BoardSquare) => {
    const sq = square as Square;
    const piece = chess.get(sq);
    if (selected) {
      if (selected === sq) return setSelected(null);
      if (legalTargets.some((m) => m.to === sq)) {
        tryMove(selected, sq);
        return;
      }
    }
    if (piece && canMoveColor(piece.color)) setSelected(sq);
    else setSelected(null);
  };

  const squareStyles = useMemo(() => {
    const s: Record<string, React.CSSProperties> = {};
    if (lastMove) {
      s[lastMove.from] = { backgroundColor: "rgba(235, 200, 80, 0.45)" };
      s[lastMove.to] = { backgroundColor: "rgba(235, 200, 80, 0.6)" };
    }
    if (chess.inCheck()) {
      const king = chess.board().flat().find((p) => p && p.type === "k" && p.color === chess.turn());
      if (king) s[king.square] = { ...s[king.square], backgroundImage: "radial-gradient(circle, rgba(230,40,40,0.95) 0%, rgba(230,40,40,0.55) 45%, rgba(230,40,40,0) 75%)" };
    }
    for (const [sq, color] of Object.entries(highlights ?? {})) s[sq] = { ...s[sq], backgroundColor: color };
    if (selected) s[selected] = { ...s[selected], backgroundColor: "rgba(91, 186, 103, 0.55)" };
    for (const m of legalTargets) {
      const capture = !!chess.get(m.to as Square);
      s[m.to] = {
        ...s[m.to],
        backgroundImage: capture
          ? "radial-gradient(circle, transparent 58%, rgba(20,20,30,0.38) 60%)"
          : "radial-gradient(circle, rgba(20,20,30,0.35) 22%, transparent 24%)",
        cursor: "pointer",
      };
    }
    return s;
  }, [lastMove, chess, selected, legalTargets, highlights]);

  const boardArrows: Arrow[] = arrows
    .filter((a) => a.from && a.to && a.from !== a.to)
    .map((a) => [a.from as BoardSquare, a.to as BoardSquare, a.color]);

  const badgePos = useMemo(() => {
    if (!badge) return null;
    const f = FILES.indexOf(badge.square[0]);
    const r = Number(badge.square[1]);
    const x = orientation === "white" ? f : 7 - f;
    const y = orientation === "white" ? 8 - r : r - 1;
    const sq = width / 8;
    return { left: (x + 1) * sq - sq * 0.36, top: y * sq - sq * 0.12, size: Math.max(16, sq * 0.42) };
  }, [badge, orientation, width]);

  const submitTyped = (e: React.FormEvent) => {
    e.preventDefault();
    const text = typed.trim();
    if (!text) return;
    const probe = new Chess(fen);
    const turn = probe.turn();
    if (!canMoveColor(turn)) {
      setTypedError("It isn't your turn.");
      return;
    }
    let move;
    try {
      move = /^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(text)
        ? probe.move({ from: text.slice(0, 2).toLowerCase(), to: text.slice(2, 4).toLowerCase(), promotion: text[4]?.toLowerCase() })
        : probe.move(text);
    } catch {
      setTypedError(`"${text}" is not a legal move here.`);
      return;
    }
    const ok = onMove?.(move.from, move.to, move.promotion as "q" | "r" | "b" | "n" | undefined);
    if (ok) {
      setTyped("");
      setTypedError("");
    } else setTypedError("Move rejected.");
  };

  const sideToMove = chess.turn() === "w" ? "White" : "Black";

  return (
    <div className="w-full">
      <div className="flex items-stretch gap-2">
      {side}
      <div ref={wrapRef} className="relative min-w-0 flex-1 select-none" aria-label={`Chess board, ${sideToMove} to move`} role="group">
        <Chessboard
          id={id}
          position={fen}
          boardWidth={width}
          boardOrientation={orientation}
          arePiecesDraggable={movable !== null}
          isDraggablePiece={({ piece }) => canMoveColor(piece[0] as "w" | "b")}
          onPieceDragBegin={(_, sq) => setSelected(sq as Square)}
          onPieceDrop={(from, to) => tryMove(from as Square, to as Square)}
          onSquareClick={onSquareClick}
          onPromotionCheck={() => false}
          autoPromoteToQueen={false}
          customArrows={boardArrows}
          areArrowsAllowed
          customSquareStyles={squareStyles}
          customDarkSquareStyle={{ backgroundColor: "var(--board-dark)" }}
          customLightSquareStyle={{ backgroundColor: "var(--board-light)" }}
          customBoardStyle={{ borderRadius: 6, boxShadow: "0 8px 30px rgba(0,0,0,0.3)" }}
          animationDuration={200}
        />
        {badge && badgePos && (
          <div key={`${badge.square}-${badge.classification}-${fen}`} className="pointer-events-none absolute z-20 animate-pop" style={{ left: badgePos.left, top: badgePos.top }}>
            <ClassificationIcon c={badge.classification} size={badgePos.size} />
          </div>
        )}
        {pendingPromo && (
          <PromotionDialog
            color={chess.turn()}
            onCancel={() => setPendingPromo(null)}
            onSelect={(p) => {
              const { from, to } = pendingPromo;
              setPendingPromo(null);
              onMove?.(from, to, p);
            }}
          />
        )}
      </div>
      </div>
      {typedMoves && movable !== null && (
        <details className="group mt-2 text-sm">
          <summary className="inline-flex cursor-pointer list-none items-center gap-1.5 rounded-lg px-2 py-1 text-xs text-muted transition hover:text-fg">
            <span aria-hidden>⌨</span> Type a move
          </summary>
          <form onSubmit={submitTyped} className="mt-1.5 flex gap-2 animate-fade-in">
            <label htmlFor={`${id}-typed`} className="sr-only">Type a move (SAN like Nf3 or UCI like g1f3)</label>
            <input
              id={`${id}-typed`}
              value={typed}
              onChange={(e) => {
                setTyped(e.target.value);
                setTypedError("");
              }}
              placeholder="e.g. Nf3 or e7e8q"
              className="input py-1.5"
              autoComplete="off"
              spellCheck={false}
              aria-invalid={!!typedError}
              aria-describedby={typedError ? `${id}-typed-err` : undefined}
            />
            <button type="submit" className="btn py-1.5">Move</button>
          </form>
          {typedError && (
            <p id={`${id}-typed-err`} role="alert" className="mt-1 text-xs text-bad">{typedError}</p>
          )}
        </details>
      )}
    </div>
  );
}
