import { rankFor } from "@/lib/chess/ranks";

export function RankBadge({ rating, size = "sm" }: { rating: number; size?: "sm" | "lg" }) {
  const r = rankFor(rating);
  if (size === "sm") {
    return (
      <span className="inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[11px] font-extrabold" style={{ background: `${r.color}22`, color: r.color }} title={`${r.name} · ${rating}`}>
        <span aria-hidden>{r.icon}</span>{r.name}
      </span>
    );
  }
  return (
    <div className="flex items-center gap-4">
      <span className="flex h-16 w-16 items-center justify-center rounded-xl text-4xl animate-pop" style={{ background: `${r.color}26`, boxShadow: `inset 0 0 0 2px ${r.color}` }} aria-hidden>
        {r.icon}
      </span>
      <div className="min-w-0 flex-1">
        <div className="text-xl font-extrabold" style={{ color: r.color }}>{r.name}</div>
        <div className="text-sm font-bold text-muted">{rating} rating</div>
        <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-panel-3" role="progressbar" aria-label={r.next ? `Progress to ${r.next.name}` : "Top rank"} aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(r.progress * 100)}>
          <div className="h-full rounded-full transition-all duration-700" style={{ width: `${r.progress * 100}%`, background: r.color }} />
        </div>
        <div className="mt-1 text-xs text-muted">{r.next ? `${r.next.min - rating} to ${r.next.name}` : "Top rank reached"}</div>
      </div>
    </div>
  );
}
