"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { signIn } from "next-auth/react";

const ERRORS: Record<string, string> = {
  invalid_credentials: "Wrong email/username or password.",
  rate_limited: "Too many sign-in attempts. Wait 15 minutes and try again.",
  credentials: "Wrong email/username or password.",
  OAuthAccountNotLinked: "That email is already registered with a password. Sign in with your password instead.",
};

export function AuthForm({ mode, googleEnabled }: { mode: "login" | "register"; googleEnabled: boolean }) {
  const router = useRouter();
  const params = useSearchParams();
  const callbackUrl = params.get("callbackUrl") || "/profile";
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(params.get("error") ? ERRORS[params.get("error")!] ?? "Sign-in failed." : "");
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      if (mode === "register") {
        const res = await fetch("/api/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email, username, password }),
        });
        const j = await res.json().catch(() => ({}));
        if (!res.ok) {
          setError(j.error ?? "Could not create the account.");
          return;
        }
      }
      const res = await signIn("credentials", { email: mode === "register" ? email.trim().toLowerCase() : email.trim(), password, redirect: false });
      if (!res || res.error) {
        setError(ERRORS[res?.code ?? ""] ?? ERRORS.credentials);
        return;
      }
      router.push(callbackUrl);
      router.refresh();
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto mt-6 max-w-sm animate-fade-up">
      <div className="card space-y-4">
        <h1 className="text-2xl font-extrabold">{mode === "login" ? "Sign in" : "Create your account"}</h1>
        <form onSubmit={submit} className="space-y-3" noValidate>
          <div>
            <label htmlFor="email" className="label">{mode === "login" ? "Email or username" : "Email"}</label>
            <input id="email" type={mode === "login" ? "text" : "email"} autoComplete={mode === "login" ? "username" : "email"} required value={email} onChange={(e) => setEmail(e.target.value)} className="input" autoCapitalize="none" spellCheck={false} />
          </div>
          {mode === "register" && (
            <div>
              <label htmlFor="username" className="label">Username</label>
              <input id="username" autoComplete="username" required minLength={3} maxLength={20} pattern="[A-Za-z0-9_\-]{3,20}" value={username} onChange={(e) => setUsername(e.target.value)} className="input" aria-describedby="username-hint" />
              <p id="username-hint" className="mt-1 text-xs text-muted">3–20 letters, numbers, _ or -.</p>
            </div>
          )}
          <div>
            <div className="flex items-center justify-between">
              <label htmlFor="password" className="label">Password</label>
              {mode === "login" && <Link href="/forgot-password" className="mb-1.5 text-xs font-bold text-accent hover:underline">Forgot password?</Link>}
            </div>
            <input id="password" type="password" autoComplete={mode === "login" ? "current-password" : "new-password"} required minLength={mode === "register" ? 8 : 1} value={password} onChange={(e) => setPassword(e.target.value)} className="input" aria-describedby={mode === "register" ? "pw-hint" : undefined} />
            {mode === "register" && <p id="pw-hint" className="mt-1 text-xs text-muted">At least 8 characters.</p>}
          </div>
          {error && <p role="alert" className="text-sm text-bad">{error}</p>}
          <button type="submit" className="btn-primary w-full" disabled={busy}>
            {busy ? "Please wait…" : mode === "login" ? "Sign in" : "Create account"}
          </button>
        </form>
        {googleEnabled && (
          <>
            <div className="flex items-center gap-2 text-xs text-muted"><span className="h-px flex-1 bg-line" />or<span className="h-px flex-1 bg-line" /></div>
            <button type="button" className="btn w-full" onClick={() => signIn("google", { callbackUrl })}>Continue with Google</button>
          </>
        )}
        <p className="text-sm text-muted">
          {mode === "login" ? (
            <>No account? <Link href="/register" className="text-accent underline">Sign up</Link></>
          ) : (
            <>Already have an account? <Link href="/login" className="text-accent underline">Sign in</Link></>
          )}
        </p>
      </div>
      <p className="mt-3 text-center text-xs text-muted">You can also play and review games as a guest — they just won&apos;t be saved.</p>
    </div>
  );
}
