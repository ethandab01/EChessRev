"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { IconAnalyze, IconFriends, IconPlay, IconPuzzle, IconReview } from "./Icons";
import { useOnlineCounts } from "@/lib/client/usePresence";

const QUICK = [
  { id: "1+0", label: "1 min" },
  { id: "3+2", label: "3 | 2" },
  { id: "10+0", label: "10 min" },
];

/** Home-page quick start: pick a time control and get paired with a real opponent. */
export function PlayPanel() {
  const router = useRouter();
  const counts = useOnlineCounts(15000);
  const [tc, setTc] = useState("10+0");
  useEffect(() => {
    try {
      const saved = localStorage.getItem("echessrev:quick-tc");
      if (saved && QUICK.some((q) => q.id === saved)) setTc(saved);
    } catch {
      /* ignore */
    }
  }, []);
  const pick = (id: string) => {
    setTc(id);
    try {
      localStorage.setItem("echessrev:quick-tc", id);
    } catch {
      /* ignore */
    }
  };

  const links = [
    { href: "/play", label: "Play Online", Icon: IconPlay },
    { href: "/play/computer", label: "Play Computer", Icon: () => <span aria-hidden className="w-[22px] text-center text-lg text-accent">🤖</span> },
    { href: "/puzzles", label: "Puzzles", Icon: IconPuzzle },
    { href: "/review", label: "Game Review", Icon: IconReview },
    { href: "/analysis", label: "Analysis Board", Icon: IconAnalyze },
    { href: "/friends", label: "Play a Friend", Icon: IconFriends },
  ];

  return (
    <section className="card space-y-3 p-4" aria-labelledby="play-heading">
      <div className="flex items-center justify-between">
        <h2 id="play-heading" className="text-lg font-extrabold">Play Online</h2>
        {counts && <span className="flex items-center gap-1.5 text-xs font-bold text-muted"><span className="h-2 w-2 rounded-full bg-accent" />{counts.players} online</span>}
      </div>
      <div className="grid grid-cols-3 gap-2" role="radiogroup" aria-label="Time control">
        {QUICK.map((q) => (
          <button key={q.id} type="button" role="radio" aria-checked={tc === q.id} onClick={() => pick(q.id)} className={`chip py-3.5 text-base ${tc === q.id ? "chip-on" : ""}`}>
            {q.label}
          </button>
        ))}
      </div>
      <button type="button" className="btn-primary btn-xl w-full" onClick={() => router.push(`/play?quick=${tc}`)}>
        Start Game
      </button>
      <nav aria-label="Shortcuts" className="space-y-2 pt-1">
        {links.map(({ href, label, Icon }) => (
          <Link key={href} href={href} className="btn w-full justify-start gap-3 py-3 text-base">
            <Icon className="text-accent" /> {label}
          </Link>
        ))}
      </nav>
    </section>
  );
}
