"use client";

import { useMemo } from "react";
import { itemValue } from "@/lib/shop";

const COLORS = ["#5bba67", "#f2ab3c", "#4a8fe7", "#ef5b4f", "#b06be0", "#f1f2f4"];

/** Confetti pieces with randomized trajectories (deterministic per mount). */
export function Confetti({ count = 70 }: { count?: number }) {
  const pieces = useMemo(
    () =>
      Array.from({ length: count }, (_, i) => {
        const left = Math.random() * 100;
        return {
          i,
          left,
          color: COLORS[i % COLORS.length],
          dx: (Math.random() - 0.5) * 260,
          dy: 380 + Math.random() * 380,
          rot: (Math.random() - 0.5) * 1440,
          delay: Math.random() * 0.35,
          dur: 1.8 + Math.random() * 1.4,
          w: 6 + Math.random() * 6,
          round: Math.random() < 0.3,
        };
      }),
    [count],
  );
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
      {pieces.map((p) => (
        <span
          key={p.i}
          className="confetti-piece"
          style={{
            left: `${p.left}%`,
            background: p.color,
            width: p.w,
            height: p.round ? p.w : p.w * 1.5,
            borderRadius: p.round ? "50%" : 2,
            ["--dx" as string]: `${p.dx}px`,
            ["--dy" as string]: `${p.dy}px`,
            ["--rot" as string]: `${p.rot}deg`,
            ["--delay" as string]: `${p.delay}s`,
            ["--dur" as string]: `${p.dur}s`,
          }}
        />
      ))}
    </div>
  );
}

/** Emoji particles falling from the top (shop win effects). */
export function EmojiRain({ glyphs, count = 40 }: { glyphs: string; count?: number }) {
  const chars = useMemo(() => Array.from(glyphs).filter((c) => c.trim() && c !== "\uFE0F"), [glyphs]);
  const pieces = useMemo(
    () =>
      Array.from({ length: count }, (_, i) => ({
        i,
        left: Math.random() * 100,
        ch: chars[i % chars.length],
        dx: (Math.random() - 0.5) * 160,
        dy: 420 + Math.random() * 360,
        rot: (Math.random() - 0.5) * 540,
        delay: Math.random() * 0.8,
        dur: 2 + Math.random() * 1.6,
        size: 16 + Math.random() * 18,
      })),
    [count, chars],
  );
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
      {pieces.map((p) => (
        <span
          key={p.i}
          className="confetti-piece"
          style={{ left: `${p.left}%`, width: "auto", height: "auto", fontSize: p.size, lineHeight: 1, ["--dx" as string]: `${p.dx}px`, ["--dy" as string]: `${p.dy}px`, ["--rot" as string]: `${p.rot}deg`, ["--delay" as string]: `${p.delay}s`, ["--dur" as string]: `${p.dur}s` }}
        >
          {p.ch}
        </span>
      ))}
    </div>
  );
}

/** Firework bursts: rings of sparks expanding from a few points. */
function Fireworks() {
  const bursts = useMemo(() => Array.from({ length: 5 }, (_, i) => ({ i, x: 15 + Math.random() * 70, y: 12 + Math.random() * 45, delay: i * 0.35, hue: Math.floor(Math.random() * 360) })), []);
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
      {bursts.map((b) => (
        <div key={b.i} className="absolute" style={{ left: `${b.x}%`, top: `${b.y}%` }}>
          {Array.from({ length: 14 }, (_, k) => {
            const a = (k / 14) * Math.PI * 2;
            return (
              <span
                key={k}
                className="confetti-piece"
                style={{ top: 0, left: 0, width: 6, height: 6, borderRadius: "50%", background: `hsl(${b.hue + k * 6} 90% 60%)`, boxShadow: `0 0 8px hsl(${b.hue} 90% 60%)`, ["--dx" as string]: `${Math.cos(a) * 90}px`, ["--dy" as string]: `${Math.sin(a) * 90 + 30}px`, ["--rot" as string]: "0deg", ["--delay" as string]: `${b.delay}s`, ["--dur" as string]: "1.3s" }}
              />
            );
          })}
        </div>
      ))}
    </div>
  );
}

/** Full-board celebration layer: confetti + trophy (win), toppling king (loss), handshake (draw). */
export function GameOverFx({ outcome, kingColor = "w", effect }: { outcome: "win" | "loss" | "draw"; kingColor?: "w" | "b"; effect?: string | null }) {
  if (outcome === "win") {
    return (
      <div className="pointer-events-none absolute inset-0 z-20" aria-hidden>
        {effect === "effect-fireworks" ? <Fireworks /> : itemValue(effect) ? <EmojiRain glyphs={itemValue(effect)!} /> : <Confetti />}
        <div className="absolute inset-x-0 top-[10%] flex justify-center">
          <div className="relative">
            <div className="absolute -inset-10 rounded-full opacity-70" style={{ background: "conic-gradient(from 0deg, transparent, rgba(242,171,60,0.45), transparent 30%, rgba(91,186,103,0.4), transparent 60%)", animation: "glow-spin 4s linear infinite" }} />
            <div className="relative text-7xl drop-shadow-lg" style={{ animation: "trophy-rise 0.8s cubic-bezier(0.2,1.4,0.4,1) both" }}>🏆</div>
          </div>
        </div>
      </div>
    );
  }
  if (outcome === "loss") {
    return (
      <div className="pointer-events-none absolute inset-0 z-20" aria-hidden>
        <div className="absolute inset-0 rounded-[10px]" style={{ background: "radial-gradient(circle at 50% 45%, rgba(0,0,0,0.15), rgba(0,0,0,0.65))", animation: "loss-vignette 0.9s ease-out both" }} />
        <div className="absolute inset-x-0 top-[12%] flex justify-center">
          <svg width="84" height="84" viewBox="0 0 64 64" className="drop-shadow-lg" style={{ transformOrigin: "50% 95%", animation: "king-topple 1.1s cubic-bezier(0.5,0,0.3,1) 0.2s both" }}>
            <g fill={kingColor === "w" ? "#f4f4f4" : "#1b1b1b"} stroke={kingColor === "w" ? "#2a2a2a" : "#e6e6e6"} strokeWidth="2.5" strokeLinejoin="round">
              <path d="M29 4h6v6h6v6h-6v5h-6v-5h-6v-6h6z" />
              <path d="M14 30c0-8 8-11 18-11s18 3 18 11c0 7-5 13-7 18H21c-2-5-7-11-7-18z" />
              <rect x="17" y="48" width="30" height="6" rx="2" />
              <rect x="13" y="54" width="38" height="7" rx="2.5" />
            </g>
          </svg>
        </div>
      </div>
    );
  }
  return (
    <div className="pointer-events-none absolute inset-0 z-20" aria-hidden>
      <div className="absolute inset-0 rounded-[10px] bg-black/30" style={{ animation: "loss-vignette 0.6s ease-out both" }} />
      <div className="absolute inset-x-0 top-[14%] flex items-center justify-center gap-1">
        <span className="absolute h-24 w-24 rounded-full border-4 border-gold" style={{ animation: "ring-out 1.2s ease-out 0.5s both" }} />
        <span className="text-6xl font-extrabold text-white drop-shadow" style={{ ["--from" as string]: "-70px", animation: "handshake 0.8s ease-out both" }}>½</span>
        <span className="text-6xl font-extrabold text-gold drop-shadow" style={{ ["--from" as string]: "70px", animation: "handshake 0.8s ease-out both" }}>½</span>
      </div>
    </div>
  );
}
