"use client";

import { useRef, useState } from "react";
import { gameTitle, parseFen, parseMultiPgn, type ParsedGame } from "@/lib/chess/pgn";

type Tab = "pgn" | "file" | "fen" | "lichess";

export interface ImportPanelProps {
  onGame: (game: ParsedGame, raw: string) => void;
  onFen?: (fen: string) => void;
  tabs?: Tab[];
}

/** Paste PGN (multi-game picker), upload .pgn, paste FEN, or import a Lichess game URL. */
export function ImportPanel({ onGame, onFen, tabs = ["pgn", "file", "fen", "lichess"] }: ImportPanelProps) {
  const [tab, setTab] = useState<Tab>(tabs[0]);
  const [text, setText] = useState("");
  const [fen, setFen] = useState("");
  const [url, setUrl] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [choices, setChoices] = useState<ReturnType<typeof parseMultiPgn> | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const handlePgnText = (raw: string) => {
    setError("");
    setChoices(null);
    let parsed;
    try {
      parsed = parseMultiPgn(raw);
    } catch (e) {
      setError((e as Error).message);
      return;
    }
    if (parsed.length === 1) {
      if (parsed[0].error) setError(parsed[0].error);
      else onGame(parsed[0].game!, parsed[0].raw);
      return;
    }
    if (parsed.every((p) => p.error)) {
      setError(`None of the ${parsed.length} games could be read. First error: ${parsed[0].error}`);
      return;
    }
    setChoices(parsed);
  };

  const onFile = async (f: File | undefined) => {
    if (!f) return;
    if (f.size > 5_000_000) {
      setError("That file is larger than 5 MB.");
      return;
    }
    handlePgnText(await f.text());
  };

  const importLichess = async () => {
    setError("");
    setBusy(true);
    try {
      const res = await fetch(`/api/import/lichess?url=${encodeURIComponent(url)}`);
      const j = await res.json();
      if (!res.ok) throw new Error(j.error ?? "Import failed");
      handlePgnText(j.pgn);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const labels: Record<Tab, string> = { pgn: "Paste PGN", file: "Upload .pgn", fen: "FEN", lichess: "Lichess URL" };

  return (
    <div className="card space-y-3">
      <div role="tablist" aria-label="Import source" className="flex flex-wrap gap-1">
        {tabs.map((t) => (
          <button
            key={t}
            type="button"
            role="tab"
            aria-selected={tab === t}
            aria-controls={`import-${t}`}
            id={`import-tab-${t}`}
            onClick={() => {
              setTab(t);
              setError("");
            }}
            className={`rounded-lg px-3 py-1.5 text-sm ${tab === t ? "bg-accent text-accent-fg" : "bg-panel-2 hover:brightness-110"}`}
          >
            {labels[t]}
          </button>
        ))}
      </div>

      {tab === "pgn" && (
        <form
          id="import-pgn"
          role="tabpanel"
          aria-labelledby="import-tab-pgn"
          onSubmit={(e) => {
            e.preventDefault();
            handlePgnText(text);
          }}
          className="space-y-2"
        >
          <label htmlFor="pgn-text" className="label">PGN (headers, comments and variations are fine; multiple games allowed)</label>
          <textarea id="pgn-text" value={text} onChange={(e) => setText(e.target.value)} rows={7} className="input font-mono" placeholder={'[Event "..."]\n\n1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 *'} />
          <button type="submit" className="btn-primary" disabled={!text.trim()}>Load PGN</button>
        </form>
      )}
      {tab === "file" && (
        <div id="import-file" role="tabpanel" aria-labelledby="import-tab-file" className="space-y-2">
          <label htmlFor="pgn-file" className="label">Choose a .pgn file</label>
          <input
            ref={fileRef}
            id="pgn-file"
            type="file"
            accept=".pgn,application/x-chess-pgn,text/plain"
            onChange={(e) => onFile(e.target.files?.[0])}
            className="block w-full text-sm file:mr-3 file:rounded-lg file:border-0 file:bg-accent file:px-3 file:py-2 file:font-semibold file:text-accent-fg"
          />
        </div>
      )}
      {tab === "fen" && onFen && (
        <form
          id="import-fen"
          role="tabpanel"
          aria-labelledby="import-tab-fen"
          onSubmit={(e) => {
            e.preventDefault();
            setError("");
            try {
              onFen(parseFen(fen));
            } catch (err) {
              setError((err as Error).message);
            }
          }}
          className="space-y-2"
        >
          <label htmlFor="fen-text" className="label">FEN</label>
          <input id="fen-text" value={fen} onChange={(e) => setFen(e.target.value)} className="input font-mono" placeholder="rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1" />
          <button type="submit" className="btn-primary" disabled={!fen.trim()}>Set up position</button>
        </form>
      )}
      {tab === "lichess" && (
        <form
          id="import-lichess"
          role="tabpanel"
          aria-labelledby="import-tab-lichess"
          onSubmit={(e) => {
            e.preventDefault();
            importLichess();
          }}
          className="space-y-2"
        >
          <label htmlFor="lichess-url" className="label">Lichess game URL</label>
          <input id="lichess-url" value={url} onChange={(e) => setUrl(e.target.value)} className="input" placeholder="https://lichess.org/abcdEFGH" inputMode="url" />
          <button type="submit" className="btn-primary" disabled={!url.trim() || busy}>{busy ? "Importing…" : "Import"}</button>
        </form>
      )}

      {error && (
        <p role="alert" className="rounded-lg border border-bad/50 bg-bad/10 px-3 py-2 text-sm text-bad">
          {error}
        </p>
      )}

      {choices && (
        <div className="space-y-1">
          <p className="label">{choices.length} games found — pick one</p>
          <ul className="max-h-64 space-y-1 overflow-y-auto">
            {choices.map((c) => (
              <li key={c.index}>
                <button
                  type="button"
                  disabled={!!c.error}
                  onClick={() => {
                    setChoices(null);
                    onGame(c.game!, c.raw);
                  }}
                  className="w-full rounded-lg border border-line bg-panel-2 px-3 py-2 text-left text-sm hover:border-accent disabled:opacity-60"
                >
                  {c.game ? (
                    <>
                      {gameTitle(c.game.headers, c.index)} <span className="text-muted">· {Math.ceil(c.game.moves.length / 2)} {Math.ceil(c.game.moves.length / 2) === 1 ? "move" : "moves"}</span>
                    </>
                  ) : (
                    <span className="text-bad">Game {c.index + 1}: {c.error}</span>
                  )}
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
