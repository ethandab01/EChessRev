import type { Bot } from "@/lib/chess/bots";

/** Generated geometric avatar: a shape in the bot's hue with a rook glyph. */
export function BotAvatar({ bot, size = 48, className = "" }: { bot: Bot; size?: number; className?: string }) {
  const fill = `hsl(${bot.hue} 75% 60%)`;
  const fill2 = `hsl(${(bot.hue + 40) % 360} 80% 55%)`;
  const bg = `hsl(${bot.hue} 30% 16%)`;
  const gid = `g-${bot.id}-${size}`;
  const shapes: Record<Bot["shape"], React.ReactNode> = {
    circle: <circle cx="24" cy="24" r="15" fill={`url(#${gid})`} />,
    square: <rect x="10" y="10" width="28" height="28" rx="7" fill={`url(#${gid})`} />,
    diamond: <path d="M24 7 41 24 24 41 7 24z" fill={`url(#${gid})`} />,
    hex: <path d="M24 7 39 15.5v17L24 41 9 32.5v-17z" fill={`url(#${gid})`} />,
    triangle: <path d="M24 8 41 38H7z" fill={`url(#${gid})`} />,
  };
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" role="img" aria-label={`${bot.name} avatar`} className={`shrink-0 rounded-xl ${className}`}>
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor={fill} />
          <stop offset="1" stopColor={fill2} />
        </linearGradient>
      </defs>
      <rect width="48" height="48" rx="12" fill={bg} />
      {shapes[bot.shape]}
      <text x="24" y={bot.shape === "triangle" ? 34 : 30} textAnchor="middle" fontSize="15" fill={bg} fontFamily="system-ui, sans-serif" fontWeight="800">
        {bot.elo >= 3200 ? "M" : "♜"}
      </text>
    </svg>
  );
}
