import { itemValue } from "@/lib/shop";

/** A player's avatar: their equipped shop icon, or a colored initial. */
export function UserAvatar({ name, icon, size = 38, className = "" }: { name: string; icon?: string | null; size?: number; className?: string }) {
  const glyph = itemValue(icon);
  const hue = [...(name || "?")].reduce((h, c) => (h * 31 + c.charCodeAt(0)) % 360, 7);
  return (
    <span
      aria-hidden
      className={`flex shrink-0 items-center justify-center rounded-md font-extrabold text-white ${className}`}
      style={{ width: size, height: size, fontSize: glyph ? size * 0.58 : size * 0.45, background: glyph ? `hsl(${hue} 30% 26%)` : `hsl(${hue} 55% 45%)` }}
    >
      {glyph ?? (name[0]?.toUpperCase() || "?")}
    </span>
  );
}

/** Username followed by the equipped flair emoji. */
export function NameWithFlair({ name, flair }: { name: string; flair?: string | null }) {
  const f = itemValue(flair);
  return (
    <>
      {name}
      {f && <span className="ml-1" title="Flair">{f}</span>}
    </>
  );
}
