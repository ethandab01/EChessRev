"use client";

import { useEffect, useRef } from "react";
import type { Classification } from "@/lib/chess/types";
import { CLASSIFICATION_META } from "@/lib/chess/classify";
import { ClassificationIcon } from "./ClassificationIcon";

export interface MoveListItem {
  san: string;
  classification?: Classification;
}

/**
 * SAN move list in two columns. `current` is the ply shown on the board (0 = start);
 * clicking a move calls onSelect(ply).
 */
export function MoveList({
  moves,
  current,
  onSelect,
  startFen,
  className = "",
  label = "Moves",
}: {
  moves: MoveListItem[];
  current: number;
  onSelect?: (ply: number) => void;
  startFen?: string;
  className?: string;
  label?: string;
}) {
  const parts = (startFen ?? "w w w w w 1").split(" ");
  const blackFirst = parts[1] === "b";
  const firstMoveNo = Number(parts[5] ?? 1) || 1;
  const activeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    activeRef.current?.scrollIntoView({ block: "nearest" });
  }, [current]);

  const rows: Array<{ no: number; w?: { ply: number; m: MoveListItem }; b?: { ply: number; m: MoveListItem } }> = [];
  moves.forEach((m, i) => {
    const ply = i + 1;
    const idx = i + (blackFirst ? 1 : 0);
    const rowIdx = Math.floor(idx / 2);
    rows[rowIdx] ??= { no: firstMoveNo + rowIdx };
    if (idx % 2 === 0) rows[rowIdx].w = { ply, m };
    else rows[rowIdx].b = { ply, m };
  });

  const cell = (c?: { ply: number; m: MoveListItem }) => {
    if (!c) return <span className="px-2 py-1 text-muted">…</span>;
    const active = c.ply === current;
    const meta = c.m.classification ? CLASSIFICATION_META[c.m.classification] : null;
    return (
      <button
        ref={active ? activeRef : undefined}
        type="button"
        disabled={!onSelect}
        onClick={() => onSelect?.(c.ply)}
        aria-current={active ? "true" : undefined}
        aria-label={`${c.m.san}${meta ? `, ${meta.label}` : ""}`}
        className={`flex w-full items-center gap-1.5 rounded-md px-2 py-1 text-left font-mono text-sm transition ${active ? "bg-accent text-accent-fg" : "hover:bg-panel-2"} disabled:cursor-default`}
      >
        {c.m.classification && <ClassificationIcon c={c.m.classification} size={15} />}
        <span style={meta && !active && ["brilliant", "great", "inaccuracy", "mistake", "miss", "blunder"].includes(c.m.classification!) ? { color: meta.color } : undefined}>
          {c.m.san}
        </span>
      </button>
    );
  };

  return (
    <div className={`overflow-y-auto ${className}`} role="list" aria-label={label}>
      {rows.length === 0 && <p className="px-2 py-1 text-sm text-muted">No moves yet.</p>}
      {rows.map((r) => (
        <div key={r.no} role="listitem" className="grid grid-cols-[2.5rem_1fr_1fr] items-center rounded-lg odd:bg-panel-2/40 animate-fade-in">
          <span className="pl-2 font-mono text-xs text-muted">{r.no}.</span>
          {cell(r.w)}
          {cell(r.b)}
        </div>
      ))}
    </div>
  );
}
