export function EngineError({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <div role="alert" className="flex flex-wrap items-center gap-2 rounded-xl border border-bad/50 bg-bad/10 px-3 py-2 text-sm">
      <span>
        <strong>Engine unavailable.</strong> {message} The board still works without it.
      </span>
      <button type="button" className="btn ml-auto py-1" onClick={onRetry}>Retry</button>
    </div>
  );
}
