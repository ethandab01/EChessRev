"use client";

import { useEffect, useRef } from "react";

const PIECES: Array<{ p: "q" | "r" | "b" | "n"; name: string; w: string; b: string }> = [
  { p: "q", name: "Queen", w: "♕", b: "♛" },
  { p: "r", name: "Rook", w: "♖", b: "♜" },
  { p: "b", name: "Bishop", w: "♗", b: "♝" },
  { p: "n", name: "Knight", w: "♘", b: "♞" },
];

export function PromotionDialog({ color, onSelect, onCancel }: { color: "w" | "b"; onSelect: (p: "q" | "r" | "b" | "n") => void; onCancel: () => void }) {
  const first = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    first.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onCancel();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onCancel]);
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/50" role="dialog" aria-modal="true" aria-label="Choose promotion piece">
      <div className="card flex gap-2 shadow-2xl">
        {PIECES.map((x, i) => (
          <button
            key={x.p}
            ref={i === 0 ? first : undefined}
            type="button"
            onClick={() => onSelect(x.p)}
            className="flex h-16 w-16 flex-col items-center justify-center rounded-lg border border-line bg-panel-2 text-4xl leading-none hover:border-accent"
            aria-label={`Promote to ${x.name}`}
          >
            <span aria-hidden>{color === "w" ? x.w : x.b}</span>
            <span className="mt-1 text-[10px] text-muted">{x.name}</span>
          </button>
        ))}
        <button type="button" onClick={onCancel} className="btn self-center" aria-label="Cancel promotion">✕</button>
      </div>
    </div>
  );
}
