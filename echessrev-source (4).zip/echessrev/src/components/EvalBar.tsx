"use client";

/** Vertical evaluation bar. `whiteCp` is from White's perspective (mate ≈ ±10000). */
export function EvalBar({ whiteCp, label, orientation }: { whiteCp: number; label: string; orientation: "white" | "black" }) {
  const clamped = Math.max(-1000, Math.min(1000, whiteCp));
  // Same logistic as win%: maps eval to the share of the bar that is White's.
  const whiteShare = Math.abs(whiteCp) >= 9000 ? (whiteCp > 0 ? 100 : 0) : 50 + 50 * (2 / (1 + Math.exp(-0.00368208 * clamped)) - 1);
  const whiteOnBottom = orientation === "white";
  return (
    <div
      className="relative w-6 shrink-0 self-stretch overflow-hidden rounded-md border border-line bg-[#2b2f36] sm:w-7"
      role="meter"
      aria-label="Evaluation"
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={Math.round(whiteShare)}
      aria-valuetext={label}
    >
      <div
        className="absolute left-0 right-0 bg-[#f1f1ee] transition-all duration-300"
        style={whiteOnBottom ? { bottom: 0, height: `${whiteShare}%` } : { top: 0, height: `${whiteShare}%` }}
      />
      <span
        className={`absolute left-0 right-0 text-center text-[9px] font-bold sm:text-[10px] ${whiteCp >= 0 ? "text-[#2b2f36]" : "text-[#f1f1ee]"}`}
        style={(whiteCp >= 0) === whiteOnBottom ? { bottom: 4 } : { top: 4 }}
      >
        {label.replace(/^\+/, "")}
      </span>
    </div>
  );
}
