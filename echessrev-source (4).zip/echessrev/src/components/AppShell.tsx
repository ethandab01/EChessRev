"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut, useSession } from "next-auth/react";
import { useEffect, useState } from "react";
import { Logo } from "./Logo";
import { IconAnalyze, IconFlame, IconFriends, IconLogout, IconMoon, IconPlay, IconPuzzle, IconReview, IconShop, IconSun, IconUser } from "./Icons";
import { useMe } from "@/lib/client/useMe";
import { usePresence } from "@/lib/client/usePresence";
import { boardColors } from "@/lib/shop";
import { UserAvatar, NameWithFlair } from "./UserAvatar";

const NAV = [
  { href: "/play", label: "Play", Icon: IconPlay },
  { href: "/puzzles", label: "Puzzles", Icon: IconPuzzle },
  { href: "/review", label: "Review", Icon: IconReview },
  { href: "/analysis", label: "Analyze", Icon: IconAnalyze },
  { href: "/friends", label: "Friends", Icon: IconFriends },
  { href: "/shop", label: "Shop", Icon: IconShop },
];

function useTheme() {
  const [dark, setDark] = useState(true);
  useEffect(() => setDark(document.documentElement.classList.contains("dark")), []);
  const toggle = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    try {
      localStorage.setItem("theme", next ? "dark" : "light");
    } catch {
      /* ignore */
    }
  };
  return { dark, toggle };
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { data: session, status } = useSession();
  const me = useMe();
  const online = usePresence();

  // Apply the equipped board theme (cached so the next page load paints it immediately).
  useEffect(() => {
    if (!me) return;
    const c = boardColors(me.boardTheme);
    const root = document.documentElement;
    if (c && me.boardTheme !== "classic") {
      root.style.setProperty("--board-light", c[0]);
      root.style.setProperty("--board-dark", c[1]);
      try { localStorage.setItem("echessrev:board", JSON.stringify(c)); } catch { /* ignore */ }
    } else {
      root.style.removeProperty("--board-light");
      root.style.removeProperty("--board-dark");
      try { localStorage.removeItem("echessrev:board"); } catch { /* ignore */ }
    }
  }, [me]);
  const { dark, toggle } = useTheme();
  const signedIn = status === "authenticated";
  const name = me?.username ?? session?.user?.username ?? session?.user?.name ?? "";

  const friendBadge = me ? me.pendingFriendRequests + me.challenges + me.yourTurn : 0;
  const isActive = (href: string) => pathname === href || pathname.startsWith(href + "/");

  return (
    <div className="min-h-screen">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[200px] flex-col bg-sidebar md:flex" aria-label="Sidebar">
        <Link href="/" className="flex items-center gap-2.5 px-5 pb-5 pt-5 text-xl font-extrabold tracking-tight" aria-label="EChessREV home">
          <Logo />
          <span>EChess<span className="text-accent">REV</span></span>
        </Link>
        <nav aria-label="Main" className="flex flex-col gap-0.5 px-2">
          {NAV.map(({ href, label, Icon }) => {
            const active = isActive(href);
            return (
              <Link
                key={href}
                href={href}
                aria-current={active ? "page" : undefined}
                className={`group relative flex items-center gap-3 rounded-lg px-3 py-2.5 text-[15px] font-bold transition ${active ? "bg-panel text-fg" : "text-muted hover:bg-panel/60 hover:text-fg"}`}
              >
                {active && <span className="absolute left-0 top-2 bottom-2 w-1 rounded-r bg-accent" aria-hidden />}
                <Icon className={`transition group-hover:scale-110 ${active ? "text-accent" : ""}`} />
                {label}
                {href === "/friends" && friendBadge > 0 && (
                  <span className="ml-auto flex h-5 min-w-5 items-center justify-center rounded-full bg-bad px-1 text-[11px] font-extrabold text-white animate-pop">{friendBadge}</span>
                )}
              </Link>
            );
          })}
        </nav>

        {online && (
          <div className="mx-4 mt-5 flex items-center gap-2 text-xs font-bold text-muted" aria-live="off">
            <span className="relative flex h-2.5 w-2.5"><span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-accent opacity-60" /><span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-accent" /></span>
            {online.players.toLocaleString()} online
          </div>
        )}
        <div className="mt-auto space-y-1 px-2 pb-4">
          {signedIn ? (
            <>
              <Link href="/profile" className={`flex items-center gap-3 rounded-lg px-3 py-2.5 transition hover:bg-panel/60 ${isActive("/profile") ? "bg-panel" : ""}`}>
                <UserAvatar name={name} icon={me?.avatarIcon} size={32} />
                <span className="min-w-0">
                  <span className="block truncate text-sm font-bold"><NameWithFlair name={name} flair={me?.flair} /></span>
                  {me && <span className="block text-xs font-bold text-gold">◆ {me.points.toLocaleString()}</span>}
                </span>
              </Link>
              <button type="button" onClick={() => signOut({ callbackUrl: "/" })} className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-bold text-muted transition hover:bg-panel/60 hover:text-fg">
                <IconLogout /> Sign out
              </button>
            </>
          ) : status === "unauthenticated" ? (
            <div className="space-y-2 px-1">
              <Link href="/register" className="btn-primary w-full">Sign Up</Link>
              <Link href="/login" className="btn w-full">Log In</Link>
            </div>
          ) : null}
          <button type="button" onClick={toggle} className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-bold text-muted transition hover:bg-panel/60 hover:text-fg" aria-label={dark ? "Switch to light mode" : "Switch to dark mode"}>
            {dark ? <IconSun /> : <IconMoon />} {dark ? "Light mode" : "Dark mode"}
          </button>
        </div>
      </aside>

      {/* Mobile top bar */}
      <header className="sticky top-0 z-40 flex h-14 items-center gap-2 bg-sidebar px-4 md:hidden">
        <Link href="/" className="flex items-center gap-2 text-lg font-extrabold" aria-label="EChessREV home">
          <Logo size={26} />
          <span>EChess<span className="text-accent">REV</span></span>
        </Link>
        <div className="ml-auto flex items-center gap-2">
          {me && <span className="rounded-full bg-panel px-2.5 py-1 text-xs font-bold text-gold">◆ {me.points}</span>}
          {me && me.puzzleStreak > 0 && <span className="flex items-center gap-0.5 rounded-full bg-panel px-2 py-1 text-xs font-bold"><IconFlame size={14} />{me.puzzleStreak}</span>}
          <button type="button" onClick={toggle} className="btn h-9 w-9 p-0" aria-label={dark ? "Switch to light mode" : "Switch to dark mode"}>{dark ? <IconSun size={18} /> : <IconMoon size={18} />}</button>
          {signedIn ? (
            <Link href="/profile" aria-label="Profile"><UserAvatar name={name} icon={me?.avatarIcon} size={36} /></Link>
          ) : status === "unauthenticated" ? (
            <Link href="/login" className="btn h-9 px-3 py-0" aria-label="Log in"><IconUser size={18} /></Link>
          ) : null}
        </div>
      </header>

      <div className="md:pl-[200px]">
        <main id="main" className="mx-auto w-full max-w-[1200px] px-3 pb-24 pt-4 sm:px-6 md:pb-12 md:pt-6">{children}</main>
      </div>

      {/* Mobile tab bar */}
      <nav aria-label="Mobile" className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-6 border-t border-line bg-sidebar pb-[env(safe-area-inset-bottom)] md:hidden">
        {NAV.map(({ href, label, Icon }) => {
          const active = isActive(href);
          return (
            <Link key={href} href={href} aria-current={active ? "page" : undefined} className={`relative flex flex-col items-center gap-0.5 py-2 text-[10px] font-bold ${active ? "text-accent" : "text-muted"}`}>
              <Icon size={22} />
              {label}
              {href === "/friends" && friendBadge > 0 && <span className="absolute right-[28%] top-1.5 h-2 w-2 rounded-full bg-bad" aria-label="New friend requests" />}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
