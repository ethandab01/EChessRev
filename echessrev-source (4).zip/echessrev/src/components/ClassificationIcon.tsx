import { CLASSIFICATION_META } from "@/lib/chess/classify";
import type { Classification } from "@/lib/chess/types";

/** Round badge with the classification's symbol (color is always paired with a symbol). */
export function ClassificationIcon({ c, size = 18, className = "" }: { c: Classification; size?: number; className?: string }) {
  const meta = CLASSIFICATION_META[c];
  return (
    <span
      role="img"
      aria-label={meta.label}
      title={meta.label}
      className={`inline-flex shrink-0 items-center justify-center rounded-full font-bold leading-none text-white shadow ${className}`}
      style={{ width: size, height: size, background: meta.color, fontSize: size * (meta.symbol.length > 1 ? 0.5 : 0.62) }}
    >
      {c === "book" ? (
        <svg aria-hidden viewBox="0 0 24 24" width={size * 0.66} height={size * 0.66} fill="none" stroke="white" strokeWidth="2.4">
          <path d="M4 5.5C6.5 4 9.5 4 12 6c2.5-2 5.5-2 8-.5V19c-2.5-1.5-5.5-1.5-8 .5-2.5-2-5.5-2-8-.5z" />
          <path d="M12 6v13.5" />
        </svg>
      ) : c === "excellent" ? (
        <svg aria-hidden viewBox="0 0 24 24" width={size * 0.62} height={size * 0.62} fill="white">
          <path d="M2 10h4v11H2zM8 21h9.5a2 2 0 0 0 2-1.6l1.4-7A2 2 0 0 0 19 10h-5l.8-4.2A2 2 0 0 0 12.9 3.4L8 9z" />
        </svg>
      ) : (
        <span aria-hidden>{meta.symbol}</span>
      )}
    </span>
  );
}
