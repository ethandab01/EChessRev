"use client";

import { useState } from "react";

export function ExportBar({ pgn, fen, filename = "echessrev-game.pgn" }: { pgn: string; fen: string; filename?: string }) {
  const [msg, setMsg] = useState("");
  const copy = async (text: string, what: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setMsg(`${what} copied to clipboard.`);
    } catch {
      setMsg(`Could not access the clipboard — select and copy manually.`);
    }
    setTimeout(() => setMsg(""), 2500);
  };
  const download = () => {
    const blob = new Blob([pgn], { type: "application/x-chess-pgn" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  return (
    <div className="flex flex-wrap items-center gap-2">
      <button type="button" className="btn py-1.5" onClick={() => copy(pgn, "PGN")}>Copy PGN</button>
      <button type="button" className="btn py-1.5" onClick={download}>Download PGN</button>
      <button type="button" className="btn py-1.5" onClick={() => copy(fen, "FEN")}>Copy FEN</button>
      <span role="status" aria-live="polite" className="text-xs text-muted">{msg}</span>
    </div>
  );
}
