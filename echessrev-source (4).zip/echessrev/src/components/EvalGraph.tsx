"use client";

import type { Classification } from "@/lib/chess/types";
import { ClassificationIcon } from "./ClassificationIcon";
import { CLASSIFICATION_META } from "@/lib/chess/classify";

const DOT_CLASSES: Classification[] = ["brilliant", "great", "inaccuracy", "mistake", "miss", "blunder"];

/**
 * Eval graph over the whole game. Values are White's win% per position (0..100).
 * Click a point, or focus it and use ←/→, to jump to that move.
 */
export function EvalGraph({
  whiteWinPcts,
  classifications,
  labels,
  current,
  onSelect,
}: {
  whiteWinPcts: number[];
  classifications: Classification[];
  /** Move labels like "12... Nf6", index i = move i. */
  labels: string[];
  /** Current ply (0 = start). */
  current: number;
  onSelect: (ply: number) => void;
}) {
  const W = 600;
  const H = 120;
  const n = whiteWinPcts.length;
  const xPct = (i: number) => (n <= 1 ? 0 : (i / (n - 1)) * 100);
  const x = (i: number) => (xPct(i) / 100) * W;
  const y = (v: number) => H - (v / 100) * H;
  const area = `M0,${H} ` + whiteWinPcts.map((v, i) => `L${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(" ") + ` L${W},${H} Z`;
  const line = whiteWinPcts.map((v, i) => `${i === 0 ? "M" : "L"}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(" ");

  const handleClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const rel = (e.clientX - rect.left) / rect.width;
    onSelect(Math.max(0, Math.min(n - 1, Math.round(rel * (n - 1)))));
  };
  return (
    <div
      className="relative h-28 w-full cursor-pointer overflow-visible rounded-lg border border-line bg-[#2b2f36]"
      onClick={handleClick}
      role="slider"
      tabIndex={0}
      aria-label="Evaluation graph — click or use arrow keys to jump to a move"
      aria-valuemin={0}
      aria-valuemax={Math.max(0, n - 1)}
      aria-valuenow={current}
      aria-valuetext={current === 0 ? "Start position" : labels[current - 1]}
      onKeyDown={(e) => {
        if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
          e.preventDefault();
          e.stopPropagation();
          onSelect(e.key === "ArrowRight" ? Math.min(n - 1, current + 1) : Math.max(0, current - 1));
        }
      }}
    >
      <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" className="absolute inset-0 h-full w-full" aria-hidden>
        <path d={area} fill="#f1f1ee" />
        <line x1="0" x2={W} y1={H / 2} y2={H / 2} stroke="#888" strokeWidth="1" strokeDasharray="4 4" vectorEffect="non-scaling-stroke" />
        <path d={line} fill="none" stroke="var(--accent)" strokeWidth="1.5" vectorEffect="non-scaling-stroke" />
        <line x1={x(current)} x2={x(current)} y1="0" y2={H} stroke="var(--accent)" strokeWidth="2" vectorEffect="non-scaling-stroke" />
      </svg>
      {classifications.map((c, i) =>
        DOT_CLASSES.includes(c) ? (
          <button
            key={i}
            type="button"
            tabIndex={-1}
            className="absolute -translate-x-1/2 -translate-y-1/2"
            style={{ left: `${xPct(i + 1)}%`, top: `${100 - whiteWinPcts[i + 1]}%` }}
            onClick={(e) => {
              e.stopPropagation();
              onSelect(i + 1);
            }}
            aria-label={`${labels[i]}: ${CLASSIFICATION_META[c].label}`}
          >
            <ClassificationIcon c={c} size={14} />
          </button>
        ) : null,
      )}
    </div>
  );
}
