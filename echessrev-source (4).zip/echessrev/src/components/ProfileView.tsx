import Link from "next/link";
import { prisma } from "@/lib/server/db";
import { botForElo, tierFor, TIERS } from "@/lib/chess/bots";
import { BotAvatar } from "./BotAvatar";
import { TERMINATION_TEXT, type Termination } from "@/lib/chess/gameEnd";
import { BONUS } from "@/lib/chess/points";
import { rankFor } from "@/lib/chess/ranks";
import { UserAvatar, NameWithFlair } from "./UserAvatar";
import { wallet } from "@/lib/server/wallet";

function pct(n: number, d: number) {
  return d ? `${Math.round((n / d) * 100)}%` : "–";
}

/** Profile body shared by /profile (own, with review links) and /u/[username] (public). */
export async function ProfileView({ userId, own, action }: { userId: string; own: boolean; action?: React.ReactNode }) {
  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) return null;
  const [games, analyses, sums] = await Promise.all([
    prisma.game.findMany({ where: { userId }, orderBy: { createdAt: "desc" }, take: own ? 100 : 20 }),
    own ? prisma.analysis.findMany({ where: { userId }, orderBy: { createdAt: "desc" }, take: 50, select: { id: true, title: true, depth: true, createdAt: true } }) : Promise.resolve([]),
    prisma.game.aggregate({ where: { userId }, _sum: { points: true, bonusPoints: true }, _count: { _all: true } }),
  ]);
  const all = await prisma.game.findMany({ where: { userId }, select: { outcome: true, botElo: true } });
  const total = sums._count._all;
  const w = await wallet(userId);
  const points = w.earned;
  const count = (o: string) => all.filter((g) => g.outcome === o).length;
  const overall = { w: count("win"), l: count("loss"), d: count("draw") };
  const bestWin = all.filter((g) => g.outcome === "win").reduce((m, g) => Math.max(m, g.botElo), 0);
  const perTier = TIERS.map((t) => {
    const gs = all.filter((g) => tierFor(g.botElo).name === t.name);
    return { tier: t, w: gs.filter((g) => g.outcome === "win").length, l: gs.filter((g) => g.outcome === "loss").length, d: gs.filter((g) => g.outcome === "draw").length };
  }).filter((r) => r.w + r.l + r.d > 0);
  const name = user.username ?? user.name ?? "Player";

  const stat = (label: string, value: React.ReactNode, cls = "") => (
    <div className="rounded-lg bg-panel-2 px-4 py-3">
      <dt className="text-xs text-muted">{label}</dt>
      <dd className={`text-2xl font-bold tabular-nums ${cls}`}>{value}</dd>
    </div>
  );

  return (
    <div className="space-y-6">
      <section className="card relative overflow-hidden">
                <div className="relative flex flex-wrap items-center gap-5">
          <UserAvatar name={name} icon={user.avatarIcon} size={80} className="rounded-xl text-4xl shadow-lg animate-pop" />
          <div className="min-w-0">
            <h1 className="truncate text-3xl font-extrabold"><NameWithFlair name={name} flair={user.flair} /></h1>
            <p className="mt-0.5 text-sm font-extrabold" style={{ color: rankFor(user.friendRating).color }}>{rankFor(user.friendRating).icon} {rankFor(user.friendRating).name} · {user.friendRating}</p>
            <p className="text-sm text-muted">Joined {user.createdAt.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}</p>
          </div>
          <div className="ml-auto flex items-center gap-3">
            {action}
            <div className="rounded-xl bg-gold-soft px-5 py-3 text-center">
              <div className="text-xs font-bold uppercase tracking-wider text-gold">Points earned</div>
              <div className="text-3xl font-extrabold tabular-nums text-gold">◆ {points.toLocaleString()}</div>
              {own && <div className="text-xs font-bold text-muted">{w.balance.toLocaleString()} to spend</div>}
            </div>
          </div>
        </div>
        <dl className="relative mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {stat("Games", total)}
          {stat("Wins", overall.w, "text-ok")}
          {stat("Losses", overall.l, "text-bad")}
          {stat("Draws", overall.d)}
          {stat("Best win", bestWin ? bestWin : "–", "text-accent")}
          {stat("Puzzle rating", user.puzzleRating)}
        </dl>
      </section>

      <div className="grid gap-6 lg:grid-cols-[1fr_2fr]">
        <div className="space-y-6">
          <section className="card" aria-labelledby="perbot">
            <h2 id="perbot" className="mb-3 font-semibold">Record by level</h2>
            {perTier.length === 0 ? (
              <p className="text-sm text-muted">No games yet.{own && <> <Link href="/play" className="text-accent hover:underline">Play a bot</Link>.</>}</p>
            ) : (
              <ul className="space-y-2">
                {perTier.map((r) => {
                  const n = r.w + r.l + r.d;
                  return (
                    <li key={r.tier.name} className="text-sm">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{r.tier.name}</span>
                        <span className="text-xs text-muted">{r.w}W {r.l}L {r.d}D · {pct(r.w + r.d / 2, n)}</span>
                      </div>
                      <div className="mt-1 flex h-2 overflow-hidden rounded-full bg-panel-2" aria-hidden>
                        <span className="bg-ok" style={{ width: `${(r.w / n) * 100}%` }} />
                        <span className="bg-muted/50" style={{ width: `${(r.d / n) * 100}%` }} />
                        <span className="bg-bad" style={{ width: `${(r.l / n) * 100}%` }} />
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </section>
          {own && (
            <section className="card text-sm" aria-labelledby="how-points">
              <h2 id="how-points" className="mb-2 font-semibold">How points work</h2>
              <ul className="space-y-1 text-muted">
                <li>Win: bot Elo ÷ 10 (a 2000 bot = <span className="font-bold text-gold">+200 ◆</span>)</li>
                <li>Draw: half of that</li>
                <li>Review a game for a one-time bonus: Brilliant +{BONUS.brilliant}, Great +{BONUS.great}, Best +{BONUS.best}</li>
                <li>Solve a puzzle first try: puzzle rating ÷ 100</li>
              </ul>
            </section>
          )}
        </div>

        <section className="card" aria-labelledby="history">
          <h2 id="history" className="mb-3 font-semibold">{own ? "Your games" : "Recent games"}</h2>
          {games.length === 0 ? (
            <p className="text-sm text-muted">{own ? "Finished games appear here automatically." : "No games yet."}</p>
          ) : (
            <ul className="divide-y divide-line">
              {games.map((g, i) => {
                const bot = botForElo(g.botElo);
                const moves = Math.ceil(g.moveCount / 2);
                const pts = g.points + (g.bonusPoints ?? 0);
                return (
                  <li key={g.id} className="flex flex-wrap items-center gap-3 py-2.5 text-sm animate-fade-up" style={{ animationDelay: `${Math.min(i, 10) * 30}ms` }}>
                    <span className={`w-14 rounded-lg px-1.5 py-1 text-center text-xs font-bold ${g.outcome === "win" ? "bg-ok/15 text-ok" : g.outcome === "loss" ? "bg-bad/15 text-bad" : "bg-panel-2 text-muted"}`}>
                      {g.outcome === "win" ? "WIN" : g.outcome === "loss" ? "LOSS" : "DRAW"}
                    </span>
                    <BotAvatar bot={bot} size={28} />
                    <span className="min-w-0 flex-1">
                      <span className="font-medium">{bot.name} {g.botElo}</span>
                      <span className="block text-xs text-muted">
                        {g.userColor === "w" ? "White" : "Black"} · {TERMINATION_TEXT[g.termination as Termination] ?? g.termination} · {moves} {moves === 1 ? "move" : "moves"} · {g.timeControl === "unlimited" ? "∞" : g.timeControl} · {g.createdAt.toLocaleDateString()}
                      </span>
                    </span>
                    {pts > 0 && <span className="text-xs font-bold text-gold">+{pts} ◆</span>}
                    {own && <Link href={`/review?game=${g.id}`} className="btn py-1 text-xs">{g.review ? "Review ✓" : "Review"}</Link>}
                  </li>
                );
              })}
            </ul>
          )}
        </section>
      </div>

      {own && analyses.length > 0 && (
        <section className="card" aria-labelledby="saved">
          <h2 id="saved" className="mb-3 font-semibold">Saved analyses</h2>
          <ul className="divide-y divide-line">
            {analyses.map((a) => (
              <li key={a.id} className="flex items-center gap-3 py-2 text-sm">
                <span className="min-w-0 flex-1 truncate">{a.title}</span>
                <span className="text-xs text-muted">depth {a.depth} · {a.createdAt.toLocaleDateString()}</span>
                <Link href={`/review?analysis=${a.id}`} className="btn py-1 text-xs">Open</Link>
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}
