"use client";

import { Chessboard } from "react-chessboard";
import { useEffect, useRef, useState } from "react";

/** Small read-only board that fills its container's width. */
export function MiniBoard({ fen, orientation = "white", label }: { fen: string; orientation?: "white" | "black"; label?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [w, setW] = useState(0);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ro = new ResizeObserver(([e]) => setW(Math.floor(e.contentRect.width)));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return (
    <div ref={ref} className="pointer-events-none aspect-square w-full overflow-hidden rounded-t-xl" role="img" aria-label={label ?? "Chess position"}>
      {w > 0 && (
        <Chessboard
          id={`mini-${fen}`}
          position={fen}
          boardWidth={w}
          boardOrientation={orientation}
          arePiecesDraggable={false}
          showBoardNotation={false}
          animationDuration={0}
          customDarkSquareStyle={{ backgroundColor: "var(--board-dark)" }}
          customLightSquareStyle={{ backgroundColor: "var(--board-light)" }}
        />
      )}
    </div>
  );
}
