"use client";

import { useState } from "react";
import { notifyPointsChanged } from "@/lib/client/useMe";

export function AddFriendButton({ username, initial }: { username: string; initial: "none" | "friends" | "sent" | "received" }) {
  const [state, setState] = useState(initial);
  const [error, setError] = useState("");
  if (state === "friends") return <span className="rounded-full bg-ok/15 px-3 py-1.5 text-sm font-semibold text-ok">✓ Friends</span>;
  if (state === "sent") return <span className="rounded-full bg-panel-2 px-3 py-1.5 text-sm text-muted">Request sent</span>;
  return (
    <div className="text-right">
      <button
        type="button"
        className="btn-primary"
        onClick={async () => {
          setError("");
          const res = await fetch("/api/friends", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username }) });
          const j = await res.json().catch(() => ({}));
          if (!res.ok) return setError(j.error ?? "Something went wrong.");
          setState(j.status === "accepted" ? "friends" : "sent");
          notifyPointsChanged();
        }}
      >
        {state === "received" ? "Accept friend request" : "+ Add friend"}
      </button>
      {error && <p className="mt-1 text-xs text-bad">{error}</p>}
    </div>
  );
}
