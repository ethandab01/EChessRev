/** Small inline icon set (stroke icons, currentColor). */
type P = { size?: number; className?: string };
const base = (size: number) => ({ width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round" as const, strokeLinejoin: "round" as const, "aria-hidden": true });

export const IconPlay = ({ size = 22, className }: P) => (
  <svg {...base(size)} className={className}><circle cx="12" cy="6" r="3" /><path d="M9.5 9.5 8 15h8l-1.5-5.5M6 20h12M7 17.5h10" /></svg>
);
export const IconPuzzle = ({ size = 22, className }: P) => (
  <svg {...base(size)} className={className}><path d="M4 8h3a2 2 0 1 1 4 0h3v3a2 2 0 1 1 0 4v3H4v-3a2 2 0 1 0 0-4z" /><path d="M14 8V4h6v6h-3" /></svg>
);
export const IconReview = ({ size = 22, className }: P) => (
  <svg {...base(size)} className={className}><circle cx="10.5" cy="10.5" r="6.5" /><path d="m20 20-4.8-4.8M8 10.5l1.8 1.8 3.4-3.6" /></svg>
);
export const IconAnalyze = ({ size = 22, className }: P) => (
  <svg {...base(size)} className={className}><path d="M4 20V10M10 20V4M16 20v-7M22 20H2" /></svg>
);
export const IconFriends = ({ size = 22, className }: P) => (
  <svg {...base(size)} className={className}><circle cx="9" cy="8" r="3.5" /><path d="M2.5 20a6.5 6.5 0 0 1 13 0" /><circle cx="17" cy="9" r="2.5" /><path d="M17.5 14.5A5 5 0 0 1 22 19.5" /></svg>
);
export const IconUser = ({ size = 22, className }: P) => (
  <svg {...base(size)} className={className}><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></svg>
);
export const IconSun = ({ size = 20, className }: P) => (
  <svg {...base(size)} className={className}><circle cx="12" cy="12" r="4" /><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" /></svg>
);
export const IconMoon = ({ size = 20, className }: P) => (
  <svg {...base(size)} className={className}><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z" /></svg>
);
export const IconLogout = ({ size = 20, className }: P) => (
  <svg {...base(size)} className={className}><path d="M15 4h4v16h-4M10 8l-4 4 4 4M6 12h10" /></svg>
);
export const IconFlame = ({ size = 18, className }: P) => (
  <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden className={className}><path fill="#f97316" d="M12 2s5 4.5 5 10a5 5 0 0 1-10 0c0-2.4 1.2-4 2.4-5.3.1 2 .9 3.3 2.1 3.8C11 7.8 12 2 12 2z" /><path fill="#fbbf24" d="M12 12.5s2.5 1.7 2.5 4a2.5 2.5 0 0 1-5 0c0-1.5 1-2.7 2.5-4z" /></svg>
);
export const IconChevron = ({ size = 20, className, dir = "right" }: P & { dir?: "left" | "right" }) => (
  <svg {...base(size)} className={className}><path d={dir === "right" ? "m9 6 6 6-6 6" : "m15 6-6 6 6 6"} /></svg>
);
export const IconShop = ({ size = 22, className }: P) => (
  <svg {...base(size)} className={className}><path d="M4 7h16l-1.5 12.5a1.5 1.5 0 0 1-1.5 1.3H7a1.5 1.5 0 0 1-1.5-1.3z" /><path d="M9 10V6a3 3 0 0 1 6 0v4" /></svg>
);
