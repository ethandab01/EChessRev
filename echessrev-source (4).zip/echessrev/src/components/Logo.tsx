export function Logo({ size = 30 }: { size?: number }) {
  return (
    <svg aria-hidden width={size} height={size} viewBox="0 0 32 32">
      <rect width="32" height="32" rx="8" fill="var(--accent)" />
      <path d="M16 6.5a3 3 0 0 1 1.9 5.3l1.6 5.2h-7l1.6-5.2A3 3 0 0 1 16 6.5z" fill="#fff" />
      <rect x="10" y="18.5" width="12" height="2.6" rx="1.3" fill="#fff" />
      <rect x="8.5" y="22.5" width="15" height="3.2" rx="1.6" fill="#fff" />
    </svg>
  );
}
