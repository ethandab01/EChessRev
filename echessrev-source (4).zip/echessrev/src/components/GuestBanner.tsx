"use client";

import Link from "next/link";
import { useSession } from "next-auth/react";

export function GuestBanner({ what = "games" }: { what?: string }) {
  const { status } = useSession();
  if (status !== "unauthenticated") return null;
  return (
    <div role="status" className="mb-3 flex flex-wrap items-center gap-1.5 text-sm text-muted">
      <span>Guest mode — your {what} won&apos;t be saved.</span>
      <Link href="/login" className="text-accent hover:underline">Sign in to keep them</Link>
    </div>
  );
}
