import NextAuth, { CredentialsSignin, type NextAuthConfig } from "next-auth";
import Credentials from "next-auth/providers/credentials";
import Google from "next-auth/providers/google";
import { PrismaAdapter } from "@auth/prisma-adapter";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "@/lib/server/db";
import { clientIp, envInt, rateLimit } from "@/lib/server/rateLimit";

export const googleEnabled = Boolean(process.env.AUTH_GOOGLE_ID && process.env.AUTH_GOOGLE_SECRET);

class RateLimitedError extends CredentialsSignin {
  code = "rate_limited";
}
class InvalidLoginError extends CredentialsSignin {
  code = "invalid_credentials";
}

const credentialsSchema = z.object({
  /** Email address or username. */
  email: z.string().trim().min(1).max(200),
  password: z.string().min(1).max(200),
});

/** Derive a unique username for OAuth sign-ups. */
async function uniqueUsername(seed: string): Promise<string> {
  const base = (seed.split("@")[0] || "player").replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 16) || "player";
  for (let i = 0; i < 50; i++) {
    const candidate = i === 0 ? base : `${base}${Math.floor(Math.random() * 10000)}`;
    const exists = await prisma.user.findUnique({ where: { username: candidate } });
    if (!exists) return candidate;
  }
  return `${base}${Date.now().toString(36)}`;
}

// In local development, fall back to a fixed secret so sign-in works without setup.
// Production must set AUTH_SECRET.
const secret = process.env.AUTH_SECRET || (process.env.NODE_ENV !== "production" ? "echessrev-local-dev-secret-not-for-production" : undefined);

export const authConfig: NextAuthConfig = {
  secret,
  adapter: PrismaAdapter(prisma),
  session: { strategy: "jwt" },
  pages: { signIn: "/login" },
  providers: [
    Credentials({
      name: "Email and password",
      credentials: { email: { label: "Email", type: "email" }, password: { label: "Password", type: "password" } },
      async authorize(raw, request) {
        const parsed = credentialsSchema.safeParse(raw);
        if (!parsed.success) throw new InvalidLoginError();
        const { password } = parsed.data;
        const identifier = parsed.data.email;
        const email = identifier.toLowerCase();
        const ip = request instanceof Request ? clientIp(request.headers) : "unknown";
        const limit = envInt("RATE_LIMIT_SIGNIN", 10);
        if (!rateLimit(`signin:${ip}:${email}`, limit, 15 * 60_000).ok || !rateLimit(`signin-ip:${ip}`, limit * 5, 15 * 60_000).ok) {
          throw new RateLimitedError();
        }
        const user = identifier.includes("@")
          ? await prisma.user.findUnique({ where: { email } })
          : await prisma.user.findUnique({ where: { username: identifier } });
        if (!user?.passwordHash) throw new InvalidLoginError();
        const ok = await bcrypt.compare(password, user.passwordHash);
        if (!ok) throw new InvalidLoginError();
        return { id: user.id, email: user.email, name: user.username ?? user.name, image: user.image };
      },
    }),
    ...(googleEnabled ? [Google({ allowDangerousEmailAccountLinking: false })] : []),
  ],
  events: {
    async createUser({ user }) {
      if (!user.id) return;
      const u = await prisma.user.findUnique({ where: { id: user.id } });
      if (u && !u.username) {
        await prisma.user.update({ where: { id: u.id }, data: { username: await uniqueUsername(u.email) } });
      }
    },
  },
  callbacks: {
    async jwt({ token, user }) {
      if (user?.id) token.uid = user.id;
      if (token.uid && !token.username) {
        const u = await prisma.user.findUnique({ where: { id: token.uid as string }, select: { username: true } });
        token.username = u?.username ?? null;
      }
      return token;
    },
    async session({ session, token }) {
      if (token.uid) session.user.id = token.uid as string;
      session.user.username = (token.username as string | null | undefined) ?? null;
      return session;
    },
  },
};

export const { handlers, auth, signIn, signOut } = NextAuth(authConfig);
