import "server-only";
import crypto from "node:crypto";
import type { Seek } from "@prisma/client";
import { prisma } from "./db";
import { getTimeControl } from "@/lib/chess/bots";

/** A seek is alive while its owner's page keeps pinging it. */
export const SEEK_TTL_MS = 15_000;

export function aliveSince() {
  return new Date(Date.now() - SEEK_TTL_MS);
}

/** Remove abandoned seeks (owner closed the tab). */
export async function sweepSeeks() {
  await prisma.seek.deleteMany({ where: { gameId: null, lastPing: { lt: new Date(Date.now() - 60_000) } } });
}

/**
 * Claim `seek` for `joinerId` and create the game. Returns the game id, or null if someone else
 * claimed it first.
 */
export async function claimSeek(seek: Seek, joinerId: string): Promise<string | null> {
  if (seek.userId === joinerId) return null;
  const gameId = crypto.randomBytes(12).toString("hex");
  const res = await prisma.seek.updateMany({ where: { id: seek.id, gameId: null }, data: { gameId } });
  if (res.count === 0) return null;
  const tc = getTimeControl(seek.timeControl);
  const ms = tc.initial ? tc.initial * 1000 : null;
  const seekerWhite = Math.random() < 0.5;
  await prisma.friendGame.create({
    data: {
      id: gameId,
      kind: "online",
      status: "active",
      whiteId: seekerWhite ? seek.userId : joinerId,
      blackId: seekerWhite ? joinerId : seek.userId,
      challengerId: seek.userId,
      timeControl: seek.timeControl,
      rated: seek.rated,
      whiteMs: ms,
      blackMs: ms,
    },
  });
  // The joiner's own open seeks are no longer needed.
  await prisma.seek.deleteMany({ where: { userId: joinerId, gameId: null } });
  return gameId;
}
