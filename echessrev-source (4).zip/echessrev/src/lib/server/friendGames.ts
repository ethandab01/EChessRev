import "server-only";
import { Chess } from "chess.js";
import type { FriendGame, User } from "@prisma/client";
import { prisma } from "./db";
import { getTimeControl } from "@/lib/chess/bots";
import { detectGameEnd, timeoutResult, type GameOver } from "@/lib/chess/gameEnd";
import { eloDeltas } from "@/lib/chess/ranks";

type PlayerRow = Pick<User, "id" | "username" | "friendRating" | "avatarIcon" | "flair">;
export type GameWithPlayers = FriendGame & { white: PlayerRow; black: PlayerRow };

export const playerSelect = { select: { id: true, username: true, friendRating: true, avatarIcon: true, flair: true } } as const;

export function replay(moves: string): Chess {
  const c = new Chess();
  for (const u of moves.split(" ").filter(Boolean)) c.move({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] });
  return c;
}

/** Clocks right now (the side to move's clock keeps running since lastMoveAt). */
export function liveClocks(g: FriendGame, now = Date.now()): { w: number; b: number } | null {
  if (g.whiteMs == null || g.blackMs == null) return null;
  const clocks = { w: g.whiteMs, b: g.blackMs };
  if (g.status === "active" && g.lastMoveAt) {
    const plies = g.moves.split(" ").filter(Boolean).length;
    const stm = plies % 2 === 0 ? "w" : "b";
    clocks[stm] -= now - g.lastMoveAt.getTime();
  }
  return clocks;
}

/** Finish a game exactly once: sets the result and applies rating changes (rated games with ≥ 2 plies). */
export async function finishGame(g: GameWithPlayers, over: GameOver, clocks?: { w: number; b: number } | null) {
  const plies = g.moves.split(" ").filter(Boolean).length;
  const score = over.result === "1-0" ? 1 : over.result === "0-1" ? 0 : 0.5;
  const rated = g.rated && plies >= 2;
  const d = rated ? eloDeltas(g.white.friendRating, g.black.friendRating, score) : { white: 0, black: 0 };
  await prisma.$transaction(async (tx) => {
    const res = await tx.friendGame.updateMany({
      where: { id: g.id, status: "active" },
      data: {
        status: "finished",
        result: over.result,
        termination: over.termination,
        drawOfferBy: null,
        whiteDelta: rated ? d.white : null,
        blackDelta: rated ? d.black : null,
        ...(clocks ? { whiteMs: Math.max(0, Math.round(clocks.w)), blackMs: Math.max(0, Math.round(clocks.b)) } : {}),
      },
    });
    if (res.count === 0 || !rated) return; // someone else already finished it
    await tx.user.update({ where: { id: g.whiteId }, data: { friendRating: { increment: d.white } } });
    await tx.user.update({ where: { id: g.blackId }, data: { friendRating: { increment: d.black } } });
  });
}

/** Load a game, ending it on time if the side to move has flagged. */
export async function loadGame(id: string): Promise<GameWithPlayers | null> {
  const g = await prisma.friendGame.findUnique({ where: { id }, include: { white: playerSelect, black: playerSelect } });
  if (!g) return null;
  if (g.status === "active") {
    const clocks = liveClocks(g);
    if (clocks) {
      const chess = replay(g.moves);
      const stm = chess.turn();
      if (clocks[stm] <= 0) {
        await finishGame(g, timeoutResult(chess, stm), clocks);
        return prisma.friendGame.findUnique({ where: { id }, include: { white: playerSelect, black: playerSelect } });
      }
    }
  }
  return g;
}

/** Public JSON for a game, from the viewer's perspective. */
export function serialize(g: GameWithPlayers, viewerId: string) {
  const chess = replay(g.moves);
  return {
    id: g.id,
    status: g.status,
    kind: g.kind,
    timeControl: g.timeControl,
    rated: g.rated,
    moves: g.moves.split(" ").filter(Boolean),
    fen: chess.fen(),
    turn: chess.turn(),
    clocks: liveClocks(g),
    clockRunning: g.status === "active" && !!g.lastMoveAt,
    white: { id: g.white.id, username: g.white.username, rating: g.white.friendRating, avatarIcon: g.white.avatarIcon, flair: g.white.flair },
    black: { id: g.black.id, username: g.black.username, rating: g.black.friendRating, avatarIcon: g.black.avatarIcon, flair: g.black.flair },
    youAre: viewerId === g.whiteId ? ("w" as const) : viewerId === g.blackId ? ("b" as const) : null,
    challengerId: g.challengerId,
    drawOfferBy: g.drawOfferBy === g.whiteId ? "w" : g.drawOfferBy === g.blackId ? "b" : null,
    result: g.result,
    termination: g.termination,
    deltas: g.whiteDelta == null ? null : { w: g.whiteDelta, b: g.blackDelta ?? 0 },
    updatedAt: g.updatedAt.toISOString(),
  };
}

/** Apply a move with optimistic concurrency on the move list. */
export async function playMove(g: GameWithPlayers, userId: string, uci: string, expectedPly: number): Promise<{ error?: string; status?: number }> {
  if (g.status !== "active") return { error: "This game is over.", status: 409 };
  const color = userId === g.whiteId ? "w" : userId === g.blackId ? "b" : null;
  if (!color) return { error: "You're not playing in this game.", status: 403 };
  const chess = replay(g.moves);
  const plies = chess.history().length;
  if (plies !== expectedPly) return { error: "The position changed — refreshing.", status: 409 };
  if (chess.turn() !== color) return { error: "It's not your turn.", status: 409 };
  try {
    chess.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), promotion: uci[4] });
  } catch {
    return { error: "Illegal move.", status: 400 };
  }
  const now = Date.now();
  let whiteMs = g.whiteMs;
  let blackMs = g.blackMs;
  const tc = getTimeControl(g.timeControl);
  if (whiteMs != null && blackMs != null && g.lastMoveAt) {
    const left = (color === "w" ? whiteMs : blackMs) - (now - g.lastMoveAt.getTime());
    if (left <= 0) {
      await finishGame(g, timeoutResult(replay(g.moves), color), { w: color === "w" ? 0 : whiteMs, b: color === "b" ? 0 : blackMs });
      return { error: "Your time ran out.", status: 409 };
    }
    if (color === "w") whiteMs = left + tc.increment * 1000;
    else blackMs = left + tc.increment * 1000;
  }
  const newMoves = (g.moves ? g.moves + " " : "") + uci;
  const res = await prisma.friendGame.updateMany({
    where: { id: g.id, status: "active", moves: g.moves },
    // The clock starts after White's first move.
    data: { moves: newMoves, whiteMs, blackMs, lastMoveAt: whiteMs != null ? new Date(now) : null, drawOfferBy: null },
  });
  if (res.count === 0) return { error: "The position changed — refreshing.", status: 409 };
  const over = detectGameEnd(chess);
  if (over) {
    const fresh = await prisma.friendGame.findUnique({ where: { id: g.id }, include: { white: playerSelect, black: playerSelect } });
    if (fresh) await finishGame(fresh, over);
  }
  return {};
}
