import "server-only";
import rows from "@/data/puzzles.json";
import { rowToPuzzle, type Puzzle, type PuzzleRow } from "@/lib/chess/puzzles";

/** Puzzle rows sorted by rating (built by scripts/build-puzzles.mjs). Server-only: ~1 MB. */
const PUZZLES = (rows as unknown as PuzzleRow[]).map(rowToPuzzle);
const BY_ID = new Map(PUZZLES.map((p) => [p.id, p]));

export function getPuzzle(id: string): Puzzle | undefined {
  return BY_ID.get(id);
}

/** Random puzzle near `rating`, skipping excluded ids; widens the window if needed. */
export function pickPuzzle(rating: number, exclude: Set<string>, theme?: string): Puzzle | undefined {
  for (const window of [100, 200, 400, 800, 3000]) {
    const pool = PUZZLES.filter((p) => Math.abs(p.rating - rating) <= window && !exclude.has(p.id) && (!theme || p.themes.includes(theme)));
    if (pool.length) return pool[Math.floor(Math.random() * pool.length)];
  }
  return undefined;
}

export const PUZZLE_COUNT = PUZZLES.length;
