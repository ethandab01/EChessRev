import "server-only";
import { prisma } from "./db";
import { pointsFor } from "./points";

/** Lifetime earned points, total spent in the shop, and the spendable balance. */
export async function wallet(userId: string) {
  const [earned, spentAgg] = await Promise.all([
    pointsFor([userId]).then((m) => m.get(userId) ?? 0),
    prisma.purchase.aggregate({ where: { userId }, _sum: { price: true } }),
  ]);
  const spent = spentAgg._sum.price ?? 0;
  return { earned, spent, balance: earned - spent };
}
