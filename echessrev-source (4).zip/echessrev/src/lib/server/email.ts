import "server-only";

/**
 * Sends email through Resend's HTTP API (https://resend.com) when RESEND_API_KEY is set.
 * Without it (local development) the message is printed to the server console instead.
 */
export async function sendEmail(opts: { to: string; subject: string; html: string; text: string }): Promise<void> {
  const key = process.env.RESEND_API_KEY;
  const from = process.env.EMAIL_FROM || "EChessREV <onboarding@resend.dev>";
  if (!key) {
    console.log(`\n[email] (RESEND_API_KEY not set — printing instead)\nTo: ${opts.to}\nSubject: ${opts.subject}\n\n${opts.text}\n`);
    return;
  }
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from, to: [opts.to], subject: opts.subject, html: opts.html, text: opts.text }),
  });
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    console.error(`[email] Resend error ${res.status}: ${body}`);
    throw new Error("Email could not be sent.");
  }
}

/** Public base URL of the site, for links in emails. */
export function siteUrl(req: Request): string {
  const env = process.env.APP_URL || process.env.AUTH_URL;
  if (env) return env.replace(/\/$/, "");
  return new URL(req.url).origin;
}
