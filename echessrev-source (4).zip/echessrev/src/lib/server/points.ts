import { prisma } from "./db";

/** Total points for a set of users: game results + review bonuses + puzzles. */
export async function pointsFor(userIds: string[]): Promise<Map<string, number>> {
  const rows = await prisma.game.groupBy({
    by: ["userId"],
    where: { userId: { in: userIds } },
    _sum: { points: true, bonusPoints: true },
  });
  const puzzleRows = await prisma.puzzleAttempt.groupBy({
    by: ["userId"],
    where: { userId: { in: userIds } },
    _sum: { points: true },
  });
  const out = new Map<string, number>(userIds.map((id) => [id, 0]));
  for (const r of rows) out.set(r.userId, (r._sum.points ?? 0) + (r._sum.bonusPoints ?? 0));
  for (const r of puzzleRows) out.set(r.userId, (out.get(r.userId) ?? 0) + (r._sum.points ?? 0));
  return out;
}

export async function userPoints(userId: string): Promise<number> {
  return (await pointsFor([userId])).get(userId) ?? 0;
}
