import { Chess, type Move } from "chess.js";
import { classifyMove, moveToUci, positionWinPct, type PositionEval, type Terminal } from "@/lib/chess/classify";
import { explainMove, pvToSan, uciToSan } from "@/lib/chess/coach";
import { gameAccuracy, estimatePerformance } from "@/lib/chess/accuracy";
import { bookPlies, detectOpening, type Opening } from "@/lib/chess/openings";
import { scoreToWhiteCp } from "@/lib/chess/winpct";
import type { Classification } from "@/lib/chess/types";
import { CLASSIFICATIONS } from "@/lib/chess/types";

export const REVIEW_VERSION = 4;

export interface ReviewMove {
  ply: number;
  san: string;
  uci: string;
  from: string;
  to: string;
  color: "w" | "b";
  fenBefore: string;
  fenAfter: string;
  classification: Classification;
  epl: number;
  /** Mover's win% before (best play) and after the move. */
  winBefore: number;
  winAfter: number;
  accuracy: number;
  bestUci: string | null;
  bestSan: string | null;
  /** Engine's best line from the position before the move, in SAN. */
  bestLineSan: string[];
  coach: string;
  reason: string;
}

export interface GameReview {
  version: number;
  depth: number;
  startFen: string;
  headers: Record<string, string>;
  result: string;
  opening: Opening | null;
  moves: ReviewMove[];
  positions: PositionEval[];
  /** White's win% at each position (length = moves + 1). */
  whiteWinPcts: number[];
  /** White-perspective centipawns at each position (mate ≈ ±10000). */
  evalWhiteCp: number[];
  accuracy: { w: number; b: number };
  rating: { w: number; b: number };
  counts: { w: Record<Classification, number>; b: Record<Classification, number> };
  /** Average centipawn loss per side (non-book, non-forced moves; evals capped at ±1000). */
  acpl: { w: number; b: number };
  bookSkipped: boolean;
}

export function terminalOf(fen: string): Terminal | undefined {
  const c = new Chess(fen);
  if (c.isCheckmate()) return "checkmate";
  if (c.isStalemate()) return "stalemate";
  if (c.isInsufficientMaterial()) return "draw";
  return undefined;
}

function emptyCounts(): Record<Classification, number> {
  return Object.fromEntries(CLASSIFICATIONS.map((c) => [c, 0])) as Record<Classification, number>;
}

/** Positions shorter than this many full moves skip book detection (as do custom-FEN games). */
export const MIN_MOVES_FOR_BOOK = 5;

/**
 * Turn per-position engine evaluations into a full review.
 * @param positions engine data for every position (length = moves.length + 1)
 */
export function buildReview(opts: {
  startFen: string;
  moves: Array<Pick<Move, "from" | "to" | "promotion" | "color" | "san" | "captured" | "piece">>;
  positions: PositionEval[];
  headers?: Record<string, string>;
  result?: string;
  depth: number;
  customStart?: boolean;
}): GameReview {
  const { moves, positions, startFen } = opts;
  if (positions.length !== moves.length + 1) {
    throw new Error(`Expected ${moves.length + 1} position evaluations, got ${positions.length}`);
  }
  const fensAfter = positions.slice(1).map((p) => p.fen);
  const bookSkipped = !!opts.customStart || moves.length < MIN_MOVES_FOR_BOOK * 2;
  const nBook = bookSkipped ? 0 : bookPlies(fensAfter);
  const opening = opts.customStart ? null : detectOpening(fensAfter);

  const whiteWinPcts = positions.map((p) => {
    const stm = new Chess(p.fen).turn();
    const w = positionWinPct(p);
    return stm === "w" ? w : 100 - w;
  });
  const evalWhiteCp = positions.map((p) => {
    const stm = new Chess(p.fen).turn();
    if (p.terminal === "checkmate") return stm === "w" ? -10000 : 10000;
    if (p.terminal) return 0;
    return p.lines[0] ? scoreToWhiteCp(p.lines[0].score, stm) : 0;
  });
  const firstMover = new Chess(startFen).turn();
  const acc = gameAccuracy(whiteWinPcts, firstMover);

  const counts = { w: emptyCounts(), b: emptyCounts() };
  const reviewMoves: ReviewMove[] = [];
  let prevClass: Classification | undefined;
  moves.forEach((m, i) => {
    const before = positions[i];
    const after = positions[i + 1];
    const prevMoverWinPct = i >= 1 ? 100 - positionWinPct(positions[i - 1]) : undefined;
    const r = classifyMove({
      before,
      after,
      move: m,
      inBook: i < nBook,
      prevClassification: prevClass,
      prevMoverWinPct,
    });
    const coach = explainMove({
      classification: r.classification,
      san: m.san,
      before,
      after,
      move: m,
      openingName: opening?.name,
      sacrifice: r.sacrifice,
    });
    const bestUci = before.lines[0]?.pv[0] ?? null;
    reviewMoves.push({
      ply: i + 1,
      san: m.san,
      uci: moveToUci(m),
      from: m.from,
      to: m.to,
      color: m.color,
      fenBefore: before.fen,
      fenAfter: after.fen,
      classification: r.classification,
      epl: r.epl,
      winBefore: r.winBefore,
      winAfter: r.winAfter,
      accuracy: acc.moves[i] ?? 0,
      bestUci,
      bestSan: bestUci ? uciToSan(before.fen, bestUci) : null,
      bestLineSan: before.lines[0] ? pvToSan(before.fen, before.lines[0].pv, 10) : [],
      coach: coach.text,
      reason: coach.reason,
    });
    counts[m.color][r.classification]++;
    prevClass = r.classification;
  });

  // Average centipawn loss per side, over "real" decisions only.
  const capCp = (p: PositionEval, mover: boolean): number => {
    // Score of position p from the perspective of the side to move (mover=true) or the other side.
    let v: number;
    if (p.terminal === "checkmate") v = -1000;
    else if (p.terminal) v = 0;
    else {
      const s = p.lines[0]?.score;
      v = !s ? 0 : s.mate !== undefined ? (s.mate > 0 ? 1000 : -1000) : Math.max(-1000, Math.min(1000, s.cp ?? 0));
    }
    return mover ? v : -v;
  };
  const loss = { w: [] as number[], b: [] as number[] };
  reviewMoves.forEach((m, i) => {
    if (m.classification === "book" || m.classification === "forced") return;
    const before = capCp(positions[i], true);
    const after = capCp(positions[i + 1], false);
    loss[m.color].push(Math.max(0, before - after));
  });
  const avg = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 0);
  const acpl = { w: Math.round(avg(loss.w)), b: Math.round(avg(loss.b)) };

  return {
    version: REVIEW_VERSION,
    depth: opts.depth,
    startFen,
    headers: opts.headers ?? {},
    result: opts.result ?? "*",
    opening,
    moves: reviewMoves,
    positions,
    whiteWinPcts,
    evalWhiteCp,
    accuracy: { w: round1(acc.white), b: round1(acc.black) },
    rating: {
      w: estimatePerformance({ accuracy: acc.white, acpl: acpl.w, moves: loss.w.length }),
      b: estimatePerformance({ accuracy: acc.black, acpl: acpl.b, moves: loss.b.length }),
    },
    counts,
    acpl,
    bookSkipped,
  };
}

function round1(x: number) {
  return Math.round(x * 10) / 10;
}
