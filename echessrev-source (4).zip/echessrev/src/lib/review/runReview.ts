"use client";

import { Chess } from "chess.js";
import type { StockfishEngine } from "@/lib/engine/engine";
import type { PositionEval } from "@/lib/chess/classify";
import type { ParsedGame } from "@/lib/chess/pgn";
import { cacheGet, cacheSet, hashString } from "@/lib/client/cache";
import { buildReview, REVIEW_VERSION, terminalOf, type GameReview } from "./buildReview";

export function reviewCacheKey(game: Pick<ParsedGame, "startFen" | "moves">, depth: number) {
  const moves = game.moves.map((m) => `${m.from}${m.to}${m.promotion ?? ""}`).join(" ");
  return `review:v${REVIEW_VERSION}:d${depth}:${hashString(game.startFen + "|" + moves)}`;
}

export async function getCachedReview(game: ParsedGame, depth: number): Promise<GameReview | undefined> {
  const r = await cacheGet<GameReview>(reviewCacheKey(game, depth));
  return r && r.version === REVIEW_VERSION ? r : undefined;
}

export async function storeCachedReview(game: ParsedGame, review: GameReview) {
  await cacheSet(reviewCacheKey(game, review.depth), review);
}

/**
 * Analyse every position of a game at `depth` (MultiPV 2, full strength) and build the review.
 * Results are cached in IndexedDB so reopening is instant.
 */
export async function runReview(
  engine: StockfishEngine,
  game: ParsedGame,
  opts: { depth: number; signal?: AbortSignal; onProgress?: (done: number, total: number) => void },
): Promise<GameReview> {
  const cached = await getCachedReview(game, opts.depth);
  if (cached) {
    opts.onProgress?.(1, 1);
    return cached;
  }
  const fens = [game.startFen, ...game.fens];
  const positions: PositionEval[] = [];
  await engine.newGame();
  for (let i = 0; i < fens.length; i++) {
    const fen = fens[i];
    const terminal = terminalOf(fen);
    if (terminal) {
      positions.push({ fen, lines: [], terminal });
    } else {
      const legal = new Chess(fen).moves().length;
      const res = await engine.search(fen, {
        depth: opts.depth,
        multipv: Math.min(2, legal),
        signal: opts.signal,
        configure: (e) => e.setFullStrength(),
      });
      positions.push({ fen, lines: res.lines.map((l) => ({ ...l, pv: l.pv.slice(0, 12) })) });
    }
    opts.onProgress?.(i + 1, fens.length);
  }
  const review = buildReview({
    startFen: game.startFen,
    moves: game.moves,
    positions,
    headers: game.headers,
    result: game.result,
    depth: opts.depth,
    customStart: game.customStart,
  });
  await storeCachedReview(game, review);
  return review;
}
