/** Friend-game rating (Elo) and the rank tiers shown for it. */
export const RANKS = [
  { min: 0, name: "Bronze", color: "#c27c48", icon: "🥉" },
  { min: 1100, name: "Silver", color: "#a9b4c2", icon: "🥈" },
  { min: 1300, name: "Gold", color: "#f2ab3c", icon: "🥇" },
  { min: 1500, name: "Platinum", color: "#5ec8c8", icon: "💠" },
  { min: 1700, name: "Diamond", color: "#7aa7ff", icon: "💎" },
  { min: 1900, name: "Champion", color: "#d36cf0", icon: "👑" },
];

export function rankFor(rating: number) {
  let r = RANKS[0];
  for (const x of RANKS) if (rating >= x.min) r = x;
  const idx = RANKS.indexOf(r);
  const next = RANKS[idx + 1];
  const progress = next ? Math.min(1, Math.max(0, (rating - r.min) / (next.min - r.min))) : 1;
  return { ...r, next: next ?? null, progress };
}

/**
 * Elo changes for both players after a game. score is White's score (1, 0.5, 0). K = 32.
 * Returns integer deltas that sum to zero.
 */
export function eloDeltas(white: number, black: number, score: 1 | 0.5 | 0, k = 32): { white: number; black: number } {
  const expected = 1 / (1 + 10 ** ((black - white) / 400));
  const d = Math.round(k * (score - expected));
  return { white: d, black: -d };
}
