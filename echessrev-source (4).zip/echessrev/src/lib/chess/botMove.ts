import { Chess } from "chess.js";
import type { EngineLine } from "./types";
import { scoreToWinPct } from "./winpct";

/** Stockfish's UCI_Elo lower/upper bounds (SF 17). */
export const UCI_ELO_MIN = 1320;
export const UCI_ELO_MAX = 3190;

export type BotStrength =
  | { mode: "full" }
  | { mode: "limit"; elo: number }
  | { mode: "weak"; depth: number; multipv: number; mistakeChance: number; temperature: number };

/**
 * Engine configuration for a bot rating.
 *  - Elo ≥ 3200 ("Max"): full strength.
 *  - Elo ≥ 1320: UCI_LimitStrength + UCI_Elo (clamped to Stockfish's 3190 maximum).
 *  - Elo < 1320: Skill Level 0, depth 1–4 scaled by Elo, MultiPV 5, weighted random choice,
 *    and an Elo-scaled chance (≈25% at 400 → ≈5% at 1200) to play a clearly inferior move.
 */
export function botStrength(elo: number): BotStrength {
  if (elo >= 3200) return { mode: "full" };
  if (elo >= UCI_ELO_MIN) return { mode: "limit", elo: Math.min(UCI_ELO_MAX, elo) };
  const t = Math.min(1, Math.max(0, (elo - 400) / 800)); // 0 at 400, 1 at 1200
  return {
    mode: "weak",
    depth: Math.min(4, Math.max(1, Math.round(1 + t * 3))),
    multipv: 5,
    mistakeChance: mistakeChance(elo),
    temperature: 8 - t * 5, // win% "temperature" for the softmax: 8 at 400, 3 at 1200
  };
}

/** Chance of a deliberate clearly-inferior move: 25% at 400 falling linearly to 5% at 1200. */
export function mistakeChance(elo: number): number {
  const t = Math.min(1, Math.max(0, (elo - 400) / 800));
  return 0.25 - t * 0.2;
}

export type Rng = () => number;

/**
 * Choose a move for a weak bot from MultiPV candidate lines.
 * @param lines engine lines (side-to-move perspective), best first
 * @param legalUci all legal moves in UCI
 */
export function pickWeakMove(
  lines: EngineLine[],
  legalUci: string[],
  opts: { mistakeChance: number; temperature: number },
  rng: Rng = Math.random,
): { move: string; deliberateMistake: boolean } {
  const candidates = lines.filter((l) => l.pv.length > 0);
  if (candidates.length === 0) return { move: legalUci[Math.floor(rng() * legalUci.length)], deliberateMistake: true };
  const bestWin = scoreToWinPct(candidates[0].score);

  if (legalUci.length > 1 && rng() < opts.mistakeChance) {
    // "Clearly inferior": a candidate at least 10 win% worse, else any legal move outside the top two.
    const inferior = candidates.filter((l) => bestWin - scoreToWinPct(l.score) >= 10).map((l) => l.pv[0]);
    const top2 = new Set(candidates.slice(0, 2).map((l) => l.pv[0]));
    const pool = inferior.length ? inferior : legalUci.filter((m) => !top2.has(m));
    if (pool.length) return { move: pool[Math.floor(rng() * pool.length)], deliberateMistake: true };
  }

  const weights = candidates.map((l) => Math.exp((scoreToWinPct(l.score) - bestWin) / opts.temperature));
  const total = weights.reduce((a, b) => a + b, 0);
  let r = rng() * total;
  for (let i = 0; i < candidates.length; i++) {
    r -= weights[i];
    if (r <= 0) return { move: candidates[i].pv[0], deliberateMistake: false };
  }
  return { move: candidates[0].pv[0], deliberateMistake: false };
}

/** Position complexity in 0..1 from move count, captures and checks available. */
export function positionComplexity(fen: string): number {
  const chess = new Chess(fen);
  const moves = chess.moves({ verbose: true });
  if (moves.length <= 1) return 0;
  const captures = moves.filter((m) => m.captured).length;
  const checks = moves.filter((m) => m.san.includes("+")).length;
  const raw = moves.length / 45 + captures / 8 + checks / 6 + (chess.inCheck() ? 0.2 : 0);
  return Math.min(1, raw / 2);
}

/**
 * Natural "thinking" delay between 0.4 s and 2.0 s scaled by complexity, shortened when the
 * bot's clock is low.
 */
export function thinkDelayMs(fen: string, opts: { remainingMs?: number | null; incrementMs?: number }, rng: Rng = Math.random): number {
  const c = positionComplexity(fen);
  let delay = 400 + 1600 * c * (0.75 + 0.25 * rng());
  if (opts.remainingMs != null) {
    const budget = timeBudgetMs(opts.remainingMs, opts.incrementMs ?? 0);
    delay = Math.min(delay, budget);
  }
  return Math.max(opts.remainingMs != null ? 50 : 400, Math.min(2000, delay));
}

/** Sensible per-move time budget for a clock: ~1/35 of remaining + most of the increment, never more than a third left. */
export function timeBudgetMs(remainingMs: number, incrementMs: number): number {
  const budget = remainingMs / 35 + incrementMs * 0.8;
  return Math.max(30, Math.min(budget, remainingMs / 3));
}

/** Bot accepts a draw only if the eval (centipawns, either perspective) is within ±0.5 and move 30 has passed. */
export function botAcceptsDraw(evalCp: number | null, mate: number | null | undefined, fullmoveNumber: number): boolean {
  if (fullmoveNumber <= 30) return false;
  if (mate != null) return false;
  if (evalCp == null) return false;
  return Math.abs(evalCp) <= 50;
}
