/**
 * Extract the 8-character Lichess game ID from a URL (or a bare ID).
 * Accepts https://lichess.org/abcdEFGH, /abcdEFGHijkl (12-char player URL), /abcdEFGH/black,
 * /game/export/abcdEFGH and similar.
 */
export function parseLichessGameId(input: string): string | null {
  const s = input.trim();
  if (/^[a-zA-Z0-9]{8}([a-zA-Z0-9]{4})?$/.test(s)) return s.slice(0, 8);
  let url: URL;
  try {
    url = new URL(s.startsWith("http") ? s : `https://${s}`);
  } catch {
    return null;
  }
  if (!/(^|\.)lichess\.org$/.test(url.hostname)) return null;
  const parts = url.pathname.split("/").filter(Boolean);
  const candidates = parts[0] === "game" && parts[1] === "export" ? [parts[2]] : parts;
  for (const p of candidates) {
    if (p && /^[a-zA-Z0-9]{8}([a-zA-Z0-9]{4})?$/.test(p)) return p.slice(0, 8);
  }
  return null;
}
