export type Color = "w" | "b";

/** Engine score from the side-to-move's perspective. Exactly one of cp / mate is set. */
export interface Score {
  cp?: number;
  /** Positive = side to move mates in N; negative = side to move gets mated in N. 0 = already mated. */
  mate?: number;
}

export interface EngineLine {
  multipv: number;
  depth: number;
  score: Score;
  /** Principal variation in UCI. */
  pv: string[];
}

export type Classification =
  | "book"
  | "brilliant"
  | "great"
  | "best"
  | "excellent"
  | "good"
  | "inaccuracy"
  | "mistake"
  | "miss"
  | "blunder"
  | "forced";

export const CLASSIFICATIONS: Classification[] = [
  "brilliant",
  "great",
  "best",
  "excellent",
  "good",
  "book",
  "inaccuracy",
  "mistake",
  "miss",
  "blunder",
  "forced",
];
