export interface Bot {
  id: string;
  name: string;
  elo: number;
  personality: string;
  /** Hue used for the generated geometric avatar. */
  hue: number;
  /** Avatar shape. */
  shape: "circle" | "square" | "diamond" | "hex" | "triangle";
}

export const ELO_MIN = 400;
export const ELO_MAX = 3200;
export const ELO_STEP = 50;
export const DEFAULT_ELO = 1200;

interface Tier {
  min: number;
  name: string;
  blurb: string;
  shape: Bot["shape"];
}

/** Rating bands used to name and describe the bot at a given Elo. */
export const TIERS: Tier[] = [
  { min: 0, name: "Beginner", blurb: "Still learning how the pieces move. Hangs things often.", shape: "circle" },
  { min: 800, name: "Novice", blurb: "Knows the basics, misses simple tactics.", shape: "triangle" },
  { min: 1200, name: "Club", blurb: "Solid club player. Punishes obvious blunders.", shape: "square" },
  { min: 1600, name: "Advanced", blurb: "Strong tactics and a real plan.", shape: "diamond" },
  { min: 2000, name: "Expert", blurb: "Expert-level play. Rarely gives anything away.", shape: "hex" },
  { min: 2400, name: "Master", blurb: "Master strength. Converts every edge.", shape: "triangle" },
  { min: 2800, name: "Grandmaster", blurb: "World-class precision.", shape: "diamond" },
  { min: 3200, name: "Max", blurb: "Full-strength engine. No mercy, no mistakes.", shape: "hex" },
];

export function clampElo(elo: number): number {
  if (!Number.isFinite(elo)) return DEFAULT_ELO;
  const stepped = Math.round(elo / ELO_STEP) * ELO_STEP;
  return Math.min(ELO_MAX, Math.max(ELO_MIN, stepped));
}

export function tierFor(elo: number): Tier {
  let t = TIERS[0];
  for (const tier of TIERS) if (elo >= tier.min) t = tier;
  return t;
}

/** The bot for a rating. Strength is derived from `elo` in botMove.ts. */
export function botForElo(rawElo: number): Bot {
  const elo = clampElo(rawElo);
  const tier = tierFor(elo);
  return {
    id: `elo-${elo}`,
    name: tier.name === "Max" ? "Max" : `${tier.name} Bot`,
    elo,
    personality: tier.blurb,
    // Hue sweeps from green (easy) through blue/purple to red (strongest).
    hue: Math.round(140 + ((elo - ELO_MIN) / (ELO_MAX - ELO_MIN)) * 220) % 360,
    shape: tier.shape,
  };
}

/** Legacy ids from the original fixed ladder, so old saved games still resolve. */
const LEGACY: Record<string, number> = {
  pip: 400, rosa: 600, tomas: 800, ivy: 1000, bruno: 1200, kiko: 1400, noor: 1600,
  elias: 1800, marta: 2000, dev: 2200, sable: 2500, orion: 2800, max: 3200,
};

/** Resolve a bot id ("elo-1500", or a legacy name) to a bot. */
export function getBot(id: string | null | undefined): Bot | undefined {
  if (!id) return undefined;
  const m = id.match(/^elo-(\d{3,4})$/);
  if (m) {
    const elo = Number(m[1]);
    if (elo < ELO_MIN || elo > ELO_MAX || elo % ELO_STEP !== 0) return undefined;
    return botForElo(elo);
  }
  return LEGACY[id] ? botForElo(LEGACY[id]) : undefined;
}

export const TIME_CONTROLS = [
  { id: "unlimited", label: "Unlimited", initial: 0, increment: 0 },
  { id: "1+0", label: "1+0", initial: 60, increment: 0 },
  { id: "3+2", label: "3+2", initial: 180, increment: 2 },
  { id: "5+0", label: "5+0", initial: 300, increment: 0 },
  { id: "10+0", label: "10+0", initial: 600, increment: 0 },
  { id: "15+10", label: "15+10", initial: 900, increment: 10 },
  { id: "30+0", label: "30+0", initial: 1800, increment: 0 },
] as const;

export type TimeControlId = string;

export interface TimeControl {
  id: string;
  label: string;
  /** Initial time in seconds (0 = unlimited). */
  initial: number;
  increment: number;
}

/**
 * Parse a time control id: "unlimited" or "M+I" (minutes 1–180, increment 0–60 seconds).
 * Returns null for anything else.
 */
export function parseTimeControl(id: string): TimeControl | null {
  if (id === "unlimited") return TIME_CONTROLS[0];
  const m = /^(\d{1,3})\+(\d{1,2})$/.exec(id);
  if (!m) return null;
  const min = Number(m[1]);
  const inc = Number(m[2]);
  if (min < 1 || min > 180 || inc > 60) return null;
  return { id, label: id, initial: min * 60, increment: inc };
}

export function isValidTimeControl(id: string): boolean {
  return parseTimeControl(id) !== null;
}

export function getTimeControl(id: string): TimeControl {
  return parseTimeControl(id) ?? TIME_CONTROLS[0];
}

/** Lichess-style speed: estimated duration = initial + 40 × increment. */
export function speedOf(tc: TimeControl): "Bullet" | "Blitz" | "Rapid" | "Classical" | "Unlimited" {
  if (tc.initial === 0) return "Unlimited";
  const est = tc.initial + 40 * tc.increment;
  if (est < 180) return "Bullet";
  if (est < 480) return "Blitz";
  if (est < 1500) return "Rapid";
  return "Classical";
}

/** Tiles on the Play Online page. */
export const ONLINE_TIME_CONTROLS = ["1+0", "2+1", "3+0", "3+2", "5+0", "5+3", "10+0", "10+5", "15+10", "30+0", "30+20"];
