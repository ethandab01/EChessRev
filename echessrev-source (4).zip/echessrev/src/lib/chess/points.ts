import type { Classification } from "./types";

/**
 * Points (signed-in players only).
 *  - Result: a win is worth the bot's Elo / 10 (400 → 40, 3200 → 320); a draw is half that; a loss is 0.
 *  - Review bonus (once per game, your own moves only): Brilliant +25, Great +10, Best +1.
 */
export const BONUS: Partial<Record<Classification, number>> = { brilliant: 25, great: 10, best: 1 };

export function resultPoints(outcome: "win" | "loss" | "draw", botElo: number): number {
  if (outcome === "win") return Math.round(botElo / 10);
  if (outcome === "draw") return Math.round(botElo / 20);
  return 0;
}

export function reviewBonus(counts: Partial<Record<Classification, number>>): { total: number; lines: Array<{ c: Classification; n: number; pts: number }> } {
  const lines: Array<{ c: Classification; n: number; pts: number }> = [];
  let total = 0;
  for (const [c, per] of Object.entries(BONUS) as Array<[Classification, number]>) {
    const n = Math.max(0, Math.floor(counts[c] ?? 0));
    if (n > 0) {
      lines.push({ c, n, pts: n * per });
      total += n * per;
    }
  }
  return { total, lines };
}
