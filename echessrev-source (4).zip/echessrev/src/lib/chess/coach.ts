import { Chess, type Move, type Square, type PieceSymbol, type Color } from "chess.js";
import type { Classification, EngineLine } from "./types";
import { CLASSIFICATION_META, type PositionEval } from "./classify";
import { PIECE_NAME, PIECE_VALUE, attackersOf, bestCaptureGain, see } from "./material";
import { formatScore } from "./winpct";

/** Convert a UCI move to SAN in a position; returns the UCI string if illegal. */
export function uciToSan(fen: string, uci: string): string {
  try {
    const c = new Chess(fen);
    const m = c.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), promotion: uci[4] });
    return m.san;
  } catch {
    return uci;
  }
}

/** Convert a UCI PV to SAN moves. Stops at the first illegal move. */
export function pvToSan(fen: string, pv: string[], max = 12): string[] {
  const c = new Chess(fen);
  const out: string[] = [];
  for (const uci of pv.slice(0, max)) {
    try {
      out.push(c.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), promotion: uci[4] }).san);
    } catch {
      break;
    }
  }
  return out;
}

/** Squares attacked by the piece on `from` (pseudo-legal). */
function attackedBy(chess: Chess, from: Square): Square[] {
  const piece = chess.get(from);
  if (!piece) return [];
  const out: Square[] = [];
  for (const row of chess.board())
    for (const sq of row) {
      if (!sq || sq.color === piece.color) continue;
      if (attackersOf(chess, sq.square, piece.color).includes(from)) out.push(sq.square);
    }
  return out;
}

/**
 * Fork: the piece on `square` attacks two or more enemy targets that are each either the
 * king, worth more than the forking piece, or undefended.
 */
export function forkTargets(chess: Chess, square: Square): Array<{ square: Square; type: PieceSymbol }> {
  const piece = chess.get(square);
  if (!piece) return [];
  const enemy: Color = piece.color === "w" ? "b" : "w";
  // A forking piece that can simply be captured for free is not a real fork.
  if (see(chess, square, enemy) >= PIECE_VALUE[piece.type] && piece.type !== "k") return [];
  const targets = attackedBy(chess, square)
    .map((s) => ({ square: s, type: chess.get(s)!.type }))
    .filter((t) => {
      if (t.type === "k") return true;
      if (PIECE_VALUE[t.type] > PIECE_VALUE[piece.type]) return true;
      return PIECE_VALUE[t.type] >= 3 && attackersOf(chess, t.square, enemy).length === 0;
    });
  return targets.length >= 2 ? targets : [];
}

function article(name: string) {
  return /^[aeiou]/.test(name) ? `an ${name}` : `a ${name}`;
}

function playMove(fen: string, uci: string): { chess: Chess; move: Move } | null {
  try {
    const chess = new Chess(fen);
    const move = chess.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), promotion: uci[4] });
    return { chess, move };
  } catch {
    return null;
  }
}

/** What a move wins materially (net, after the opponent's best recapture), or null. */
function materialWon(fen: string, uci: string): { name: string; net: number } | null {
  const r = playMove(fen, uci);
  if (!r || !r.move.captured) return null;
  const capturedValue = PIECE_VALUE[r.move.captured];
  const opp: Color = r.move.color === "w" ? "b" : "w";
  const lost = see(r.chess, r.move.to as Square, opp);
  const net = capturedValue - lost;
  if (net < 1) return null;
  const moved = r.move.piece;
  if (r.move.captured === "r" && (moved === "n" || moved === "b") && lost >= 3) return { name: "the exchange", net };
  return { name: article(PIECE_NAME[r.move.captured]), net };
}

export interface CoachInput {
  classification: Classification;
  san: string;
  before: PositionEval;
  after: PositionEval;
  move: Pick<Move, "from" | "to" | "promotion" | "color" | "san" | "captured" | "piece">;
  openingName?: string;
  /** True when this move was a material sacrifice (from classifyMove). */
  sacrifice?: boolean;
}

export interface CoachOutput {
  text: string;
  reason: string;
  bestSan: string | null;
}

function moverScoreAfter(after: PositionEval): string {
  return after.lines[0] ? formatScore(after.lines[0].score, new Chess(after.fen).turn()) : "";
}

/** 1–2 sentence explanation built from engine data and simple tactical checks. */
export function explainMove(input: CoachInput): CoachOutput {
  const { classification, before, after, move, san } = input;
  const meta = CLASSIFICATION_META[classification];
  const top: EngineLine | undefined = before.lines[0];
  const bestUci = top?.pv[0];
  const bestSan = bestUci ? uciToSan(before.fen, bestUci) : null;
  const playedUci = `${move.from}${move.to}${move.promotion ?? ""}`;
  const isBestMove = bestUci === playedUci;
  const stmBefore = new Chess(before.fen).turn();
  const evalBefore = top ? formatScore(top.score, stmBefore) : "";
  const evalAfter = after.terminal === "checkmate" ? (stmBefore === "w" ? "1-0" : "0-1") : moverScoreAfter(after);
  const evalChange = evalBefore && evalAfter ? ` (eval ${evalBefore} → ${evalAfter})` : "";
  const opp: Color = move.color === "w" ? "b" : "w";
  const afterBoard = new Chess(after.fen);

  let reason = "";

  // 1. Mate delivered / mates found or missed / allowed.
  if (after.terminal === "checkmate") reason = "delivers checkmate";
  else if (after.terminal === "stalemate") reason = top && top.score.mate === undefined && Math.abs(top.score.cp ?? 0) < 100 ? "forces stalemate" : "stalemates the opponent, throwing away the win";

  const afterTop = after.lines[0];
  if (!reason && top?.score.mate !== undefined && top.score.mate > 0) {
    const stillMating = afterTop?.score.mate !== undefined && afterTop.score.mate < 0;
    if (!stillMating) reason = `misses mate in ${top.score.mate}`;
    else if (isBestMove || -afterTop!.score.mate! <= top.score.mate) reason = `keeps a forced mate in ${-afterTop!.score.mate!}`;
    else reason = `still mates, but slower than the mate in ${top.score.mate}`;
  }
  if (!reason && afterTop?.score.mate !== undefined && afterTop.score.mate > 0 && !(top?.score.mate !== undefined && top.score.mate < 0)) {
    reason = `allows mate in ${afterTop.score.mate}`;
  }
  if (!reason && top?.score.mate !== undefined && top.score.mate < 0 && classification === "forced") {
    reason = "is the only legal move";
  }

  // 2. Sacrifice (brilliant).
  if (!reason && classification === "brilliant") {
    const { square } = bestCaptureGain(afterBoard, opp);
    const piece = square ? afterBoard.get(square) : undefined;
    reason = piece ? `sacrifices ${article(PIECE_NAME[piece.type])} for a winning follow-up` : "gives up material for a powerful initiative";
  }

  // 3. Hanging material: opponent's best reply wins material by capture.
  const reply = afterTop?.pv[0];
  if (!reason && reply && !after.terminal) {
    const replyWin = materialWon(after.fen, reply);
    const { gain, square } = bestCaptureGain(afterBoard, opp);
    if (replyWin && gain >= 1 && square && reply.slice(2, 4) === square && ["inaccuracy", "mistake", "blunder", "miss"].includes(classification)) {
      const piece = afterBoard.get(square);
      reason = piece ? `hangs ${article(PIECE_NAME[piece.type])} on ${square}` : `loses ${replyWin.name}`;
    }
  }

  // 4. Allows a fork.
  if (!reason && reply && ["inaccuracy", "mistake", "blunder", "miss"].includes(classification)) {
    const r = playMove(after.fen, reply);
    if (r) {
      const targets = forkTargets(r.chess, r.move.to as Square);
      if (targets.length >= 2) {
        reason = `allows ${article(PIECE_NAME[r.move.piece])} fork with ${r.move.san}`;
      }
    }
  }

  // 5. The move itself wins material / forks.
  if (!reason) {
    const won = materialWon(before.fen, playedUci);
    if (won && won.net >= 2) reason = `wins ${won.name}`;
  }
  if (!reason && !after.terminal) {
    const targets = forkTargets(afterBoard, move.to as Square);
    if (targets.length >= 2 && ["brilliant", "great", "best", "excellent", "good"].includes(classification)) {
      const names = targets.slice(0, 2).map((t) => PIECE_NAME[t.type]);
      reason = `forks the ${names[0]} and ${names[1]}`;
    }
  }

  // 6. Missed a material win.
  if (!reason && bestUci && !isBestMove && ["inaccuracy", "mistake", "blunder", "miss"].includes(classification)) {
    const won = materialWon(before.fen, bestUci);
    if (won && won.net >= 2) reason = `misses the chance to win ${won.name} with ${bestSan}`;
  }

  // 7. Promotion.
  if (!reason && move.promotion) {
    reason = move.promotion === "q" ? "promotes to a queen" : `underpromotes to ${article(PIECE_NAME[move.promotion as PieceSymbol])}`;
  }

  // 8. Generic fallback by class.
  if (!reason) {
    const generic: Record<Classification, string> = {
      book: input.openingName ? `is a known opening move (${input.openingName})` : "is a known opening move",
      brilliant: "is a brilliant sacrifice",
      great: "is the only move that keeps the balance in your favour",
      best: "is the strongest move in the position",
      excellent: "is nearly as strong as the engine's choice",
      good: "is a reasonable move that keeps the position",
      inaccuracy: "lets some of the advantage slip",
      mistake: "gives the opponent a clear improvement",
      miss: "fails to punish the opponent's error",
      blunder: "throws away a big part of the position",
      forced: "is the only legal move",
    };
    reason = generic[classification];
  }

  const label = meta.label.toLowerCase();
  const nounLabels: Classification[] = ["inaccuracy", "mistake", "miss", "blunder"];
  let text: string;
  if (classification === "book") text = `${san} is a book move: it ${reason}.`;
  else if (classification === "forced") text = `${san} is forced: it ${reason}.`;
  else if (classification === "best") text = `${san} is the best move: it ${reason}.`;
  else if (nounLabels.includes(classification)) text = `${san} is ${/^[aeiou]/.test(label) ? "an" : "a"} ${label}: it ${reason}.`;
  else text = `${san} is ${/^[aeiou]/.test(label) ? "an" : "a"} ${label} move: it ${reason}.`;
  if (bestSan && !isBestMove && !["book", "forced", "best"].includes(classification)) {
    text += ` The best move was ${bestSan}${evalChange}.`;
  } else if (evalChange && classification !== "book") {
    text += ` Evaluation${evalChange.replace(" (eval", ":").replace(")", "")}.`;
  }
  return { text, reason, bestSan };
}
