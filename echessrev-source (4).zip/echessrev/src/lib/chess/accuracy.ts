/**
 * Accuracy, following the Lichess method.
 *
 * Move accuracy = 103.1668 * exp(-0.04354 * (winBefore − winAfter)) − 3.1669, clamped 0..100
 * (win% from the mover's perspective; a move that does not lose win% scores 100).
 *
 * Game accuracy for a side = average of
 *   (a) the harmonic mean of that side's move accuracies, and
 *   (b) the volatility-weighted mean, where each move's weight is the standard deviation of
 *       White's win% over a sliding window around it (clamped 0.5..12).
 */

export function moveAccuracy(winBefore: number, winAfter: number): number {
  const diff = Math.max(0, winBefore - winAfter);
  const raw = 103.1668 * Math.exp(-0.04354 * diff) - 3.1669;
  return Math.min(100, Math.max(0, raw));
}

function stdDev(xs: number[]): number {
  if (xs.length === 0) return 0;
  const mean = xs.reduce((a, b) => a + b, 0) / xs.length;
  const variance = xs.reduce((a, b) => a + (b - mean) ** 2, 0) / xs.length;
  return Math.sqrt(variance);
}

export function harmonicMean(xs: number[]): number {
  if (xs.length === 0) return 0;
  // Accuracies of 0 would make the harmonic mean 0 regardless of the rest; floor at 1 like Lichess' practical behaviour.
  const sum = xs.reduce((a, x) => a + 1 / Math.max(1, x), 0);
  return xs.length / sum;
}

export function weightedMean(pairs: Array<[number, number]>): number {
  const wsum = pairs.reduce((a, [, w]) => a + w, 0);
  if (wsum === 0) return 0;
  return pairs.reduce((a, [x, w]) => a + x * w, 0) / wsum;
}

export interface GameAccuracy {
  white: number;
  black: number;
  /** Per-ply move accuracy (index i = move i), from the mover's perspective. */
  moves: number[];
}

/**
 * @param whiteWinPcts White's win% for every position of the game, starting with the
 *   initial position (length = plies + 1).
 * @param firstMover who made the first move ("b" for games starting from a FEN with Black to move).
 */
export function gameAccuracy(whiteWinPcts: number[], firstMover: "w" | "b" = "w"): GameAccuracy {
  const plies = whiteWinPcts.length - 1;
  if (plies <= 0) return { white: 0, black: 0, moves: [] };

  const windowSize = Math.min(8, Math.max(2, Math.floor(plies / 10)));
  const windows: number[][] = [];
  const firstWindow = whiteWinPcts.slice(0, windowSize);
  for (let i = 0; i < Math.min(windowSize, whiteWinPcts.length) - 2; i++) windows.push(firstWindow);
  for (let i = 0; i + windowSize <= whiteWinPcts.length; i++) windows.push(whiteWinPcts.slice(i, i + windowSize));
  // Very short games: make sure every move has a window.
  while (windows.length < plies) windows.push(whiteWinPcts);
  const weights = windows.map((w) => Math.min(12, Math.max(0.5, stdDev(w))));

  const moves: number[] = [];
  const perSide: Record<"w" | "b", Array<[number, number]>> = { w: [], b: [] };
  for (let i = 0; i < plies; i++) {
    const mover: "w" | "b" = (i % 2 === 0) === (firstMover === "w") ? "w" : "b";
    const prev = whiteWinPcts[i];
    const next = whiteWinPcts[i + 1];
    const acc = mover === "w" ? moveAccuracy(prev, next) : moveAccuracy(100 - prev, 100 - next);
    moves.push(acc);
    perSide[mover].push([acc, weights[i]]);
  }

  const side = (pairs: Array<[number, number]>) => {
    if (pairs.length === 0) return 0;
    const h = harmonicMean(pairs.map(([x]) => x));
    const w = weightedMean(pairs);
    return (h + w) / 2;
  };
  return { white: side(perSide.w), black: side(perSide.b), moves };
}

/**
 * Accuracy → rating lookup (accuracy lower bound → Elo), interpolated linearly.
 * Deliberately conservative: engine-measured accuracy runs high in quiet or short games.
 *
 *   accuracy:  0   50   60   70   75   80   85   90   93   96   98  100
 *   rating:  100  400  700 1000 1200 1400 1650 1950 2200 2500 2750 2900
 */
export const ACCURACY_RATING_TABLE: Array<[number, number]> = [
  [0, 100],
  [50, 400],
  [60, 700],
  [70, 1000],
  [75, 1200],
  [80, 1400],
  [85, 1650],
  [90, 1950],
  [93, 2200],
  [96, 2500],
  [98, 2750],
  [100, 2900],
];

export function ratingFromAccuracy(accuracy: number): number {
  const a = Math.min(100, Math.max(0, accuracy));
  for (let i = 1; i < ACCURACY_RATING_TABLE.length; i++) {
    const [a1, r1] = ACCURACY_RATING_TABLE[i];
    const [a0, r0] = ACCURACY_RATING_TABLE[i - 1];
    if (a <= a1) return r0 + ((a - a0) / (a1 - a0)) * (r1 - r0);
  }
  return 2900;
}

/** Average centipawn loss → rating: 3100 · e^(−0.01 · ACPL)  (ACPL 20 ≈ 2540, 60 ≈ 1700, 100 ≈ 1140). */
export function ratingFromAcpl(acpl: number): number {
  return Math.min(3000, Math.max(100, 3100 * Math.exp(-0.01 * Math.max(0, acpl))));
}

/** Prior rating that short games are pulled toward, and how many moves it is "worth". */
export const PERF_PRIOR = 1200;
export const PERF_PRIOR_MOVES = 10;

/**
 * Estimated performance rating for one side of one game.
 * Blends the accuracy-based and ACPL-based estimates, then shrinks toward PERF_PRIOR by
 * moves / (moves + PERF_PRIOR_MOVES), so a handful of good moves can't claim a master rating.
 * `moves` should count only the side's non-book, non-forced moves.
 */
export function estimatePerformance(opts: { accuracy: number; acpl: number; moves: number }): number {
  if (opts.moves <= 0) return PERF_PRIOR;
  const raw = (ratingFromAccuracy(opts.accuracy) + ratingFromAcpl(opts.acpl)) / 2;
  const w = opts.moves / (opts.moves + PERF_PRIOR_MOVES);
  const est = PERF_PRIOR + w * (raw - PERF_PRIOR);
  return Math.round(Math.min(3000, Math.max(100, est)) / 50) * 50;
}

/** Back-compat: accuracy-only estimate, rounded to 25. */
export function estimateRating(accuracy: number): number {
  return Math.round(ratingFromAccuracy(accuracy) / 25) * 25;
}
