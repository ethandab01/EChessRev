import { Chess } from "chess.js";

export interface Puzzle {
  id: string;
  /** Position before the opponent's setup move. */
  fen: string;
  /** UCI moves: [opponent setup move, your move, reply, your move, ...]. */
  moves: string[];
  rating: number;
  themes: string[];
}

export type PuzzleRow = [string, string, string, number, string];

export function rowToPuzzle(r: PuzzleRow): Puzzle {
  return { id: r[0], fen: r[1], moves: r[2].split(" "), rating: r[3], themes: r[4].split(" ").filter(Boolean) };
}

export type MoveVerdict = "correct" | "solved" | "wrong";

/**
 * Check the player's move at `step` (an odd index into puzzle.moves).
 * `fen` is the current position. Any move that delivers checkmate is accepted (like Lichess).
 */
export function checkPuzzleMove(puzzle: Puzzle, step: number, fen: string, uci: string): MoveVerdict {
  const expected = puzzle.moves[step];
  const c = new Chess(fen);
  try {
    c.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), promotion: uci[4] });
  } catch {
    return "wrong";
  }
  const isLast = step >= puzzle.moves.length - 1;
  if (c.isCheckmate()) return "solved";
  if (uci !== expected) return "wrong";
  return isLast ? "solved" : "correct";
}

/** Elo update for a puzzle attempt (K = 32; puzzle is the opponent). */
export function puzzleRatingUpdate(userRating: number, puzzleRating: number, solved: boolean, k = 32): number {
  const expected = 1 / (1 + 10 ** ((puzzleRating - userRating) / 400));
  const next = userRating + k * ((solved ? 1 : 0) - expected);
  return Math.max(100, Math.round(next));
}

/** Points for solving a puzzle on the first try: puzzle rating / 100. */
export function puzzlePoints(puzzleRating: number, solved: boolean): number {
  return solved ? Math.max(1, Math.round(puzzleRating / 100)) : 0;
}

const THEME_NAMES: Record<string, string> = {
  mate: "Checkmate", mateIn1: "Mate in 1", mateIn2: "Mate in 2", mateIn3: "Mate in 3", mateIn4: "Mate in 4", mateIn5: "Mate in 5+",
  fork: "Fork", pin: "Pin", skewer: "Skewer", sacrifice: "Sacrifice", discoveredAttack: "Discovered attack",
  hangingPiece: "Hanging piece", deflection: "Deflection", attraction: "Attraction", quietMove: "Quiet move",
  defensiveMove: "Defensive move", kingsideAttack: "Kingside attack", queensideAttack: "Queenside attack",
  advancedPawn: "Advanced pawn", promotion: "Promotion", underPromotion: "Underpromotion", endgame: "Endgame",
  middlegame: "Middlegame", opening: "Opening", rookEndgame: "Rook endgame", pawnEndgame: "Pawn endgame",
  backRankMate: "Back-rank mate", smotheredMate: "Smothered mate", trappedPiece: "Trapped piece",
  exposedKing: "Exposed king", doubleCheck: "Double check", zugzwang: "Zugzwang", interference: "Interference",
  intermezzo: "Intermezzo", xRayAttack: "X-ray", capturingDefender: "Remove the defender", clearance: "Clearance",
  enPassant: "En passant", castling: "Castling", crushing: "Crushing", advantage: "Advantage", equality: "Equality",
};

/** Human-readable themes, skipping length/phase tags that aren't interesting on their own. */
export function themeLabels(themes: string[]): string[] {
  const skip = new Set(["short", "long", "veryLong", "oneMove", "master", "masterVsMaster", "superGM", "crushing", "advantage", "equality"]);
  return themes.filter((t) => !skip.has(t) && THEME_NAMES[t]).map((t) => THEME_NAMES[t]);
}
