import { Chess, type Move } from "chess.js";
import type { Classification, EngineLine } from "./types";
import { expectedPointsLoss, scoreToWinPct } from "./winpct";
import { bestCaptureGain, materialBalance } from "./material";

export type Terminal = "checkmate" | "stalemate" | "draw";

/** Engine data for one position. Scores in `lines` are from the side-to-move's perspective. */
export interface PositionEval {
  fen: string;
  lines: EngineLine[];
  terminal?: Terminal;
}

/** Side-to-move's win% (0..100) with best play. */
export function positionWinPct(p: PositionEval): number {
  if (p.terminal === "checkmate") return 0;
  if (p.terminal === "stalemate" || p.terminal === "draw") return 50;
  if (!p.lines.length) return 50;
  return scoreToWinPct(p.lines[0].score);
}

export interface ClassifyInput {
  /** Position before the move. */
  before: PositionEval;
  /** Position after the move. */
  after: PositionEval;
  /** The move, as played (chess.js verbose move). */
  move: Pick<Move, "from" | "to" | "promotion" | "color" | "san">;
  /** True if this move is within the book section of the game. */
  inBook: boolean;
  /** Classification of the opponent's previous move, if any. */
  prevClassification?: Classification;
  /** Mover's win% after their own previous move (two plies ago), if any. */
  prevMoverWinPct?: number;
}

export interface ClassifyResult {
  classification: Classification;
  epl: number;
  winBefore: number;
  winAfter: number;
  isBest: boolean;
  sacrifice: boolean;
}

export const EPL = {
  BEST_EPSILON: 0.002,
  BRILLIANT_NEAR_BEST: 0.02,
  EXCELLENT: 0.02,
  GOOD: 0.05,
  INACCURACY: 0.1,
  MISTAKE: 0.2,
  GREAT_GAP: 0.1,
  MISS: 0.1,
} as const;

export function moveToUci(m: Pick<Move, "from" | "to" | "promotion">): string {
  return `${m.from}${m.to}${m.promotion ?? ""}`;
}

/**
 * True if the move gives up material: comparing the mover's material balance before the
 * move with the balance after the move AND after the opponent's best immediate capture
 * sequence (static exchange evaluation), the mover is down at least 2 pawn units
 * (a minor piece, or the exchange).
 */
export function isSacrifice(fenBefore: string, move: Pick<Move, "from" | "to" | "promotion">): boolean {
  const board = new Chess(fenBefore);
  const mover = board.turn();
  const opp = mover === "w" ? "b" : "w";
  const matBefore = materialBalance(board, mover);
  try {
    board.move({ from: move.from, to: move.to, promotion: move.promotion });
  } catch {
    return false;
  }
  const matAfterMove = materialBalance(board, mover);
  const { gain } = bestCaptureGain(board, opp);
  const net = matAfterMove - gain;
  return matBefore - net >= 2;
}

/**
 * Classify a move. Priority order:
 *   Forced → Book → Brilliant → Great → Best → Excellent → Good → Miss → Inaccuracy → Mistake → Blunder
 *
 * Notes on interpretation:
 *  - "Forced" is checked first: when only one legal move exists no other label is meaningful.
 *  - "Miss" is checked before the EPL buckets it would otherwise fall into, so a move that
 *    fails to punish the opponent's Mistake/Blunder is labelled Miss rather than Mistake.
 */
export function classifyMove(input: ClassifyInput): ClassifyResult {
  const { before, after, move } = input;
  const board = new Chess(before.fen);
  const legalCount = board.moves().length;

  const winBefore = positionWinPct(before);
  // Mover's win% after the move = complement of the opponent's win% (side to move after).
  const winAfter = 100 - positionWinPct(after);
  const epl = expectedPointsLoss(winBefore, winAfter);
  const uci = moveToUci(move);
  const top = before.lines[0];
  const isBest = (top && top.pv[0] === uci) || epl <= EPL.BEST_EPSILON;
  const base = { epl, winBefore, winAfter, isBest, sacrifice: false };

  if (legalCount === 1) return { ...base, classification: "forced" };
  if (input.inBook) return { ...base, classification: "book" };

  const sacrifice = (isBest || epl <= EPL.BRILLIANT_NEAR_BEST) && isSacrifice(before.fen, move);
  if (sacrifice && winBefore < 90 && winAfter >= 50) {
    return { ...base, sacrifice, classification: "brilliant" };
  }

  if (isBest) {
    const second = before.lines[1];
    const gap = second ? (winBefore - scoreToWinPct(second.score)) / 100 : 0;
    const turnsIt =
      input.prevMoverWinPct !== undefined && input.prevMoverWinPct <= 50 && winAfter >= 70;
    if (gap >= EPL.GREAT_GAP || turnsIt) return { ...base, sacrifice, classification: "great" };
    return { ...base, sacrifice, classification: "best" };
  }
  if (epl <= EPL.EXCELLENT) return { ...base, classification: "excellent" };
  if (epl <= EPL.GOOD) return { ...base, classification: "good" };

  const prev = input.prevClassification;
  if ((prev === "mistake" || prev === "blunder") && epl >= EPL.MISS) {
    return { ...base, classification: "miss" };
  }
  if (epl <= EPL.INACCURACY) return { ...base, classification: "inaccuracy" };
  if (epl <= EPL.MISTAKE) return { ...base, classification: "mistake" };
  return { ...base, classification: "blunder" };
}

export const CLASSIFICATION_META: Record<
  Classification,
  { label: string; symbol: string; color: string; textClass: string }
> = {
  book: { label: "Book", symbol: "📖", color: "#a58b6f", textClass: "text-[#a58b6f]" },
  brilliant: { label: "Brilliant", symbol: "!!", color: "#1fb5ad", textClass: "text-[#1fb5ad]" },
  great: { label: "Great", symbol: "!", color: "#4a8fe7", textClass: "text-[#4a8fe7]" },
  best: { label: "Best", symbol: "★", color: "#5fae3a", textClass: "text-[#5fae3a]" },
  excellent: { label: "Excellent", symbol: "👍", color: "#8fc65a", textClass: "text-[#8fc65a]" },
  good: { label: "Good", symbol: "✓", color: "#8ba58a", textClass: "text-[#8ba58a]" },
  inaccuracy: { label: "Inaccuracy", symbol: "?!", color: "#e8c547", textClass: "text-[#e8c547]" },
  mistake: { label: "Mistake", symbol: "?", color: "#ef9b3a", textClass: "text-[#ef9b3a]" },
  miss: { label: "Miss", symbol: "✕", color: "#ee6a3e", textClass: "text-[#ee6a3e]" },
  blunder: { label: "Blunder", symbol: "??", color: "#e0433b", textClass: "text-[#e0433b]" },
  forced: { label: "Forced", symbol: "□", color: "#97a0a8", textClass: "text-[#97a0a8]" },
};

export const NEEDS_RETRY: Classification[] = ["inaccuracy", "mistake", "miss", "blunder"];
