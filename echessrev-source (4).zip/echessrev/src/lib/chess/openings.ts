import openings from "@/data/openings.json";

const DB = openings as unknown as Record<string, [string, string]>;

/** FEN → EPD key (board, side, castling, en passant), matching how the DB was built. */
export function fenToEpd(fen: string): string {
  return fen.trim().split(/\s+/).slice(0, 4).join(" ");
}

export interface Opening {
  eco: string;
  name: string;
}

export function lookupOpening(fen: string): Opening | null {
  const hit = DB[fenToEpd(fen)];
  return hit ? { eco: hit[0], name: hit[1] } : null;
}

/** Plies counted as the "opening phase" for Book detection. */
export const OPENING_PHASE_PLIES = 30;

/**
 * Given the FENs after each ply (index i = position after ply i+1), return the number of
 * leading plies that are "book": every ply up to and including the last one whose
 * resulting position appears in the opening database within the opening phase.
 * (The DB only stores named positions, so un-named intermediate positions inside a
 * named line still count as book.)
 */
export function bookPlies(fensAfter: string[]): number {
  let last = 0;
  const n = Math.min(fensAfter.length, OPENING_PHASE_PLIES);
  for (let i = 0; i < n; i++) {
    if (DB[fenToEpd(fensAfter[i])]) last = i + 1;
    // Once we are several plies past the last named position, we have left book.
    if (i + 1 - last > 6) break;
  }
  return last;
}

/** The most specific named opening reached in the game. */
export function detectOpening(fensAfter: string[]): Opening | null {
  let found: Opening | null = null;
  for (const fen of fensAfter.slice(0, 40)) {
    const o = lookupOpening(fen);
    if (o) found = o;
  }
  return found;
}
