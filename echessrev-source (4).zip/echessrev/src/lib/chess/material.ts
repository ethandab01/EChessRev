import { Chess, type Square, type PieceSymbol, type Color } from "chess.js";

export const PIECE_VALUE: Record<PieceSymbol, number> = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 100 };
export const PIECE_NAME: Record<PieceSymbol, string> = {
  p: "pawn",
  n: "knight",
  b: "bishop",
  r: "rook",
  q: "queen",
  k: "king",
};

/** Material balance (pawn units, kings excluded) from `color`'s perspective. */
export function materialBalance(chess: Chess, color: Color): number {
  let total = 0;
  for (const row of chess.board()) {
    for (const sq of row) {
      if (!sq || sq.type === "k") continue;
      total += sq.color === color ? PIECE_VALUE[sq.type] : -PIECE_VALUE[sq.type];
    }
  }
  return total;
}

const FILES = "abcdefgh";

function sqToXY(sq: Square): [number, number] {
  return [FILES.indexOf(sq[0]), Number(sq[1]) - 1];
}
function xyToSq(x: number, y: number): Square | null {
  if (x < 0 || x > 7 || y < 0 || y > 7) return null;
  return `${FILES[x]}${y + 1}` as Square;
}

/**
 * All pieces of `color` that attack `target` (pseudo-legal, pins ignored), taking the
 * given set of removed squares into account so x-ray attackers appear once pieces in
 * front of them have been exchanged off.
 */
export function attackersOf(chess: Chess, target: Square, color: Color, removed: Set<Square> = new Set()): Square[] {
  const [tx, ty] = sqToXY(target);
  const out: Square[] = [];
  const at = (sq: Square | null) => (sq && !removed.has(sq) ? chess.get(sq) : undefined);

  // Pawns
  const pawnDir = color === "w" ? -1 : 1; // pawn that attacks target sits one rank "behind"
  for (const dx of [-1, 1]) {
    const sq = xyToSq(tx + dx, ty + pawnDir);
    const p = at(sq);
    if (sq && p && p.color === color && p.type === "p") out.push(sq);
  }
  // Knights
  for (const [dx, dy] of [[1, 2], [2, 1], [-1, 2], [-2, 1], [1, -2], [2, -1], [-1, -2], [-2, -1]]) {
    const sq = xyToSq(tx + dx, ty + dy);
    const p = at(sq);
    if (sq && p && p.color === color && p.type === "n") out.push(sq);
  }
  // King
  for (let dx = -1; dx <= 1; dx++)
    for (let dy = -1; dy <= 1; dy++) {
      if (!dx && !dy) continue;
      const sq = xyToSq(tx + dx, ty + dy);
      const p = at(sq);
      if (sq && p && p.color === color && p.type === "k") out.push(sq);
    }
  // Sliders
  const rays: Array<[number, number, PieceSymbol[]]> = [
    [1, 0, ["r", "q"]], [-1, 0, ["r", "q"]], [0, 1, ["r", "q"]], [0, -1, ["r", "q"]],
    [1, 1, ["b", "q"]], [1, -1, ["b", "q"]], [-1, 1, ["b", "q"]], [-1, -1, ["b", "q"]],
  ];
  for (const [dx, dy, types] of rays) {
    let x = tx + dx;
    let y = ty + dy;
    while (true) {
      const sq = xyToSq(x, y);
      if (!sq) break;
      const p = at(sq);
      if (p) {
        if (p.color === color && types.includes(p.type)) out.push(sq);
        break;
      }
      x += dx;
      y += dy;
    }
  }
  return out;
}

/**
 * Static exchange evaluation: material (pawn units) that `attackerColor` wins by
 * starting a capture sequence on `target`, each side always recapturing with its least
 * valuable attacker and free to stop. Returns 0 if the square is empty or not attacked.
 */
export function see(chess: Chess, target: Square, attackerColor: Color): number {
  const victim = chess.get(target);
  if (!victim || victim.color === attackerColor) return 0;
  const removed = new Set<Square>();
  const gain: number[] = [];

  const leastAttacker = (side: Color): Square | null => {
    const attackers = attackersOf(chess, target, side, removed);
    if (attackers.length === 0) return null;
    attackers.sort((a, b) => PIECE_VALUE[chess.get(a)!.type] - PIECE_VALUE[chess.get(b)!.type]);
    const from = attackers[0];
    if (chess.get(from)!.type === "k") {
      // A king may only capture if the square is not defended (after this capture).
      const other: Color = side === "w" ? "b" : "w";
      if (attackersOf(chess, target, other, new Set([...removed, from])).length > 0) return null;
    }
    return from;
  };

  let side: Color = attackerColor;
  let from = leastAttacker(side);
  if (!from) return 0;
  gain[0] = PIECE_VALUE[victim.type];
  let pieceOnSquare = PIECE_VALUE[chess.get(from)!.type];
  removed.add(from);
  side = side === "w" ? "b" : "w";
  let d = 0;
  while (true) {
    from = leastAttacker(side);
    if (!from) break;
    d++;
    gain[d] = pieceOnSquare - gain[d - 1];
    pieceOnSquare = PIECE_VALUE[chess.get(from)!.type];
    removed.add(from);
    side = side === "w" ? "b" : "w";
  }
  // Either side may decline to continue the exchange.
  while (d > 0) {
    gain[d - 1] = -Math.max(-gain[d - 1], gain[d]);
    d--;
  }
  return Math.max(0, gain[0]);
}

/**
 * The best material `attackerColor` can win immediately by a single capture sequence
 * (max SEE over all of the opponent's pieces). Returns the gain and the target square.
 */
export function bestCaptureGain(chess: Chess, attackerColor: Color): { gain: number; square: Square | null } {
  let best = { gain: 0, square: null as Square | null };
  for (const row of chess.board()) {
    for (const sq of row) {
      if (!sq || sq.color === attackerColor || sq.type === "k") continue;
      const g = see(chess, sq.square, attackerColor);
      if (g > best.gain) best = { gain: g, square: sq.square };
    }
  }
  return best;
}

/** Each side's material can (not) deliver mate: lone king, K+N or K+B. */
export function hasMatingMaterial(chess: Chess, color: Color): boolean {
  let minors = 0;
  for (const row of chess.board()) {
    for (const sq of row) {
      if (!sq || sq.color !== color || sq.type === "k") continue;
      if (sq.type === "p" || sq.type === "r" || sq.type === "q") return true;
      minors++;
    }
  }
  return minors >= 2;
}
