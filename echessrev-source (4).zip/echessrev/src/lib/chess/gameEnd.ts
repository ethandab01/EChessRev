import type { Chess } from "chess.js";
import { hasMatingMaterial } from "./material";

export type Termination =
  | "checkmate"
  | "resignation"
  | "timeout"
  | "timeout-insufficient"
  | "stalemate"
  | "threefold"
  | "fifty-move"
  | "insufficient"
  | "agreement";

export interface GameOver {
  result: "1-0" | "0-1" | "1/2-1/2";
  termination: Termination;
}

export const TERMINATION_TEXT: Record<Termination, string> = {
  checkmate: "by checkmate",
  resignation: "by resignation",
  timeout: "on time",
  "timeout-insufficient": "— timeout vs. insufficient material",
  stalemate: "by stalemate",
  threefold: "by threefold repetition",
  "fifty-move": "by the 50-move rule",
  insufficient: "by insufficient material",
  agreement: "by agreement",
};

/** Rule-based game end after a move (checkmate, stalemate, repetition, 50-move, material). */
export function detectGameEnd(chess: Chess): GameOver | null {
  if (chess.isCheckmate()) return { result: chess.turn() === "w" ? "0-1" : "1-0", termination: "checkmate" };
  if (chess.isStalemate()) return { result: "1/2-1/2", termination: "stalemate" };
  if (chess.isInsufficientMaterial()) return { result: "1/2-1/2", termination: "insufficient" };
  if (chess.isThreefoldRepetition()) return { result: "1/2-1/2", termination: "threefold" };
  if (chess.isDrawByFiftyMoves()) return { result: "1/2-1/2", termination: "fifty-move" };
  return null;
}

/** The side whose flag fell loses, unless the opponent cannot possibly mate — then it's a draw. */
export function timeoutResult(chess: Chess, flagged: "w" | "b"): GameOver {
  const winner = flagged === "w" ? "b" : "w";
  if (!hasMatingMaterial(chess, winner)) return { result: "1/2-1/2", termination: "timeout-insufficient" };
  return { result: winner === "w" ? "1-0" : "0-1", termination: "timeout" };
}

export function describeResult(over: GameOver, userColor: "w" | "b"): { headline: string; outcome: "win" | "loss" | "draw" } {
  if (over.result === "1/2-1/2") return { headline: `Draw ${TERMINATION_TEXT[over.termination]}`, outcome: "draw" };
  const whiteWon = over.result === "1-0";
  const userWon = whiteWon === (userColor === "w");
  return { headline: `${userWon ? "You won" : "You lost"} ${TERMINATION_TEXT[over.termination]}`, outcome: userWon ? "win" : "loss" };
}
