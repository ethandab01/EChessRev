import { Chess, validateFen, type Move } from "chess.js";

export const START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";

export class ChessParseError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ChessParseError";
  }
}

export interface ParsedGame {
  headers: Record<string, string>;
  /** Starting position (START_FEN unless a [FEN] header is present). */
  startFen: string;
  /** Moves in order, as chess.js verbose moves. */
  moves: Move[];
  /** FEN after each move (index i = after moves[i]). */
  fens: string[];
  result: string;
  /** True if the game starts from a non-standard position. */
  customStart: boolean;
}

const RESULT_TOKENS = new Set(["1-0", "0-1", "1/2-1/2", "*"]);

/**
 * Validate a FEN and produce a specific error message naming the failing field.
 * Accepts 4-field EPD-style FENs by appending "0 1".
 */
export function parseFen(input: string): string {
  const raw = input.trim().replace(/\s+/g, " ");
  if (!raw) throw new ChessParseError("FEN is empty.");
  let fields = raw.split(" ");
  if (fields.length === 4) fields = [...fields, "0", "1"];
  if (fields.length !== 6) {
    throw new ChessParseError(
      `FEN must have 6 space-separated fields (piece placement, active color, castling, en passant, halfmove clock, fullmove number); found ${fields.length}.`,
    );
  }
  const [placement, color, castling, ep, half, full] = fields;

  const ranks = placement.split("/");
  if (ranks.length !== 8) {
    throw new ChessParseError(`FEN field 1 (piece placement) must have 8 ranks separated by "/"; found ${ranks.length}.`);
  }
  ranks.forEach((rank, i) => {
    let count = 0;
    for (const ch of rank) {
      if (/[1-8]/.test(ch)) count += Number(ch);
      else if (/[pnbrqkPNBRQK]/.test(ch)) count++;
      else throw new ChessParseError(`FEN field 1 (piece placement): invalid character "${ch}" in rank ${8 - i}.`);
    }
    if (count !== 8) {
      throw new ChessParseError(`FEN field 1 (piece placement): rank ${8 - i} ("${rank}") describes ${count} squares instead of 8.`);
    }
  });
  const whiteKings = (placement.match(/K/g) || []).length;
  const blackKings = (placement.match(/k/g) || []).length;
  if (whiteKings !== 1) throw new ChessParseError(`FEN field 1 (piece placement): White must have exactly one king; found ${whiteKings}.`);
  if (blackKings !== 1) throw new ChessParseError(`FEN field 1 (piece placement): Black must have exactly one king; found ${blackKings}.`);
  if (/[pP]/.test(ranks[0]) || /[pP]/.test(ranks[7])) {
    throw new ChessParseError("FEN field 1 (piece placement): pawns cannot stand on the 1st or 8th rank.");
  }
  if (color !== "w" && color !== "b") {
    throw new ChessParseError(`FEN field 2 (active color) must be "w" or "b"; got "${color}".`);
  }
  if (!/^(-|K?Q?k?q?)$/.test(castling) || castling === "") {
    throw new ChessParseError(`FEN field 3 (castling availability) must be "-" or a combination of KQkq in that order; got "${castling}".`);
  }
  if (!/^(-|[a-h][36])$/.test(ep)) {
    throw new ChessParseError(`FEN field 4 (en passant square) must be "-" or a square on rank 3 or 6; got "${ep}".`);
  }
  if (!/^\d+$/.test(half)) throw new ChessParseError(`FEN field 5 (halfmove clock) must be a non-negative integer; got "${half}".`);
  if (!/^\d+$/.test(full) || Number(full) < 1) {
    throw new ChessParseError(`FEN field 6 (fullmove number) must be a positive integer; got "${full}".`);
  }
  const fen = fields.join(" ");
  const v = validateFen(fen);
  if (!v.ok) {
    throw new ChessParseError(`Invalid FEN: ${v.error ?? "unknown error"}`);
  }
  // Side not to move must not be in check.
  const otherSide = color === "w" ? "b" : "w";
  try {
    const test = new Chess(fen.replace(` ${color} `, ` ${otherSide} `).replace(/ [a-h][36] /, " - "), { skipValidation: true });
    if (test.inCheck()) {
      throw new ChessParseError(`Invalid FEN: the side not to move (${otherSide === "w" ? "White" : "Black"}) is in check.`);
    }
  } catch (e) {
    if (e instanceof ChessParseError) throw e;
  }
  return fen;
}

/** Remove {comments}, ;line comments, (variations, nested), $NAGs and %escape lines. */
export function stripMovetext(text: string): string {
  let out = "";
  let depth = 0;
  let inBrace = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inBrace) {
      if (c === "}") inBrace = false;
      continue;
    }
    if (c === "{") {
      inBrace = true;
      continue;
    }
    if (c === ";") {
      while (i < text.length && text[i] !== "\n") i++;
      out += " ";
      continue;
    }
    if (c === "(") {
      depth++;
      continue;
    }
    if (c === ")") {
      if (depth > 0) depth--;
      continue;
    }
    if (depth === 0) out += c;
  }
  return out.replace(/\$\d+/g, " ");
}

/** Split text containing one or more PGN games into separate game strings. */
export function splitPgnGames(text: string): string[] {
  const lines = text.replace(/\r\n?/g, "\n").replace(/^﻿/, "").split("\n");
  const games: string[] = [];
  let current: string[] = [];
  let hasMoves = false;
  const flush = () => {
    const g = current.join("\n").trim();
    if (g) games.push(g);
    current = [];
    hasMoves = false;
  };
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.startsWith("%")) continue;
    const isHeader = /^\[\s*\w+\s+".*"\s*\]$/.test(trimmed);
    if (isHeader && hasMoves) flush();
    current.push(line);
    if (!isHeader && trimmed) {
      hasMoves = true;
      // A result token at the end of movetext also terminates a game (header-less multi-game input).
      const stripped = stripMovetext(trimmed).trim();
      const last = stripped.split(/\s+/).pop() ?? "";
      if (RESULT_TOKENS.has(last)) flush();
    }
  }
  flush();
  return games;
}

function parseHeaders(text: string): { headers: Record<string, string>; movetext: string } {
  const headers: Record<string, string> = {};
  const body: string[] = [];
  for (const line of text.split("\n")) {
    const m = line.trim().match(/^\[\s*(\w+)\s+"((?:[^"\\]|\\.)*)"\s*\]$/);
    if (m) headers[m[1]] = m[2].replace(/\\(.)/g, "$1");
    else body.push(line);
  }
  return { headers, movetext: body.join("\n") };
}

/** Normalise common SAN variants (0-0, x-less long algebraic, e.p. suffix, annotation glyphs). */
function normaliseSan(tok: string): string {
  return tok
    .replace(/^0-0-0/, "O-O-O")
    .replace(/^0-0/, "O-O")
    .replace(/e\.p\.$/i, "")
    .replace(/[!?]+$/, "")
    .replace(/[+#]+$/, (m) => m[0]);
}

/**
 * Parse a single PGN game. Headers are optional; comments, variations and NAGs are stripped.
 * Throws ChessParseError naming the exact move (number, side and SAN) that failed.
 */
export function parsePgn(text: string): ParsedGame {
  const source = text.replace(/\r\n?/g, "\n").trim();
  if (!source) throw new ChessParseError("PGN is empty.");
  const { headers, movetext } = parseHeaders(source);

  let startFen = START_FEN;
  if (headers.FEN) {
    try {
      startFen = parseFen(headers.FEN);
    } catch (e) {
      throw new ChessParseError(`[FEN "${headers.FEN}"] header is invalid: ${(e as Error).message}`);
    }
  }
  const chess = new Chess(startFen);
  const tokens = stripMovetext(movetext)
    .replace(/(\d+)\.(\.\.)?/g, "$1. ") // "12.e4" / "12...e5" → separate number
    .split(/\s+/)
    .filter(Boolean);

  const moves: Move[] = [];
  const fens: string[] = [];
  let result = headers.Result ?? "*";
  for (const tok of tokens) {
    if (/^\d+\.+$/.test(tok) || /^\.+$/.test(tok)) continue;
    if (RESULT_TOKENS.has(tok)) {
      result = tok;
      break;
    }
    const san = normaliseSan(tok);
    if (!san) continue;
    const moveNo = chess.moveNumber();
    const side = chess.turn() === "w" ? "White" : "Black";
    const label = `${moveNo}${chess.turn() === "w" ? "." : "..."} ${tok}`;
    if (!/^([NBRQK]?[a-h]?[1-8]?x?[a-h][1-8](=?[NBRQnbrq])?|O-O(-O)?)[+#]?$/.test(san) && !/^[a-h][1-8][a-h][1-8][nbrq]?$/.test(san)) {
      throw new ChessParseError(`Move ${label} (${side}): "${tok}" is not valid move notation.`);
    }
    let m: Move;
    try {
      m = /^[a-h][1-8][a-h][1-8][nbrq]?$/.test(san)
        ? chess.move({ from: san.slice(0, 2), to: san.slice(2, 4), promotion: san[4] })
        : chess.move(san.replace(/=?([NBRQnbrq])([+#]?)$/, (_, p: string, s: string) => `=${p.toUpperCase()}${s}`));
    } catch {
      const reason = chess.isCheckmate()
        ? "the game is already over by checkmate"
        : chess.inCheck()
          ? `it does not resolve the check on ${side}'s king or is not a legal move`
          : "it is not a legal move in this position";
      throw new ChessParseError(`Move ${label} (${side}): "${tok}" is illegal — ${reason}.`);
    }
    moves.push(m);
    fens.push(chess.fen());
  }
  if (moves.length === 0 && !headers.FEN) {
    throw new ChessParseError("PGN contains no moves.");
  }
  return { headers, startFen, moves, fens, result, customStart: startFen !== START_FEN };
}

/** Parse every game in the text; collects errors per game instead of failing everything. */
export function parseMultiPgn(text: string): Array<{ index: number; raw: string; game?: ParsedGame; error?: string }> {
  const parts = splitPgnGames(text);
  if (parts.length === 0) throw new ChessParseError("PGN is empty.");
  return parts.map((raw, index) => {
    try {
      return { index, raw, game: parsePgn(raw) };
    } catch (e) {
      return { index, raw, error: (e as Error).message };
    }
  });
}

/** Build a PGN string from moves. */
export function buildPgn(opts: {
  moves: Array<Pick<Move, "san">>;
  startFen?: string;
  headers?: Record<string, string>;
  result?: string;
}): string {
  const result = opts.result ?? "*";
  const headers: Record<string, string> = {
    Event: "Casual game",
    Site: "EChessREV",
    Date: new Date().toISOString().slice(0, 10).replace(/-/g, "."),
    White: "?",
    Black: "?",
    ...opts.headers,
    Result: result,
  };
  const start = opts.startFen ?? START_FEN;
  if (start !== START_FEN) {
    headers.SetUp = "1";
    headers.FEN = start;
  }
  const head = Object.entries(headers)
    .map(([k, v]) => `[${k} "${String(v).replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"]`)
    .join("\n");
  const fenParts = start.split(" ");
  let moveNo = Number(fenParts[5] ?? 1);
  let turn = fenParts[1] ?? "w";
  const parts: string[] = [];
  opts.moves.forEach((m, i) => {
    if (turn === "w") parts.push(`${moveNo}. ${m.san}`);
    else parts.push(i === 0 ? `${moveNo}... ${m.san}` : m.san);
    if (turn === "b") moveNo++;
    turn = turn === "w" ? "b" : "w";
  });
  parts.push(result);
  // Wrap movetext at ~80 chars.
  const lines: string[] = [];
  let line = "";
  for (const p of parts) {
    if ((line + " " + p).trim().length > 80) {
      lines.push(line.trim());
      line = p;
    } else line += " " + p;
  }
  if (line.trim()) lines.push(line.trim());
  return `${head}\n\n${lines.join("\n")}\n`;
}

/** Display names for a game from its headers. */
export function gameTitle(headers: Record<string, string>, fallbackIndex?: number): string {
  const w = headers.White && headers.White !== "?" ? headers.White : "White";
  const b = headers.Black && headers.Black !== "?" ? headers.Black : "Black";
  const extra = [headers.Event && headers.Event !== "?" ? headers.Event : "", headers.Date && !headers.Date.includes("?") ? headers.Date : ""]
    .filter(Boolean)
    .join(", ");
  const base = `${w} vs ${b}${headers.Result ? ` (${headers.Result})` : ""}`;
  return extra ? `${base} — ${extra}` : fallbackIndex !== undefined ? `${base} — Game ${fallbackIndex + 1}` : base;
}
