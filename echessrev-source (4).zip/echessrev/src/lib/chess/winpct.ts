import type { Score } from "./types";

/**
 * Win probability (0..100) for a centipawn score from the mover's perspective.
 * winPct(cp) = 50 + 50 * (2 / (1 + exp(-0.00368208 * cp)) - 1)
 */
export function winPct(cp: number): number {
  return 50 + 50 * (2 / (1 + Math.exp(-0.00368208 * cp)) - 1);
}

/** Win% for an engine score (side-to-move perspective). Mate scores map to 100 / 0. */
export function scoreToWinPct(score: Score): number {
  if (score.mate !== undefined) {
    if (score.mate > 0) return 100;
    return 0; // mate <= 0: side to move is getting mated (or already mated)
  }
  return winPct(score.cp ?? 0);
}

/** Flip a score to the other side's perspective. */
export function negateScore(score: Score): Score {
  if (score.mate !== undefined) return { mate: -score.mate };
  return { cp: -(score.cp ?? 0) };
}

/**
 * Expected-points loss of a move, 0..1.
 * EPL = (winPct before the move with best play − winPct after the move played) / 100,
 * both from the mover's perspective. Never negative.
 */
export function expectedPointsLoss(winBefore: number, winAfter: number): number {
  return Math.max(0, (winBefore - winAfter) / 100);
}

/** Convert a score to a signed "white-perspective" centipawn number for display / graphs (mate ≈ ±10000). */
export function scoreToWhiteCp(score: Score, sideToMove: "w" | "b"): number {
  const sign = sideToMove === "w" ? 1 : -1;
  if (score.mate !== undefined) {
    const m = score.mate;
    return sign * (m > 0 ? 10000 - m : -10000 - m);
  }
  return sign * (score.cp ?? 0);
}

/** White's win% (0..100) for a score given from the side-to-move's perspective. */
export function whiteWinPct(score: Score, sideToMove: "w" | "b"): number {
  const w = scoreToWinPct(score);
  return sideToMove === "w" ? w : 100 - w;
}

/** Human-readable eval from White's perspective: "+1.25", "-0.40", "M3", "-M2", or "1-0"/"0-1" when mated. */
export function formatScore(score: Score, sideToMove: "w" | "b"): string {
  const sign = sideToMove === "w" ? 1 : -1;
  if (score.mate !== undefined) {
    if (score.mate === 0) return sideToMove === "w" ? "0-1" : "1-0";
    const m = score.mate * sign;
    return m > 0 ? `M${m}` : `-M${-m}`;
  }
  const v = (sign * (score.cp ?? 0)) / 100;
  return `${v > 0 ? "+" : ""}${v.toFixed(2)}`;
}
