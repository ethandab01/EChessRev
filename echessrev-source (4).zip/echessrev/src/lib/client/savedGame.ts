"use client";

/** In-progress game persisted to localStorage so a user can leave and resume. */
const KEY = "echessrev:current-game";

export interface SavedGameState {
  version: 1;
  startFen: string;
  moves: string[]; // UCI
  userColor: "w" | "b";
  botId: string;
  timeControl: string;
  clocks: { w: number; b: number } | null;
  takebacks: boolean;
  savedAt: number;
}

export function loadSavedGame(): SavedGameState | null {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const s = JSON.parse(raw) as SavedGameState;
    return s.version === 1 ? s : null;
  } catch {
    return null;
  }
}

export function saveGameState(s: SavedGameState) {
  try {
    localStorage.setItem(KEY, JSON.stringify(s));
  } catch {
    /* ignore */
  }
}

export function clearSavedGame() {
  try {
    localStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
}
