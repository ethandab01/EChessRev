"use client";

import { useEffect, useState } from "react";

export interface OnlineCounts {
  players: number;
  games: number;
  seeks: number;
}

function clientId(): string {
  try {
    let id = localStorage.getItem("echessrev:client");
    if (!id) {
      id = Math.random().toString(36).slice(2) + Date.now().toString(36);
      localStorage.setItem("echessrev:client", id);
    }
    return id;
  } catch {
    return "anon" + Math.random().toString(36).slice(2, 12);
  }
}

/** Sends a heartbeat every 25 s (counts this browser as online) and returns the latest counts. */
export function usePresence(): OnlineCounts | null {
  const [counts, setCounts] = useState<OnlineCounts | null>(null);
  useEffect(() => {
    const id = clientId();
    let stopped = false;
    const beat = () => {
      if (document.visibilityState === "hidden") return;
      fetch("/api/presence", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ clientId: id }) })
        .then((r) => (r.ok ? r.json() : null))
        .then((j) => !stopped && j && setCounts(j))
        .catch(() => undefined);
    };
    beat();
    const t = setInterval(beat, 25_000);
    const onVis = () => document.visibilityState === "visible" && beat();
    document.addEventListener("visibilitychange", onVis);
    return () => {
      stopped = true;
      clearInterval(t);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, []);
  return counts;
}

/** Just the counts, refreshed every `ms` (no heartbeat). */
export function useOnlineCounts(ms = 8000): OnlineCounts | null {
  const [counts, setCounts] = useState<OnlineCounts | null>(null);
  useEffect(() => {
    let stopped = false;
    const load = () =>
      fetch("/api/presence")
        .then((r) => (r.ok ? r.json() : null))
        .then((j) => !stopped && j && setCounts(j))
        .catch(() => undefined);
    load();
    const t = setInterval(load, ms);
    return () => {
      stopped = true;
      clearInterval(t);
    };
  }, [ms]);
  return counts;
}
