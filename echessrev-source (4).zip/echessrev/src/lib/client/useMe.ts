"use client";

import { useCallback, useEffect, useState } from "react";
import { useSession } from "next-auth/react";

export interface Me {
  /** Spendable balance (earned − spent). */
  points: number;
  /** Lifetime points earned. */
  earned: number;
  boardTheme: string;
  avatarIcon: string | null;
  flair: string | null;
  winEffect: string;
  pendingFriendRequests: number;
  puzzleRating: number;
  puzzleStreak: number;
  username: string | null;
  friendRating: number;
  /** Incoming friend-game challenges. */
  challenges: number;
  /** Friend games where it's your move. */
  yourTurn: number;
}

/** Signed-in user's stats. Refreshes on the "points-changed" event. */
export function useMe() {
  const { status } = useSession();
  const [me, setMe] = useState<Me | null>(null);
  const load = useCallback(() => {
    fetch("/api/me")
      .then((r) => (r.ok ? r.json() : null))
      .then((j) => j && setMe(j))
      .catch(() => undefined);
  }, []);
  useEffect(() => {
    if (status !== "authenticated") {
      setMe(null);
      return;
    }
    load();
    // Poll so challenges and "your move" badges show up without a refresh.
    const id = setInterval(load, 15000);
    window.addEventListener("points-changed", load);
    return () => {
      clearInterval(id);
      window.removeEventListener("points-changed", load);
    };
  }, [status, load]);
  return me;
}

export function notifyPointsChanged() {
  window.dispatchEvent(new Event("points-changed"));
}
