"use client";

/** Pass a game between pages (e.g. Play → Review) without putting it in the URL. */
const KEY = "echessrev:handoff";

export interface Handoff {
  pgn: string;
  gameId?: string;
  title?: string;
}

export function setHandoff(h: Handoff) {
  try {
    sessionStorage.setItem(KEY, JSON.stringify(h));
  } catch {
    /* ignore */
  }
}

export function getHandoff(): Handoff | null {
  try {
    const raw = sessionStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Handoff) : null;
  } catch {
    return null;
  }
}
