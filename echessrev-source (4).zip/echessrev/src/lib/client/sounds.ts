"use client";

/** Tiny synthesized move sounds (no audio assets needed). */
let ctx: AudioContext | null = null;
let muted = false;

try {
  muted = typeof localStorage !== "undefined" && localStorage.getItem("muted") === "1";
} catch {
  /* ignore */
}

export function isMuted() {
  return muted;
}
export function setMuted(m: boolean) {
  muted = m;
  try {
    localStorage.setItem("muted", m ? "1" : "0");
  } catch {
    /* ignore */
  }
}

function tone(freq: number, duration: number, type: OscillatorType, gain: number, delay = 0) {
  if (muted || typeof window === "undefined") return;
  try {
    ctx ??= new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    const t = ctx.currentTime + delay;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    osc.frequency.exponentialRampToValueAtTime(Math.max(40, freq * 0.6), t + duration);
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + duration);
    osc.connect(g).connect(ctx.destination);
    osc.start(t);
    osc.stop(t + duration + 0.02);
  } catch {
    /* audio unavailable */
  }
}

export type SoundKind = "move" | "capture" | "check" | "castle" | "promote" | "end" | "illegal";

export function playSound(kind: SoundKind) {
  switch (kind) {
    case "move":
      return tone(420, 0.07, "triangle", 0.25);
    case "capture":
      tone(260, 0.09, "square", 0.12);
      return tone(180, 0.1, "triangle", 0.2, 0.02);
    case "check":
      tone(660, 0.08, "sine", 0.2);
      return tone(880, 0.12, "sine", 0.18, 0.08);
    case "castle":
      tone(400, 0.06, "triangle", 0.22);
      return tone(380, 0.06, "triangle", 0.22, 0.08);
    case "promote":
      tone(520, 0.08, "sine", 0.2);
      return tone(780, 0.14, "sine", 0.2, 0.08);
    case "end":
      tone(520, 0.15, "sine", 0.2);
      tone(390, 0.2, "sine", 0.2, 0.15);
      return tone(260, 0.3, "sine", 0.2, 0.32);
    case "illegal":
      return tone(140, 0.12, "sawtooth", 0.08);
  }
}

export function soundForSan(san: string, captured?: string): SoundKind {
  if (san.includes("#")) return "end";
  if (san.includes("+")) return "check";
  if (san.includes("=")) return "promote";
  if (san.startsWith("O-O")) return "castle";
  if (captured || san.includes("x")) return "capture";
  return "move";
}
