"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { StockfishEngine } from "@/lib/engine/engine";

export type EngineStatus = "loading" | "ready" | "error";

/** Creates (and tears down) a Stockfish worker. Exposes a retry for load failures. */
export function useEngine(enabled = true) {
  const [engine, setEngine] = useState<StockfishEngine | null>(null);
  const [status, setStatus] = useState<EngineStatus>("loading");
  const [error, setError] = useState<string>("");
  const [attempt, setAttempt] = useState(0);
  const ref = useRef<StockfishEngine | null>(null);

  useEffect(() => {
    if (!enabled) return;
    let cancelled = false;
    setStatus("loading");
    setError("");
    StockfishEngine.create()
      .then((e) => {
        if (cancelled) return e.terminate();
        ref.current = e;
        setEngine(e);
        setStatus("ready");
      })
      .catch((e: Error) => {
        if (cancelled) return;
        setStatus("error");
        setError(e.message || "The engine failed to load.");
      });
    return () => {
      cancelled = true;
      ref.current?.terminate();
      ref.current = null;
      setEngine(null);
    };
  }, [enabled, attempt]);

  const retry = useCallback(() => setAttempt((a) => a + 1), []);
  return { engine, status, error, retry };
}
