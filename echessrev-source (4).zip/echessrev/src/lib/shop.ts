/** Cosmetic shop catalogue. Prices are in points (◆). Free items are owned by everyone. */
export type ShopCategory = "board" | "avatar" | "flair" | "effect";

export interface ShopItem {
  id: string;
  category: ShopCategory;
  name: string;
  price: number;
  /** board: [light, dark] colors; avatar/flair: emoji; effect: particle glyphs. */
  value: string | [string, string];
}

export const SHOP_ITEMS: ShopItem[] = [
  // Board themes
  { id: "board-classic", category: "board", name: "Slate", price: 0, value: ["#d9dde3", "#6c82a3"] },
  { id: "board-forest", category: "board", name: "Forest", price: 150, value: ["#e3e8cf", "#6f955b"] },
  { id: "board-walnut", category: "board", name: "Walnut", price: 250, value: ["#ecd3ac", "#a57449"] },
  { id: "board-ice", category: "board", name: "Glacier", price: 300, value: ["#e9f2f8", "#7fa8c6"] },
  { id: "board-rose", category: "board", name: "Rose", price: 400, value: ["#f4e1e4", "#c47d90"] },
  { id: "board-sand", category: "board", name: "Desert", price: 400, value: ["#f3e6c8", "#c79f62"] },
  { id: "board-midnight", category: "board", name: "Midnight", price: 600, value: ["#a9b2c4", "#3b4862"] },
  { id: "board-lava", category: "board", name: "Lava", price: 800, value: ["#f3d8b8", "#c4512f"] },
  { id: "board-royal", category: "board", name: "Royal", price: 1200, value: ["#e7dcf5", "#7a52b3"] },
  { id: "board-gold", category: "board", name: "Golden", price: 2000, value: ["#f7e8b7", "#c29832"] },
  // Avatars
  { id: "avatar-knight", category: "avatar", name: "Knight", price: 100, value: "♞" },
  { id: "avatar-fox", category: "avatar", name: "Fox", price: 150, value: "🦊" },
  { id: "avatar-owl", category: "avatar", name: "Owl", price: 150, value: "🦉" },
  { id: "avatar-robot", category: "avatar", name: "Robot", price: 200, value: "🤖" },
  { id: "avatar-octopus", category: "avatar", name: "Octopus", price: 200, value: "🐙" },
  { id: "avatar-lightning", category: "avatar", name: "Lightning", price: 250, value: "⚡" },
  { id: "avatar-fire", category: "avatar", name: "Fire", price: 300, value: "🔥" },
  { id: "avatar-dragon", category: "avatar", name: "Dragon", price: 500, value: "🐉" },
  { id: "avatar-crown", category: "avatar", name: "Crown", price: 750, value: "👑" },
  { id: "avatar-diamond", category: "avatar", name: "Diamond", price: 1500, value: "💎" },
  // Name flairs
  { id: "flair-star", category: "flair", name: "Star", price: 100, value: "⭐" },
  { id: "flair-target", category: "flair", name: "Sharpshooter", price: 200, value: "🎯" },
  { id: "flair-moon", category: "flair", name: "Night Owl", price: 200, value: "🌙" },
  { id: "flair-brain", category: "flair", name: "Big Brain", price: 300, value: "🧠" },
  { id: "flair-rocket", category: "flair", name: "Speedster", price: 300, value: "🚀" },
  { id: "flair-skull", category: "flair", name: "Ruthless", price: 400, value: "💀" },
  { id: "flair-trophy", category: "flair", name: "Champion", price: 800, value: "🏆" },
  { id: "flair-gem", category: "flair", name: "Legend", price: 2500, value: "💠" },
  // Win effects
  { id: "effect-confetti", category: "effect", name: "Confetti", price: 0, value: "" },
  { id: "effect-stars", category: "effect", name: "Shooting Stars", price: 300, value: "⭐✨🌟" },
  { id: "effect-hearts", category: "effect", name: "Hearts", price: 300, value: "❤️💖💕" },
  { id: "effect-snow", category: "effect", name: "Snowfall", price: 300, value: "❄️❅❆" },
  { id: "effect-coins", category: "effect", name: "Coin Rain", price: 500, value: "🪙💰" },
  { id: "effect-pieces", category: "effect", name: "Piece Storm", price: 600, value: "♛♜♝♞♟" },
  { id: "effect-fireworks", category: "effect", name: "Fireworks", price: 900, value: "🎆🎇✨" },
];

export const SHOP_BY_ID = new Map(SHOP_ITEMS.map((i) => [i.id, i]));

export const CATEGORY_LABEL: Record<ShopCategory, string> = { board: "Board themes", avatar: "Avatars", flair: "Name flair", effect: "Win effects" };

/** User column holding the equipped item for each category. */
export const EQUIP_FIELD = { board: "boardTheme", avatar: "avatarIcon", flair: "flair", effect: "winEffect" } as const;

export function boardColors(id: string | null | undefined): [string, string] | null {
  const item = id ? SHOP_BY_ID.get(id.startsWith("board-") ? id : `board-${id}`) : undefined;
  return item && Array.isArray(item.value) ? item.value : null;
}

export function itemValue(id: string | null | undefined): string | null {
  const v = id ? SHOP_BY_ID.get(id)?.value : null;
  return typeof v === "string" && v ? v : null;
}
