import type { EngineLine, Score } from "@/lib/chess/types";

/** Parse a UCI "info" line. Returns null for lines without a score + pv (e.g. currmove info). */
export function parseInfo(line: string): EngineLine | null {
  if (!line.startsWith("info ")) return null;
  const tokens = line.split(/\s+/);
  let depth = 0;
  let multipv = 1;
  let score: Score | null = null;
  let pv: string[] = [];
  let bound = false;
  for (let i = 1; i < tokens.length; i++) {
    const t = tokens[i];
    if (t === "depth") depth = Number(tokens[++i]);
    else if (t === "multipv") multipv = Number(tokens[++i]);
    else if (t === "score") {
      const kind = tokens[++i];
      const val = Number(tokens[++i]);
      score = kind === "mate" ? { mate: val } : { cp: val };
      if (tokens[i + 1] === "lowerbound" || tokens[i + 1] === "upperbound") {
        bound = true;
        i++;
      }
    } else if (t === "pv") {
      pv = tokens.slice(i + 1);
      break;
    }
  }
  if (!score || pv.length === 0 || bound) return null;
  return { depth, multipv, score, pv };
}

export function parseBestMove(line: string): string | null {
  const m = line.match(/^bestmove\s+(\S+)/);
  if (!m) return null;
  return m[1] === "(none)" ? null : m[1];
}
