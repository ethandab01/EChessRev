"use client";

import type { EngineLine } from "@/lib/chess/types";
import { parseBestMove, parseInfo } from "./uci";

export const ENGINE_URL = "/engine/stockfish.js";

export interface SearchOptions {
  depth?: number;
  movetime?: number;
  multipv?: number;
  /** Called with the current set of lines every time a new info line arrives. */
  onInfo?: (lines: EngineLine[]) => void;
  signal?: AbortSignal;
}

export interface SearchResult {
  lines: EngineLine[];
  bestmove: string | null;
}

export class EngineLoadError extends Error {}
export class SearchAbortedError extends Error {
  constructor() {
    super("Search aborted");
  }
}

type Listener = (line: string) => void;

/**
 * Thin promise-based wrapper around the Stockfish WASM web worker.
 * All searches are serialized through an internal queue, so callers can fire
 * requests without coordinating with each other.
 */
export class StockfishEngine {
  private worker: Worker;
  private listeners = new Set<Listener>();
  private queue: Promise<unknown> = Promise.resolve();
  private options = new Map<string, string>();
  private dead = false;

  private constructor(worker: Worker) {
    this.worker = worker;
    worker.onmessage = (e: MessageEvent) => {
      const data = typeof e.data === "string" ? e.data : String(e.data);
      for (const raw of data.split("\n")) {
        const line = raw.trim();
        if (line) for (const l of this.listeners) l(line);
      }
    };
  }

  static async create(timeoutMs = 20000): Promise<StockfishEngine> {
    if (typeof Worker === "undefined" || typeof WebAssembly === "undefined") {
      throw new EngineLoadError("This browser does not support Web Workers / WebAssembly.");
    }
    try {
      const head = await fetch(ENGINE_URL, { method: "HEAD" });
      if (head.status === 404) {
        throw new EngineLoadError("The engine files are missing. Run `npm install` again in the project folder.");
      }
    } catch (e) {
      if (e instanceof EngineLoadError) throw e;
    }
    let worker: Worker;
    try {
      worker = new Worker(ENGINE_URL);
    } catch (e) {
      throw new EngineLoadError(`Could not start the engine worker: ${(e as Error).message}`);
    }
    const engine = new StockfishEngine(worker);
    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => {
        cleanup();
        worker.terminate();
        reject(new EngineLoadError("The engine took too long to load."));
      }, timeoutMs);
      const onLine = (line: string) => {
        if (line === "uciok") {
          cleanup();
          resolve();
        }
      };
      const onError = (e: ErrorEvent) => {
        cleanup();
        worker.terminate();
        reject(new EngineLoadError(`The engine failed to load${e.message ? `: ${e.message}` : ""}.`));
      };
      const cleanup = () => {
        clearTimeout(timer);
        engine.listeners.delete(onLine);
        worker.removeEventListener("error", onError);
      };
      engine.listeners.add(onLine);
      worker.addEventListener("error", onError);
      worker.postMessage("uci");
    });
    await engine.isReady();
    return engine;
  }

  private send(cmd: string) {
    if (!this.dead) this.worker.postMessage(cmd);
  }

  private waitFor(predicate: (line: string) => boolean): Promise<string> {
    return new Promise((resolve) => {
      const l = (line: string) => {
        if (predicate(line)) {
          this.listeners.delete(l);
          resolve(line);
        }
      };
      this.listeners.add(l);
    });
  }

  async isReady(): Promise<void> {
    const p = this.waitFor((l) => l === "readyok");
    this.send("isready");
    await p;
  }

  /** Set a UCI option (skipped if it already has that value). Must be called between searches. */
  setOption(name: string, value: string | number | boolean) {
    const v = String(value);
    if (this.options.get(name) === v) return;
    this.options.set(name, v);
    this.send(`setoption name ${name} value ${v}`);
  }

  /** Configure full strength analysis mode. */
  setFullStrength() {
    this.setOption("UCI_LimitStrength", false);
    this.setOption("Skill Level", 20);
  }

  newGame(): Promise<void> {
    return this.enqueue(async () => {
      this.send("ucinewgame");
      await this.isReady();
    });
  }

  /**
   * Run a search. `configure` runs right before the search starts (inside the queue),
   * which is where callers should set strength options.
   */
  search(fen: string, opts: SearchOptions & { configure?: (e: StockfishEngine) => void } = {}): Promise<SearchResult> {
    return this.enqueue(() => this.runSearch(fen, opts));
  }

  private enqueue<T>(job: () => Promise<T>): Promise<T> {
    const next = this.queue.then(job, job);
    this.queue = next.catch(() => undefined);
    return next;
  }

  private async runSearch(
    fen: string,
    opts: SearchOptions & { configure?: (e: StockfishEngine) => void },
  ): Promise<SearchResult> {
    if (this.dead) throw new EngineLoadError("Engine has been terminated.");
    if (opts.signal?.aborted) throw new SearchAbortedError();
    opts.configure?.(this);
    this.setOption("MultiPV", opts.multipv ?? 1);
    await this.isReady();

    const lines = new Map<number, EngineLine>();
    const collect = () => [...lines.values()].sort((a, b) => a.multipv - b.multipv);

    return new Promise<SearchResult>((resolve, reject) => {
      let aborted = false;
      const onAbort = () => {
        aborted = true;
        this.send("stop");
      };
      opts.signal?.addEventListener("abort", onAbort);
      const listener = (line: string) => {
        const info = parseInfo(line);
        if (info) {
          lines.set(info.multipv, info);
          opts.onInfo?.(collect());
          return;
        }
        if (line.startsWith("bestmove")) {
          this.listeners.delete(listener);
          opts.signal?.removeEventListener("abort", onAbort);
          if (aborted) reject(new SearchAbortedError());
          else resolve({ lines: collect(), bestmove: parseBestMove(line) });
        }
      };
      this.listeners.add(listener);
      this.send(`position fen ${fen}`);
      if (opts.movetime) this.send(`go movetime ${Math.max(10, Math.round(opts.movetime))}`);
      else this.send(`go depth ${opts.depth ?? 16}`);
    });
  }

  /** Stop the current search (it still resolves with its best result so far). */
  stop() {
    this.send("stop");
  }

  terminate() {
    this.dead = true;
    this.worker.terminate();
    this.listeners.clear();
  }
}
