import type { Metadata } from "next";
import { Suspense } from "react";
import { googleEnabled } from "@/auth";
import { AuthForm } from "@/components/AuthForm";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Create account" };

export default function RegisterPage() {
  return (
    <Suspense>
      <AuthForm mode="register" googleEnabled={googleEnabled} />
    </Suspense>
  );
}
