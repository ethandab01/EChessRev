"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { CATEGORY_LABEL, type ShopCategory, type ShopItem } from "@/lib/shop";
import { notifyPointsChanged } from "@/lib/client/useMe";
import { Confetti, EmojiRain } from "@/components/GameOverFx";

interface ShopData {
  items: ShopItem[];
  owned: string[];
  equipped: Partial<Record<ShopCategory, string | null>>;
  balance: number;
  earned?: number;
  signedIn: boolean;
}

const CATS: ShopCategory[] = ["board", "avatar", "flair", "effect"];

function BoardPreview({ colors }: { colors: [string, string] }) {
  return (
    <div className="grid aspect-square w-full grid-cols-4 overflow-hidden rounded-lg" aria-hidden>
      {Array.from({ length: 16 }, (_, i) => {
        const dark = (Math.floor(i / 4) + i) % 2 === 1;
        const piece = i === 5 ? "♞" : i === 10 ? "♝" : i === 15 ? "♔" : i === 2 ? "♜" : "";
        return (
          <div key={i} className="flex items-center justify-center text-2xl" style={{ background: dark ? colors[1] : colors[0], color: i === 2 ? "#111" : "#fff", textShadow: i === 2 ? "none" : "0 0 2px #000, 0 0 1px #000" }}>
            {piece}
          </div>
        );
      })}
    </div>
  );
}

export function ShopClient() {
  const { status, data: session } = useSession();
  const [data, setData] = useState<ShopData | null>(null);
  const [cat, setCat] = useState<ShopCategory>("board");
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [preview, setPreview] = useState<{ id: string; key: number } | null>(null);
  const [flash, setFlash] = useState<string | null>(null);

  const load = useCallback(async () => {
    const r = await fetch("/api/shop", { cache: "no-store" });
    if (r.ok) setData(await r.json());
  }, []);
  useEffect(() => {
    if (status !== "loading") load();
  }, [status, load]);

  const buy = async (item: ShopItem) => {
    setMsg(null);
    setBusy(item.id);
    const r = await fetch("/api/shop/buy", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ itemId: item.id }) });
    const j = await r.json().catch(() => ({}));
    setBusy(null);
    if (!r.ok) return setMsg({ ok: false, text: j.error ?? "Couldn't buy that." });
    setFlash(item.id);
    setTimeout(() => setFlash(null), 1200);
    setMsg({ ok: true, text: `You bought ${item.name}! Equip it below.` });
    await load();
    notifyPointsChanged();
  };

  const equip = async (item: ShopItem | null, category: ShopCategory) => {
    setBusy(item?.id ?? category);
    await fetch("/api/shop/equip", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ category, itemId: item?.id ?? null }) });
    setBusy(null);
    await load();
    notifyPointsChanged();
  };

  const owned = new Set(data?.owned ?? []);
  const items = (data?.items ?? []).filter((i) => i.category === cat);
  const name = session?.user?.username ?? "You";

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end gap-4">
        <div>
          <h1 className="text-3xl font-extrabold">Shop</h1>
          <p className="text-muted">Spend the ◆ you earn from wins, reviews and puzzles.</p>
        </div>
        {data?.signedIn && (
          <div className="ml-auto rounded-xl bg-gold-soft px-5 py-3 text-right">
            <div className="text-xs font-bold uppercase tracking-wider text-gold">Balance</div>
            <div key={data.balance} className="text-3xl font-extrabold tabular-nums text-gold animate-pop">◆ {data.balance.toLocaleString()}</div>
          </div>
        )}
      </div>

      {status === "unauthenticated" && (
        <div className="card flex flex-wrap items-center gap-3">
          <span className="flex-1 font-bold">Sign in to earn ◆ and unlock themes, avatars, flair and win effects.</span>
          <Link href="/register" className="btn-primary">Sign Up</Link>
          <Link href="/login?callbackUrl=/shop" className="btn">Log In</Link>
        </div>
      )}

      <div className="flex gap-1 overflow-x-auto border-b border-line" role="tablist" aria-label="Shop categories">
        {CATS.map((c) => (
          <button key={c} type="button" role="tab" aria-selected={cat === c} onClick={() => setCat(c)} className={`relative shrink-0 px-5 py-3 text-sm font-extrabold transition ${cat === c ? "text-accent" : "text-muted hover:text-fg"}`}>
            {CATEGORY_LABEL[c]}
            {cat === c && <span className="absolute inset-x-2 -bottom-px h-0.5 rounded-full bg-accent" />}
          </button>
        ))}
      </div>

      {msg && <p role="status" className={`rounded-lg px-3 py-2 text-sm font-bold animate-fade-in ${msg.ok ? "bg-accent-soft text-accent" : "bg-bad/15 text-bad"}`}>{msg.text}</p>}

      {(cat === "avatar" || cat === "flair") && data?.signedIn && (data.equipped[cat] ?? null) && (
        <button type="button" className="btn text-xs" onClick={() => equip(null, cat)}>Remove {cat === "avatar" ? "avatar" : "flair"}</button>
      )}

      {!data ? (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">{Array.from({ length: 10 }, (_, i) => <div key={i} className="skeleton h-56" />)}</div>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
          {items.map((item, i) => {
            const isOwned = owned.has(item.id);
            const isEquipped = data.equipped[cat] === item.id;
            const affordable = data.balance >= item.price;
            return (
              <article
                key={item.id}
                className={`relative flex flex-col overflow-hidden rounded-xl bg-panel p-3 transition hover:-translate-y-1 hover:shadow-xl animate-fade-up ${isEquipped ? "ring-2 ring-accent" : ""} ${flash === item.id ? "animate-pop" : ""}`}
                style={{ animationDelay: `${i * 30}ms` }}
              >
                {isEquipped && <span className="absolute right-2 top-2 z-10 rounded-md bg-accent px-1.5 py-0.5 text-[10px] font-extrabold text-white">EQUIPPED</span>}
                <div className="relative mb-3 flex aspect-square items-center justify-center overflow-hidden rounded-lg bg-panel-2">
                  {item.category === "board" && Array.isArray(item.value) && <BoardPreview colors={item.value} />}
                  {item.category === "avatar" && <span className="text-6xl transition group-hover:scale-110">{item.value as string}</span>}
                  {item.category === "flair" && (
                    <span className="px-2 text-center text-lg font-extrabold">{name} <span className="text-2xl">{item.value as string}</span></span>
                  )}
                  {item.category === "effect" && (
                    <>
                      <span className="text-5xl">{(item.value as string) ? Array.from(item.value as string)[0] : "🎊"}</span>
                      {preview?.id === item.id && (
                        <div key={preview.key} className="absolute inset-0">
                          {item.id === "effect-confetti" ? <Confetti count={30} /> : <EmojiRain glyphs={item.id === "effect-fireworks" ? "🎆🎇✨" : (item.value as string)} count={18} />}
                        </div>
                      )}
                    </>
                  )}
                </div>
                <div className="font-extrabold">{item.name}</div>
                <div className="mb-3 text-sm font-bold text-gold">{item.price === 0 ? "Free" : `◆ ${item.price.toLocaleString()}`}</div>
                <div className="mt-auto space-y-1.5">
                  {item.category === "effect" && (
                    <button type="button" className="btn w-full py-1.5 text-xs" onClick={() => setPreview({ id: item.id, key: Date.now() })}>▶ Preview</button>
                  )}
                  {!data.signedIn ? null : isEquipped ? (
                    <button type="button" className="btn w-full py-2 text-sm" disabled>✓ Equipped</button>
                  ) : isOwned ? (
                    <button type="button" className="btn-primary w-full py-2 text-sm" onClick={() => equip(item, cat)} disabled={busy === item.id}>Equip</button>
                  ) : (
                    <button type="button" className={`w-full py-2 text-sm ${affordable ? "btn-primary" : "btn"}`} onClick={() => buy(item)} disabled={!affordable || busy === item.id} title={affordable ? undefined : `Need ${item.price - data.balance} more ◆`}>
                      {affordable ? `Buy ◆ ${item.price}` : `🔒 ◆ ${item.price}`}
                    </button>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
