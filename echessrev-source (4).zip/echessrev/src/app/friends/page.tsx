import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { auth } from "@/auth";
import { FriendsClient } from "./FriendsClient";

export const metadata: Metadata = { title: "Friends" };
export const dynamic = "force-dynamic";

export default async function FriendsPage() {
  const session = await auth();
  if (!session?.user?.id) redirect("/login?callbackUrl=/friends");
  return <FriendsClient me={session.user.username ?? "You"} />;
}
