"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import { notifyPointsChanged, useMe } from "@/lib/client/useMe";
import { UserAvatar, NameWithFlair } from "@/components/UserAvatar";
import { TIME_CONTROLS } from "@/lib/chess/bots";
import { RankBadge } from "@/components/RankBadge";

interface Entry {
  id: string;
  user: { id: string; username: string | null; points: number; rating: number; avatarIcon?: string | null; flair?: string | null };
}
interface Data {
  me: { points: number; rating: number };
  friends: Entry[];
  incoming: Entry[];
  outgoing: Entry[];
}
interface FGame {
  id: string;
  status: string;
  timeControl: string;
  rated: boolean;
  color: "w" | "b";
  opponent: { id: string; username: string | null; rating: number };
  yourTurn: boolean;
  result: string | null;
  termination: string | null;
  delta: number | null;
  plies: number;
}
interface Games {
  rating: number;
  incoming: FGame[];
  outgoing: FGame[];
  active: FGame[];
  finished: FGame[];
}

function Avatar({ name, size = 40, icon }: { name: string; size?: number; icon?: string | null }) {
  return <UserAvatar name={name} icon={icon} size={size} />;
}

const tcLabel = (id: string) => (id === "unlimited" ? "∞" : id);

export function FriendsClient({ me }: { me: string }) {
  const router = useRouter();
  const meInfo = useMe();
  const [data, setData] = useState<Data | null>(null);
  const [games, setGames] = useState<Games | null>(null);
  const [username, setUsername] = useState("");
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [tab, setTab] = useState<"points" | "rank">("rank");
  const [challengeFor, setChallengeFor] = useState<string | null>(null);
  const [ch, setCh] = useState({ timeControl: "10+0", color: "random" as "w" | "b" | "random", rated: true });

  const load = useCallback(async () => {
    const [a, b] = await Promise.all([fetch("/api/friends"), fetch("/api/friend-games")]);
    if (a.ok) setData(await a.json());
    if (b.ok) setGames(await b.json());
  }, []);
  useEffect(() => {
    load();
    const id = setInterval(load, 5000);
    return () => clearInterval(id);
  }, [load]);

  const add = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) return;
    setBusy(true);
    setMsg(null);
    const res = await fetch("/api/friends", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username: username.trim() }) });
    const j = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) return setMsg({ ok: false, text: j.error ?? "Something went wrong." });
    setMsg({ ok: true, text: j.status === "accepted" ? `You and ${username.trim()} are now friends!` : `Friend request sent to ${username.trim()}.` });
    setUsername("");
    load();
  };

  const act = async (id: string, method: "PATCH" | "DELETE") => {
    await fetch(`/api/friends/${id}`, { method, headers: { "Content-Type": "application/json" }, body: method === "PATCH" ? JSON.stringify({ action: "accept" }) : undefined });
    await load();
    notifyPointsChanged();
  };

  const gameAction = async (id: string, action: string) => {
    const res = await fetch(`/api/friend-games/${id}/action`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action }) });
    notifyPointsChanged();
    if (action === "accept" && res.ok) router.push(`/game/${id}`);
    else load();
  };

  const sendChallenge = async (name: string) => {
    setMsg(null);
    const res = await fetch("/api/friend-games", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username: name, ...ch }) });
    const j = await res.json().catch(() => ({}));
    if (!res.ok) return setMsg({ ok: false, text: j.error ?? "Could not send the challenge." });
    setChallengeFor(null);
    router.push(`/game/${j.id}`);
  };

  const board = data
    ? [
        ...data.friends.map((f) => ({ name: f.user.username ?? "?", points: f.user.points, rating: f.user.rating, id: f.id, isMe: false, icon: f.user.avatarIcon ?? null, flair: f.user.flair ?? null })),
        { name: me, points: data.me.points, rating: data.me.rating, id: "me", isMe: true, icon: meInfo?.avatarIcon ?? null, flair: meInfo?.flair ?? null },
      ].sort((a, b) => (tab === "points" ? b.points - a.points : b.rating - a.rating))
    : [];

  return (
    <div className="mx-auto grid max-w-5xl grid-cols-1 gap-5 lg:grid-cols-[1fr_340px]">
      <div className="space-y-5">
        <h1 className="text-3xl font-extrabold">Friends</h1>
        {msg && <p role="status" className={`rounded-lg px-3 py-2 text-sm font-bold animate-fade-in ${msg.ok ? "bg-accent-soft text-accent" : "bg-bad/15 text-bad"}`}>{msg.text}</p>}

        {games && (games.incoming.length > 0 || games.active.length > 0 || games.outgoing.length > 0) && (
          <section className="card space-y-2 animate-fade-up" aria-labelledby="games-h">
            <h2 id="games-h" className="mb-1 font-extrabold">Your games</h2>
            {games.incoming.map((g) => (
              <div key={g.id} className="flex flex-wrap items-center gap-3 rounded-lg bg-gold-soft p-3 animate-pop">
                <Avatar name={g.opponent.username ?? "?"} />
                <div className="min-w-0 flex-1">
                  <div className="font-extrabold">{g.opponent.username} challenged you!</div>
                  <div className="text-xs font-bold text-muted">{tcLabel(g.timeControl)} · you play {g.color === "w" ? "White" : "Black"} · {g.rated ? "Rated" : "Casual"}</div>
                </div>
                <button type="button" className="btn-primary" onClick={() => gameAction(g.id, "accept")}>Accept</button>
                <button type="button" className="btn" onClick={() => gameAction(g.id, "decline")}>Decline</button>
              </div>
            ))}
            {games.active.map((g) => (
              <Link key={g.id} href={`/game/${g.id}`} className={`flex items-center gap-3 rounded-lg p-3 transition hover:brightness-110 ${g.yourTurn ? "bg-accent-soft ring-2 ring-accent" : "bg-panel-2"}`}>
                <Avatar name={g.opponent.username ?? "?"} />
                <div className="min-w-0 flex-1">
                  <div className="font-extrabold">vs {g.opponent.username}</div>
                  <div className="text-xs font-bold text-muted">{tcLabel(g.timeControl)} · {g.color === "w" ? "White" : "Black"} · move {Math.floor(g.plies / 2) + 1}</div>
                </div>
                <span className={`rounded-md px-2 py-1 text-xs font-extrabold ${g.yourTurn ? "bg-accent text-white" : "text-muted"}`}>{g.yourTurn ? "Your move" : "Their move"}</span>
              </Link>
            ))}
            {games.outgoing.map((g) => (
              <div key={g.id} className="flex items-center gap-3 rounded-lg bg-panel-2 p-3">
                <Avatar name={g.opponent.username ?? "?"} size={32} />
                <span className="flex-1 text-sm font-bold">Waiting for {g.opponent.username} · {tcLabel(g.timeControl)}</span>
                <button type="button" className="btn py-1.5 text-xs" onClick={() => gameAction(g.id, "cancel")}>Cancel</button>
              </div>
            ))}
          </section>
        )}

        {data && data.incoming.length > 0 && (
          <section className="card animate-fade-up" aria-labelledby="incoming">
            <h2 id="incoming" className="mb-3 font-extrabold">Friend requests <span className="ml-1 rounded-full bg-bad px-2 py-0.5 text-xs text-white">{data.incoming.length}</span></h2>
            <ul className="space-y-2">
              {data.incoming.map((r) => (
                <li key={r.id} className="flex items-center gap-3 rounded-lg bg-panel-2 p-3 animate-pop">
                  <Avatar name={r.user.username ?? "?"} />
                  <Link href={`/u/${r.user.username}`} className="flex-1 font-bold hover:text-accent">{r.user.username}</Link>
                  <button type="button" className="btn-primary py-1.5" onClick={() => act(r.id, "PATCH")}>Accept</button>
                  <button type="button" className="btn py-1.5" onClick={() => act(r.id, "DELETE")}>Decline</button>
                </li>
              ))}
            </ul>
          </section>
        )}

        <section className="card" aria-labelledby="leaderboard">
          <div className="mb-3 flex items-center gap-2">
            <h2 id="leaderboard" className="font-extrabold">Leaderboard</h2>
            <div className="ml-auto flex rounded-lg bg-panel-2 p-1" role="tablist" aria-label="Sort leaderboard by">
              {(["rank", "points"] as const).map((t) => (
                <button key={t} type="button" role="tab" aria-selected={tab === t} onClick={() => setTab(t)} className={`rounded-md px-3 py-1 text-xs font-extrabold transition ${tab === t ? "bg-panel-3 text-fg" : "text-muted"}`}>
                  {t === "rank" ? "Rank" : "Points"}
                </button>
              ))}
            </div>
          </div>
          {!data ? (
            <div className="space-y-2">{[0, 1, 2].map((i) => <div key={i} className="skeleton h-14" />)}</div>
          ) : data.friends.length === 0 ? (
            <div className="py-8 text-center">
              <div className="text-4xl" aria-hidden>👋</div>
              <p className="mt-2 text-muted">No friends yet. Add someone by username, then challenge them to a rated game.</p>
            </div>
          ) : (
            <ol className="space-y-2">
              {board.map((row, i) => (
                <li key={row.id} className={`rounded-lg animate-fade-up ${row.isMe ? "bg-accent-soft ring-1 ring-accent/40" : "bg-panel-2"}`} style={{ animationDelay: `${i * 40}ms` }}>
                  <div className="flex items-center gap-3 p-3">
                    <span className={`w-7 text-center text-lg font-extrabold ${i === 0 ? "text-gold" : "text-muted"}`}>{i === 0 ? "👑" : i + 1}</span>
                    <Avatar name={row.name} icon={row.icon} />
                    <div className="min-w-0 flex-1">
                      {row.isMe ? (
                        <span className="font-extrabold"><NameWithFlair name={row.name} flair={row.flair} /> <span className="text-xs text-muted">(you)</span></span>
                      ) : (
                        <Link href={`/u/${row.name}`} className="font-extrabold hover:text-accent"><NameWithFlair name={row.name} flair={row.flair} /></Link>
                      )}
                      <div className="mt-0.5"><RankBadge rating={row.rating} /></div>
                    </div>
                    <span className="text-right font-mono text-sm font-bold tabular-nums">
                      {tab === "rank" ? <span>{row.rating}</span> : <span className="text-gold">◆ {row.points.toLocaleString()}</span>}
                    </span>
                    {!row.isMe && (
                      <button type="button" className="btn-primary px-3 py-1.5 text-xs" onClick={() => setChallengeFor(challengeFor === row.name ? null : row.name)} aria-expanded={challengeFor === row.name}>
                        ⚔ Challenge
                      </button>
                    )}
                  </div>
                  {challengeFor === row.name && (
                    <div className="space-y-3 border-t border-line p-3 animate-fade-in">
                      <div className="flex flex-wrap gap-1.5" role="radiogroup" aria-label="Time control">
                        {TIME_CONTROLS.map((t) => (
                          <button key={t.id} type="button" role="radio" aria-checked={ch.timeControl === t.id} onClick={() => setCh({ ...ch, timeControl: t.id })} className={`chip px-3 py-1.5 text-xs ${ch.timeControl === t.id ? "chip-on" : ""}`}>
                            {tcLabel(t.id)}
                          </button>
                        ))}
                      </div>
                      <div className="flex flex-wrap items-center gap-1.5" role="radiogroup" aria-label="Your color">
                        {(["w", "random", "b"] as const).map((c) => (
                          <button key={c} type="button" role="radio" aria-checked={ch.color === c} onClick={() => setCh({ ...ch, color: c })} className={`chip px-3 py-1.5 text-xs ${ch.color === c ? "chip-on" : ""}`}>
                            {c === "w" ? "♔ White" : c === "b" ? "♚ Black" : "⚄ Random"}
                          </button>
                        ))}
                        <label className="ml-auto flex items-center gap-2 text-xs font-bold">
                          <input type="checkbox" checked={ch.rated} onChange={(e) => setCh({ ...ch, rated: e.target.checked })} className="h-4 w-4 accent-[var(--accent)]" /> Rated
                        </label>
                      </div>
                      <div className="flex gap-2">
                        <button type="button" className="btn-primary flex-1 py-2.5" onClick={() => sendChallenge(row.name)}>Send challenge</button>
                        <button type="button" className="btn py-2.5" onClick={() => setChallengeFor(null)}>Cancel</button>
                        <button type="button" className="btn py-2.5 text-xs text-muted" onClick={() => act(row.id, "DELETE")}>Unfriend</button>
                      </div>
                    </div>
                  )}
                </li>
              ))}
            </ol>
          )}
        </section>
      </div>

      <aside className="space-y-5 lg:pt-14">
        <section className="card" aria-labelledby="rank-h">
          <h2 id="rank-h" className="label">Your rank</h2>
          {games ? <RankBadge rating={games.rating} size="lg" /> : <div className="skeleton h-16" />}
          <p className="mt-3 text-xs text-muted">Win rated games against friends to climb: Bronze → Silver → Gold → Platinum → Diamond → Champion.</p>
        </section>

        <form onSubmit={add} className="card space-y-3">
          <label htmlFor="friend-name" className="label">Add a friend</label>
          <input id="friend-name" value={username} onChange={(e) => setUsername(e.target.value)} className="input" placeholder="username" autoComplete="off" />
          <button type="submit" className="btn-primary w-full py-2.5" disabled={busy || !username.trim()}>{busy ? "Sending…" : "Send friend request"}</button>
          {data && data.outgoing.length > 0 && (
            <ul className="space-y-1 pt-1 text-sm">
              {data.outgoing.map((r) => (
                <li key={r.id} className="flex items-center gap-2 text-muted">
                  <span className="flex-1 truncate">Pending: {r.user.username}</span>
                  <button type="button" className="text-xs font-bold hover:text-fg" onClick={() => act(r.id, "DELETE")}>Cancel</button>
                </li>
              ))}
            </ul>
          )}
        </form>

        {games && games.finished.length > 0 && (
          <section className="card" aria-labelledby="recent-h">
            <h2 id="recent-h" className="label">Recent friend games</h2>
            <ul className="space-y-1.5">
              {games.finished.slice(0, 8).map((g) => {
                const won = (g.result === "1-0" && g.color === "w") || (g.result === "0-1" && g.color === "b");
                const draw = g.result === "1/2-1/2";
                return (
                  <li key={g.id}>
                    <Link href={`/game/${g.id}`} className="flex items-center gap-2 rounded-md px-2 py-1.5 text-sm hover:bg-panel-2">
                      <span className={`w-10 rounded px-1 text-center text-[11px] font-extrabold ${won ? "bg-ok/15 text-ok" : draw ? "bg-panel-3 text-muted" : "bg-bad/15 text-bad"}`}>{won ? "WIN" : draw ? "DRAW" : "LOSS"}</span>
                      <span className="flex-1 truncate font-bold">{g.opponent.username}</span>
                      {g.delta != null && <span className={`font-mono text-xs font-bold ${g.delta >= 0 ? "text-ok" : "text-bad"}`}>{g.delta >= 0 ? `+${g.delta}` : g.delta}</span>}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </section>
        )}
      </aside>
    </div>
  );
}
