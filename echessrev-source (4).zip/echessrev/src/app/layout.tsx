import type { Metadata, Viewport } from "next";
import "./globals.css";
import { AppShell } from "@/components/AppShell";
import { Providers } from "@/components/Providers";

export const metadata: Metadata = {
  title: { default: "EChessREV — play bots, review every move", template: "%s · EChessREV" },
  description: "Play chess against rated computer bots from 400 to 3200, then get a full move-by-move Game Review. Import any PGN or FEN for analysis.",
  icons: { icon: "/favicon.svg" },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: dark)", color: "#16171a" },
    { media: "(prefers-color-scheme: light)", color: "#e3e6e1" },
  ],
};

// Applies the saved theme before paint (dark is the default).
const themeScript = `try{var t=localStorage.getItem('theme');document.documentElement.classList.toggle('dark',t!=='light');var b=JSON.parse(localStorage.getItem('echessrev:board')||'null');if(b){document.documentElement.style.setProperty('--board-light',b[0]);document.documentElement.style.setProperty('--board-dark',b[1])}}catch(e){document.documentElement.classList.add('dark')}`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body className="min-h-screen font-sans antialiased">
        <Providers>
          <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:z-50 focus:rounded focus:bg-accent focus:px-3 focus:py-2 focus:text-accent-fg">
            Skip to content
          </a>
          <AppShell>{children}</AppShell>
        </Providers>
      </body>
    </html>
  );
}
