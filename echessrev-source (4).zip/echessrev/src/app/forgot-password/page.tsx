"use client";

import Link from "next/link";
import { useState } from "react";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [state, setState] = useState<"idle" | "busy" | "sent">("idle");
  const [error, setError] = useState("");
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setState("busy");
    const res = await fetch("/api/password/forgot", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email }) });
    const j = await res.json().catch(() => ({}));
    if (!res.ok) {
      setError(j.error ?? "Something went wrong.");
      setState("idle");
      return;
    }
    setState("sent");
  };
  return (
    <div className="mx-auto mt-6 max-w-sm animate-fade-up">
      <div className="card space-y-4">
        <h1 className="text-2xl font-extrabold">Reset your password</h1>
        {state === "sent" ? (
          <div className="space-y-3" role="status">
            <div className="text-4xl" aria-hidden>📬</div>
            <p>If an account uses <strong>{email}</strong>, we&apos;ve emailed it a link to choose a new password. It works for one hour.</p>
            <p className="text-sm text-muted">Don&apos;t see it? Check your spam folder.</p>
            <Link href="/login" className="btn w-full py-2.5">Back to log in</Link>
          </div>
        ) : (
          <form onSubmit={submit} className="space-y-3">
            <p className="text-sm text-muted">Enter the email you signed up with and we&apos;ll send you a reset link.</p>
            <div>
              <label htmlFor="email" className="label">Email</label>
              <input id="email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="input" />
            </div>
            {error && <p role="alert" className="text-sm text-bad">{error}</p>}
            <button type="submit" className="btn-primary w-full py-2.5" disabled={state === "busy" || !email}>{state === "busy" ? "Sending…" : "Send reset link"}</button>
            <p className="text-center text-sm text-muted"><Link href="/login" className="text-accent hover:underline">Back to log in</Link></p>
          </form>
        )}
      </div>
    </div>
  );
}
