/**
 * Re-mounts on every navigation, so each page fades in.
 * Opacity only: a transform animation on an ancestor would become the containing block for
 * position:fixed descendants and throw off the board's drag preview.
 */
export default function Template({ children }: { children: React.ReactNode }) {
  return <div className="animate-fade-in">{children}</div>;
}
