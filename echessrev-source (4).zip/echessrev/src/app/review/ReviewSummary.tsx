"use client";

import type { GameReview } from "@/lib/review/buildReview";
import { CLASSIFICATION_META } from "@/lib/chess/classify";
import type { Classification } from "@/lib/chess/types";
import { ClassificationIcon } from "@/components/ClassificationIcon";

const ROWS: Classification[] = ["brilliant", "great", "best", "excellent", "good", "book", "inaccuracy", "mistake", "miss", "blunder", "forced"];

export function ReviewSummary({ review }: { review: GameReview }) {
  const white = review.headers.White && review.headers.White !== "?" ? review.headers.White : "White";
  const black = review.headers.Black && review.headers.Black !== "?" ? review.headers.Black : "Black";
  return (
    <section className="card space-y-3" aria-labelledby="summary-heading">
      <h2 id="summary-heading" className="sr-only">Review summary</h2>
      <div className="flex items-center justify-between gap-2 text-sm">
        <div className="min-w-0">
          {review.opening ? (
            <span>
              <span className="rounded bg-panel-2 px-1.5 py-0.5 font-mono text-xs">{review.opening.eco}</span>{" "}
              <span className="font-medium">{review.opening.name}</span>
            </span>
          ) : (
            <span className="text-muted">{review.bookSkipped ? "Custom start / short game — no opening book" : "Opening not in database"}</span>
          )}
        </div>
        <span className="shrink-0 font-mono font-bold">{review.result}</span>
      </div>
      <div className="grid grid-cols-[1fr_auto_auto] items-center gap-x-4 gap-y-1">
        <span />
        <span className="max-w-24 truncate text-center text-xs font-semibold" title={white}>{white}</span>
        <span className="max-w-24 truncate text-center text-xs font-semibold" title={black}>{black}</span>
        <span className="text-sm text-muted">Accuracy</span>
        <span className="rounded-lg bg-[#f1f1ee] px-3 py-1 text-center text-lg font-bold text-[#1d1f24]">{review.accuracy.w.toFixed(1)}</span>
        <span className="rounded-lg bg-[#2b2f36] px-3 py-1 text-center text-lg font-bold text-[#f1f1ee]">{review.accuracy.b.toFixed(1)}</span>
        <span className="text-sm text-muted" title="Estimated from accuracy using the table in src/lib/chess/accuracy.ts">Est. performance</span>
        <span className="text-center font-mono font-semibold">{review.rating.w}</span>
        <span className="text-center font-mono font-semibold">{review.rating.b}</span>
      </div>
      <table className="w-full text-sm">
        <caption className="sr-only">Move classifications per side</caption>
        <thead>
          <tr className="text-xs text-muted">
            <th scope="col" className="text-left font-medium">Classification</th>
            <th scope="col" className="w-12 text-center font-medium">W</th>
            <th scope="col" className="w-12 text-center font-medium">B</th>
          </tr>
        </thead>
        <tbody>
          {ROWS.map((c) => (
            <tr key={c} className="border-t border-line/60">
              <th scope="row" className="py-1 text-left font-normal">
                <span className="flex items-center gap-2">
                  <ClassificationIcon c={c} size={16} />
                  <span style={{ color: CLASSIFICATION_META[c].color }}>{CLASSIFICATION_META[c].label}</span>
                </span>
              </th>
              <td className="text-center font-mono">{review.counts.w[c]}</td>
              <td className="text-center font-mono">{review.counts.b[c]}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="text-xs text-muted">Engine depth {review.depth}. Stockfish 17.1 (WASM, in your browser).</p>
    </section>
  );
}
