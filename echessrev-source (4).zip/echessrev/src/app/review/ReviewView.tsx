"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { Chess } from "chess.js";
import { Board, type BoardArrow } from "@/components/Board";
import { EvalBar } from "@/components/EvalBar";
import { EvalGraph } from "@/components/EvalGraph";
import { MoveList } from "@/components/MoveList";
import { ClassificationIcon } from "@/components/ClassificationIcon";
import { ExportBar } from "@/components/ExportBar";
import { ReviewSummary } from "./ReviewSummary";
import type { GameReview } from "@/lib/review/buildReview";
import { CLASSIFICATION_META, NEEDS_RETRY, positionWinPct } from "@/lib/chess/classify";
import { pvToSan } from "@/lib/chess/coach";
import { formatScore, scoreToWhiteCp, scoreToWinPct } from "@/lib/chess/winpct";
import type { EngineLine } from "@/lib/chess/types";
import type { StockfishEngine } from "@/lib/engine/engine";
import { playSound, soundForSan } from "@/lib/client/sounds";

interface VarMove {
  san: string;
  from: string;
  to: string;
  fen: string;
}
interface Variation {
  baseFen: string;
  /** Game ply the variation branches from. */
  basePly: number;
  moves: VarMove[];
  idx: number;
  label: string;
}

const BEST_ARROW = "rgba(70, 180, 80, 0.85)";

function isTypingTarget(t: EventTarget | null) {
  const el = t as HTMLElement | null;
  return !!el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.tagName === "SELECT" || el.isContentEditable);
}

export function ReviewView({ review, pgn, engine }: { review: GameReview; pgn: string; engine: StockfishEngine | null }) {
  const n = review.moves.length;
  const [ply, setPly] = useState(0);
  const [orientation, setOrientation] = useState<"white" | "black">(() => {
    const black = (review.headers.Black ?? "").toLowerCase();
    return black.includes("(bot") ? "white" : (review.headers.White ?? "").includes("(bot") ? "black" : "white";
  });
  const [variation, setVariation] = useState<Variation | null>(null);
  const [retry, setRetry] = useState<{ ply: number; feedback: "correct" | "wrong" | null; tried: string | null; solution: boolean } | null>(null);
  const [liveLines, setLiveLines] = useState<EngineLine[]>([]);
  const liveAbort = useRef<AbortController | null>(null);

  const move = ply > 0 ? review.moves[ply - 1] : null;

  const goto = useCallback(
    (p: number) => {
      setVariation(null);
      setRetry(null);
      const target = Math.max(0, Math.min(n, p));
      if (target === ply + 1 && review.moves[target - 1]) playSound(soundForSan(review.moves[target - 1].san));
      setPly(target);
    },
    [n, ply, review.moves],
  );

  // Keyboard navigation: ←/→ step, Home/End jump (also inside a variation).
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (isTypingTarget(e.target) || e.altKey || e.ctrlKey || e.metaKey) return;
      if (variation) {
        if (e.key === "ArrowLeft") setVariation((v) => (v ? { ...v, idx: Math.max(0, v.idx - 1) } : v));
        else if (e.key === "ArrowRight") setVariation((v) => (v ? { ...v, idx: Math.min(v.moves.length, v.idx + 1) } : v));
        else if (e.key === "Home") setVariation((v) => (v ? { ...v, idx: 0 } : v));
        else if (e.key === "End") setVariation((v) => (v ? { ...v, idx: v.moves.length } : v));
        else if (e.key === "Escape") setVariation(null);
        else return;
      } else {
        if (e.key === "ArrowLeft") goto(ply - 1);
        else if (e.key === "ArrowRight") goto(ply + 1);
        else if (e.key === "Home") goto(0);
        else if (e.key === "End") goto(n);
        else return;
      }
      e.preventDefault();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [goto, ply, n, variation]);

  const boardFen = retry
    ? review.moves[retry.ply - 1].fenBefore
    : variation
      ? variation.idx === 0
        ? variation.baseFen
        : variation.moves[variation.idx - 1].fen
      : ply === 0
        ? review.startFen
        : review.moves[ply - 1].fenAfter;

  // Live engine for variation positions.
  useEffect(() => {
    liveAbort.current?.abort();
    setLiveLines([]);
    if (!variation || !engine) return;
    const c = new Chess(boardFen);
    if (c.isGameOver()) return;
    const ac = new AbortController();
    liveAbort.current = ac;
    engine
      .search(boardFen, { depth: 16, multipv: 1, signal: ac.signal, configure: (e) => e.setFullStrength(), onInfo: (l) => !ac.signal.aborted && setLiveLines(l) })
      .catch(() => undefined);
    return () => ac.abort();
  }, [variation, boardFen, engine]);

  const stm = new Chess(boardFen).turn();

  // Eval for the bar.
  const evalInfo = useMemo(() => {
    if (variation || retry) {
      const c = new Chess(boardFen);
      if (c.isCheckmate()) return { cp: c.turn() === "w" ? -10000 : 10000, label: c.turn() === "w" ? "0-1" : "1-0" };
      if (c.isDraw()) return { cp: 0, label: "½" };
      const top = retry ? review.positions[retry.ply - 1].lines[0] : liveLines[0];
      if (!top) return { cp: 0, label: "…" };
      return { cp: scoreToWhiteCp(top.score, stm), label: formatScore(top.score, stm) };
    }
    const p = review.positions[ply];
    const label =
      p.terminal === "checkmate" ? (stm === "w" ? "0-1" : "1-0") : p.terminal ? "½" : p.lines[0] ? formatScore(p.lines[0].score, stm) : "0.00";
    return { cp: review.evalWhiteCp[ply], label };
  }, [variation, retry, boardFen, liveLines, review, ply, stm]);

  const arrows: BoardArrow[] = [];
  if (retry) {
    const m = review.moves[retry.ply - 1];
    if (retry.solution && m.bestUci) arrows.push({ from: m.bestUci.slice(0, 2), to: m.bestUci.slice(2, 4), color: BEST_ARROW });
  } else if (variation) {
    const best = liveLines[0]?.pv[0];
    if (best) arrows.push({ from: best.slice(0, 2), to: best.slice(2, 4), color: BEST_ARROW });
  } else if (move) {
    if (move.bestUci && move.bestUci !== move.uci && move.classification !== "book" && move.classification !== "forced") {
      arrows.push({ from: move.bestUci.slice(0, 2), to: move.bestUci.slice(2, 4), color: BEST_ARROW });
    }
    arrows.push({ from: move.from, to: move.to, color: CLASSIFICATION_META[move.classification].color + "cc" });
  }

  const lastMove = retry
    ? null
    : variation
      ? variation.idx > 0
        ? variation.moves[variation.idx - 1]
        : variation.basePly > 0
          ? review.moves[variation.basePly - 1]
          : null
      : move;

  const onBoardMove = (from: string, to: string, promotion?: string): boolean => {
    const c = new Chess(boardFen);
    let m;
    try {
      m = c.move({ from, to, promotion });
    } catch {
      return false;
    }
    playSound(soundForSan(m.san, m.captured));
    const uci = `${m.from}${m.to}${m.promotion ?? ""}`;
    if (retry) {
      const rm = review.moves[retry.ply - 1];
      const before = review.positions[retry.ply - 1];
      const bestWin = positionWinPct(before);
      const alt = before.lines.find((l) => l.pv[0] === uci);
      const correct = uci === rm.bestUci || (!!alt && (bestWin - scoreToWinPct(alt.score)) / 100 <= 0.02);
      setRetry({ ...retry, feedback: correct ? "correct" : "wrong", tried: m.san });
      return false; // keep the board on the puzzle position
    }
    if (!variation) {
      const next = review.moves[ply];
      if (next && next.uci === uci) {
        setPly(ply + 1);
        return true;
      }
      setVariation({ baseFen: boardFen, basePly: ply, moves: [{ san: m.san, from: m.from, to: m.to, fen: c.fen() }], idx: 1, label: "Your variation" });
      return true;
    }
    const kept = variation.moves.slice(0, variation.idx);
    setVariation({ ...variation, moves: [...kept, { san: m.san, from: m.from, to: m.to, fen: c.fen() }], idx: kept.length + 1, label: "Your variation" });
    return true;
  };

  const showLine = (fromFen: string, pv: string[], basePly: number, label: string) => {
    const c = new Chess(fromFen);
    const moves: VarMove[] = [];
    for (const u of pv) {
      try {
        const m = c.move({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] });
        moves.push({ san: m.san, from: m.from, to: m.to, fen: c.fen() });
      } catch {
        break;
      }
    }
    if (moves.length === 0) return;
    setRetry(null);
    setVariation({ baseFen: fromFen, basePly, moves, idx: 1, label });
  };

  const nextRetryable = (fromPly: number, dir: 1 | -1) => {
    for (let p = fromPly + dir; p >= 1 && p <= n; p += dir) if (NEEDS_RETRY.includes(review.moves[p - 1].classification)) return p;
    return null;
  };

  const labels = review.moves.map((m) => {
    const no = Number(m.fenBefore.split(" ")[5]);
    return `${no}${m.color === "w" ? "." : "..."} ${m.san}`;
  });

  const retryMove = retry ? review.moves[retry.ply - 1] : null;
  const fenParts = boardFen.split(" ");

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-[minmax(0,1fr)_380px]">
      <div className="mx-auto w-full max-w-[min(100%,calc(100vh-9rem))] space-y-3">
        <Board
          fen={boardFen}
          orientation={orientation}
          movable={retry ? (retry.feedback === "correct" ? null : (stm as "w" | "b")) : "both"}
          onMove={onBoardMove}
          lastMove={lastMove ? { from: lastMove.from, to: lastMove.to } : null}
          arrows={arrows}
          badge={!variation && !retry && move ? { square: move.to, classification: move.classification } : null}
          side={<EvalBar whiteCp={evalInfo.cp} label={evalInfo.label} orientation={orientation} />}
          id="review-board"
        />
        <div className="flex flex-wrap items-center gap-2" role="toolbar" aria-label="Move navigation">
          <button type="button" className="btn" onClick={() => goto(0)} aria-label="First move (Home)">⏮</button>
          <button type="button" className="btn" onClick={() => (variation ? setVariation({ ...variation, idx: Math.max(0, variation.idx - 1) }) : goto(ply - 1))} aria-label="Previous move (Left arrow)">◀</button>
          <button type="button" className="btn" onClick={() => (variation ? setVariation({ ...variation, idx: Math.min(variation.moves.length, variation.idx + 1) }) : goto(ply + 1))} aria-label="Next move (Right arrow)">▶</button>
          <button type="button" className="btn" onClick={() => goto(n)} aria-label="Last move (End)">⏭</button>
          <button type="button" className="btn" onClick={() => setOrientation((o) => (o === "white" ? "black" : "white"))} aria-label="Flip board">⇅</button>
          <span className="ml-auto text-xs text-muted">Use ← → Home End to navigate</span>
        </div>
        <EvalGraph whiteWinPcts={review.whiteWinPcts} classifications={review.moves.map((m) => m.classification)} labels={labels} current={ply} onSelect={goto} />
        <ExportBar pgn={pgn} fen={boardFen} />
      </div>

      <aside className="space-y-3">
        {/* Coach panel */}
        <section className="card space-y-3" aria-live="polite" aria-labelledby="coach-heading">
          <h2 id="coach-heading" className="label">Coach</h2>
          {retry && retryMove ? (
            <div className="space-y-2">
              <p className="text-sm">
                <strong>Retry:</strong> find a better move than <span className="font-mono">{retryMove.san}</span> for {retryMove.color === "w" ? "White" : "Black"}.
              </p>
              {retry.feedback === "correct" && <p className="rounded-lg bg-ok/15 px-3 py-2 text-sm text-ok" role="status">✓ Correct! {retry.tried} is the best move.</p>}
              {retry.feedback === "wrong" && <p className="rounded-lg bg-bad/15 px-3 py-2 text-sm text-bad" role="status">✕ {retry.tried} isn&apos;t it. Try again.</p>}
              {retry.solution && (
                <p className="text-sm">
                  Solution: <strong className="font-mono">{retryMove.bestSan}</strong>
                  {retryMove.bestLineSan.length > 1 && <span className="text-muted"> — {retryMove.bestLineSan.slice(0, 6).join(" ")}</span>}
                </p>
              )}
              <div className="flex flex-wrap gap-2">
                {!retry.solution && <button type="button" className="btn" onClick={() => setRetry({ ...retry, solution: true })}>Show solution</button>}
                {(() => {
                  const next = nextRetryable(retry.ply, 1);
                  return next ? <button type="button" className="btn" onClick={() => { setPly(next); setRetry({ ply: next, feedback: null, tried: null, solution: false }); }}>Next mistake ▶</button> : null;
                })()}
                <button type="button" className="btn" onClick={() => { setPly(retry.ply); setRetry(null); }}>Back to review</button>
              </div>
            </div>
          ) : variation ? (
            <div className="space-y-2">
              <p className="text-sm">
                <strong>{variation.label}</strong> from {variation.basePly === 0 ? "the start" : labels[variation.basePly - 1]}
              </p>
              <p className="font-mono text-sm">
                {variation.moves.map((m, i) => (
                  <button key={i} type="button" onClick={() => setVariation({ ...variation, idx: i + 1 })} className={`mr-1 rounded px-1 ${variation.idx === i + 1 ? "bg-accent text-accent-fg" : "hover:bg-panel-2"}`}>
                    {m.san}
                  </button>
                ))}
              </p>
              <p className="text-xs text-muted">
                Engine: {liveLines[0] ? `${formatScore(liveLines[0].score, stm)} · depth ${liveLines[0].depth} · ${pvToSan(boardFen, liveLines[0].pv, 6).join(" ")}` : engine ? "thinking…" : "unavailable"}
              </p>
              <p className="text-xs text-muted">Make moves on the board to explore. The main game is unchanged.</p>
              <button type="button" className="btn" onClick={() => setVariation(null)}>Back to game (Esc)</button>
            </div>
          ) : move ? (
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <ClassificationIcon c={move.classification} size={26} />
                <div>
                  <div className="font-semibold" style={{ color: CLASSIFICATION_META[move.classification].color }}>
                    {labels[ply - 1]} — {CLASSIFICATION_META[move.classification].label}
                  </div>
                  <div className="text-xs text-muted">Move accuracy {move.accuracy.toFixed(0)}% · expected points lost {move.epl.toFixed(2)}</div>
                </div>
              </div>
              <p className="text-sm leading-relaxed">{move.coach}</p>
              {move.bestLineSan.length > 0 && move.bestUci !== move.uci && (
                <p className="text-xs text-muted">Best line: <span className="font-mono">{move.bestLineSan.slice(0, 8).join(" ")}</span></p>
              )}
              <div className="flex flex-wrap gap-2">
                {NEEDS_RETRY.includes(move.classification) && (
                  <button type="button" className="btn-primary" onClick={() => setRetry({ ply, feedback: null, tried: null, solution: false })}>↻ Retry</button>
                )}
                {review.positions[ply - 1].lines[0] && (
                  <button type="button" className="btn" onClick={() => showLine(move.fenBefore, review.positions[ply - 1].lines[0].pv, ply - 1, "Best line")}>Show best line</button>
                )}
                {review.positions[ply]?.lines[0] && (
                  <button type="button" className="btn" onClick={() => showLine(move.fenAfter, review.positions[ply].lines[0].pv, ply, "Engine line after this move")}>Engine line from here</button>
                )}
              </div>
            </div>
          ) : (
            <div className="space-y-2 text-sm">
              <p>Start position. Press → or click a move to step through the review.</p>
              {(() => {
                const first = nextRetryable(0, 1);
                return first ? (
                  <button type="button" className="btn" onClick={() => goto(first)}>Jump to first mistake</button>
                ) : (
                  <p className="text-muted">No inaccuracies, mistakes or blunders in this game.</p>
                );
              })()}
            </div>
          )}
        </section>

        <div className="card p-2">
          <MoveList
            moves={review.moves.map((m) => ({ san: m.san, classification: m.classification }))}
            current={variation || retry ? -1 : ply}
            onSelect={goto}
            startFen={review.startFen}
            className="max-h-72"
          />
        </div>

        <ReviewSummary review={review} />

        <div className="flex flex-wrap gap-2 text-sm">
          <Link className="btn" href={`/analysis?fen=${encodeURIComponent(boardFen)}`}>Open position in analysis board</Link>
          <Link className="btn" href={`/play/computer?fen=${encodeURIComponent(boardFen)}`}>Play from here vs a bot</Link>
        </div>
        <p className="sr-only" aria-live="polite">{fenParts[1] === "w" ? "White" : "Black"} to move.</p>
      </aside>
    </div>
  );
}
