import type { Metadata } from "next";
import { Suspense } from "react";
import { ReviewClient } from "./ReviewClient";

export const metadata: Metadata = { title: "Game Review" };

export default function ReviewPage() {
  return (
    <Suspense fallback={<p className="text-muted">Loading…</p>}>
      <ReviewClient />
    </Suspense>
  );
}
