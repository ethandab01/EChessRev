"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useSession } from "next-auth/react";
import { ImportPanel } from "@/components/ImportPanel";
import { EngineError } from "@/components/EngineError";
import { GuestBanner } from "@/components/GuestBanner";
import { gameTitle, parsePgn, type ParsedGame } from "@/lib/chess/pgn";
import { useEngine } from "@/lib/client/useEngine";
import { getHandoff } from "@/lib/client/handoff";
import { runReview, getCachedReview, storeCachedReview } from "@/lib/review/runReview";
import { REVIEW_VERSION, type GameReview } from "@/lib/review/buildReview";
import { SearchAbortedError } from "@/lib/engine/engine";
import { ReviewView } from "./ReviewView";
import { notifyPointsChanged } from "@/lib/client/useMe";
import { CLASSIFICATION_META } from "@/lib/chess/classify";
import type { Classification } from "@/lib/chess/types";

interface Source {
  pgn: string;
  game: ParsedGame;
  gameId?: string;
  analysisId?: string;
  title: string;
}

export function ReviewClient() {
  const params = useSearchParams();
  const { status: authStatus } = useSession();
  const { engine, status: engineStatus, error: engineError, retry } = useEngine();
  const [source, setSource] = useState<Source | null>(null);
  const [review, setReview] = useState<GameReview | null>(null);
  const [depth, setDepth] = useState(18);
  const [progress, setProgress] = useState<{ done: number; total: number } | null>(null);
  const [error, setError] = useState("");
  const [loadingSource, setLoadingSource] = useState(false);
  const [saveState, setSaveState] = useState<"idle" | "saving" | "saved" | "error">("idle");
  const abortRef = useRef<AbortController | null>(null);
  const [autoCache, setAutoCache] = useState(true);
  const [bonus, setBonus] = useState<{ total: number; lines: Array<{ c: Classification; n: number; pts: number }> } | null>(null);

  // Load from ?game=, ?analysis= or ?source=handoff.
  useEffect(() => {
    const gameId = params.get("game");
    const analysisId = params.get("analysis");
    const fromHandoff = params.get("source") === "handoff";
    if (!gameId && !analysisId && !fromHandoff) return;
    setLoadingSource(true);
    (async () => {
      try {
        if (gameId) {
          const res = await fetch(`/api/games/${gameId}`);
          const j = await res.json();
          if (!res.ok) throw new Error(j.error ?? "Could not load the game.");
          const game = parsePgn(j.game.pgn);
          setSource({ pgn: j.game.pgn, game, gameId, title: `vs ${j.game.botName} (${j.game.botElo})` });
          if (j.game.review?.version === REVIEW_VERSION) {
            setReview(j.game.review);
            setDepth(j.game.review.depth);
            await storeCachedReview(game, j.game.review);
          }
        } else if (analysisId) {
          const res = await fetch(`/api/analyses/${analysisId}`);
          const j = await res.json();
          if (!res.ok) throw new Error(j.error ?? "Could not load the analysis.");
          const game = parsePgn(j.analysis.pgn);
          setSource({ pgn: j.analysis.pgn, game, analysisId, title: j.analysis.title });
          if (j.analysis.review?.version === REVIEW_VERSION) {
            setReview(j.analysis.review);
            setDepth(j.analysis.review.depth);
          }
          setSaveState("saved");
        } else {
          const h = getHandoff();
          if (!h) throw new Error("Nothing to review — paste a PGN below.");
          const game = parsePgn(h.pgn);
          setSource({ pgn: h.pgn, game, gameId: h.gameId, title: h.title ?? gameTitle(game.headers) });
        }
      } catch (e) {
        setError((e as Error).message);
      } finally {
        setLoadingSource(false);
      }
    })();
  }, [params]);

  // Instantly show a cached review for the chosen depth if we have one.
  useEffect(() => {
    if (!source || review || !autoCache) return;
    getCachedReview(source.game, depth).then((r) => {
      if (r) setReview(r);
    });
  }, [source, depth, review, autoCache]);

  const start = useCallback(async () => {
    if (!engine || !source) return;
    setError("");
    const ac = new AbortController();
    abortRef.current = ac;
    setProgress({ done: 0, total: source.game.moves.length + 1 });
    try {
      const r = await runReview(engine, source.game, { depth, signal: ac.signal, onProgress: (done, total) => setProgress({ done, total }) });
      setReview(r);
      if (source.gameId && authStatus === "authenticated") {
        fetch(`/api/games/${source.gameId}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ review: r, depth }),
        })
          .then((res) => res.json())
          .then((j) => {
            if (j?.bonus) {
              setBonus(j.bonus);
              notifyPointsChanged();
            }
          })
          .catch(() => undefined);
      }
    } catch (e) {
      if (!(e instanceof SearchAbortedError)) setError(`Analysis failed: ${(e as Error).message}`);
    } finally {
      setProgress(null);
      abortRef.current = null;
    }
  }, [engine, source, depth, authStatus]);

  const cancel = () => abortRef.current?.abort();

  const saveAnalysis = async () => {
    if (!source || !review) return;
    setSaveState("saving");
    try {
      const res = await fetch("/api/analyses", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: source.title.slice(0, 200) || "Imported game", pgn: source.pgn, review, depth: review.depth }),
      });
      if (!res.ok) throw new Error();
      setSaveState("saved");
    } catch {
      setSaveState("error");
    }
  };

  const reset = () => {
    cancel();
    setSource(null);
    setReview(null);
    setError("");
    setSaveState("idle");
    setAutoCache(true);
    window.history.replaceState(null, "", "/review");
  };

  if (review && source) {
    return (
      <div className="space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          <h1 className="mr-auto text-xl font-bold">Game Review <span className="text-base font-normal text-muted">— {source.title}</span></h1>
          {!source.gameId && authStatus === "authenticated" && (
            <button type="button" className="btn" onClick={saveAnalysis} disabled={saveState === "saving" || saveState === "saved"}>
              {saveState === "saved" ? "Saved ✓" : saveState === "saving" ? "Saving…" : saveState === "error" ? "Retry save" : "Save analysis"}
            </button>
          )}
          <button type="button" className="btn" onClick={() => { setAutoCache(false); setReview(null); }}>Change depth…</button>
          <button type="button" className="btn" onClick={reset}>Review another game</button>
        </div>
        {engineStatus === "error" && <EngineError message={engineError} onRetry={retry} />}
        {bonus && (
          <div role="status" className="card flex flex-wrap items-center gap-3 border-accent/50 py-3 animate-pop">
            <span className="text-2xl font-extrabold text-accent">+{bonus.total} ◆</span>
            <span className="text-sm text-muted">
              Review bonus{bonus.lines.length ? ": " + bonus.lines.map((l) => `${l.n} ${CLASSIFICATION_META[l.c].label} (+${l.pts})`).join(", ") : " — no Brilliant, Great or Best moves this time"}
            </span>
            <button type="button" className="ml-auto text-sm text-muted hover:text-fg" onClick={() => setBonus(null)} aria-label="Dismiss">✕</button>
          </div>
        )}
        <ReviewView review={review} pgn={source.pgn} engine={engine} />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <GuestBanner what="reviews" />
      <h1 className="text-2xl font-bold">Game Review</h1>
      <p className="text-muted">
        Every move is analysed by Stockfish in your browser and classified from Brilliant to Blunder, with accuracy, an estimated
        performance rating and a coach explanation for each move.
      </p>
      {engineStatus === "error" && <EngineError message={engineError} onRetry={retry} />}
      {error && <p role="alert" className="rounded-lg border border-bad/50 bg-bad/10 px-3 py-2 text-sm text-bad">{error}</p>}
      {loadingSource && <p className="text-muted" role="status">Loading game…</p>}
      {!source && !loadingSource && (
        <>
          <ImportPanel
            tabs={["pgn", "file", "lichess"]}
            onGame={(game, raw) => setSource({ pgn: raw, game, title: gameTitle(game.headers) })}
          />
          {authStatus === "authenticated" && (
            <p className="text-sm text-muted">
              Or open one of your games from your <Link href="/profile" className="text-accent underline">profile</Link>.
            </p>
          )}
        </>
      )}
      {source && (
        <div className="card space-y-4">
          <div>
            <div className="font-semibold">{source.title}</div>
            <div className="text-sm text-muted">
              {source.game.moves.length} plies{source.game.customStart ? " · custom starting position (book detection skipped)" : ""}
            </div>
          </div>
          <div>
            <label htmlFor="depth" className="label">Engine depth: {depth}</label>
            <input id="depth" type="range" min={12} max={24} value={depth} onChange={(e) => setDepth(Number(e.target.value))} className="w-full accent-[var(--accent)]" disabled={!!progress} />
            <div className="flex justify-between text-xs text-muted"><span>12 · fast</span><span>24 · thorough</span></div>
          </div>
          {progress ? (
            <div className="space-y-2">
              <div
                className="h-3 w-full overflow-hidden rounded-full bg-panel-2"
                role="progressbar"
                aria-label="Analysis progress"
                aria-valuemin={0}
                aria-valuemax={progress.total}
                aria-valuenow={progress.done}
              >
                <div className="h-full bg-accent transition-all" style={{ width: `${(progress.done / progress.total) * 100}%` }} />
              </div>
              <div className="flex items-center justify-between text-sm">
                <span>Analysing position {progress.done} / {progress.total}</span>
                <button type="button" className="btn py-1" onClick={cancel}>Cancel</button>
              </div>
            </div>
          ) : (
            <div className="flex flex-wrap gap-2">
              <button type="button" className="btn-primary" onClick={start} disabled={engineStatus !== "ready" || source.game.moves.length === 0}>
                {engineStatus === "loading" ? "Loading engine…" : "Start review"}
              </button>
              <button type="button" className="btn" onClick={reset}>Choose a different game</button>
            </div>
          )}
          {source.game.moves.length === 0 && <p className="text-sm text-bad">This game has no moves to review.</p>}
        </div>
      )}
    </div>
  );
}
