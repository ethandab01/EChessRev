import { notFound, redirect } from "next/navigation";
import { auth } from "@/auth";
import { prisma } from "@/lib/server/db";
import { ProfileView } from "@/components/ProfileView";
import { AddFriendButton } from "@/components/AddFriendButton";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ username: string }> }) {
  const { username } = await params;
  return { title: decodeURIComponent(username) };
}

export default async function PublicProfile({ params }: { params: Promise<{ username: string }> }) {
  const { username } = await params;
  const user = await prisma.user.findUnique({ where: { username: decodeURIComponent(username) } });
  if (!user) notFound();
  const session = await auth();
  if (session?.user?.id === user.id) redirect("/profile");
  let relation: "none" | "friends" | "sent" | "received" | "guest" = "guest";
  if (session?.user?.id) {
    const f = await prisma.friendship.findFirst({
      where: { OR: [{ requesterId: session.user.id, addresseeId: user.id }, { requesterId: user.id, addresseeId: session.user.id }] },
    });
    relation = !f ? "none" : f.status === "accepted" ? "friends" : f.requesterId === session.user.id ? "sent" : "received";
  }
  return <ProfileView userId={user.id} own={false} action={relation === "guest" ? null : <AddFriendButton username={user.username!} initial={relation} />} />;
}
