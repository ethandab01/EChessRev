import type { Metadata } from "next";
import { Suspense } from "react";
import { AnalysisClient } from "./AnalysisClient";

export const metadata: Metadata = { title: "Analysis board & import" };

export default function AnalysisPage() {
  return (
    <Suspense fallback={<p className="text-muted">Loading…</p>}>
      <AnalysisClient />
    </Suspense>
  );
}
