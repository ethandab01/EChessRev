"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Chess, type Move } from "chess.js";
import { Board } from "@/components/Board";
import { EvalBar } from "@/components/EvalBar";
import { MoveList } from "@/components/MoveList";
import { ImportPanel } from "@/components/ImportPanel";
import { ExportBar } from "@/components/ExportBar";
import { EngineError } from "@/components/EngineError";
import { ELO_MAX, ELO_MIN, ELO_STEP, botForElo } from "@/lib/chess/bots";
import { buildPgn, gameTitle, parseFen, parsePgn, START_FEN } from "@/lib/chess/pgn";
import { lookupOpening, type Opening } from "@/lib/chess/openings";
import { pvToSan } from "@/lib/chess/coach";
import { formatScore, scoreToWhiteCp } from "@/lib/chess/winpct";
import type { EngineLine } from "@/lib/chess/types";
import { useEngine } from "@/lib/client/useEngine";
import { getHandoff, setHandoff } from "@/lib/client/handoff";
import { playSound, soundForSan } from "@/lib/client/sounds";

const MAX_DEPTH = 22;

export function AnalysisClient() {
  const params = useSearchParams();
  const router = useRouter();
  const [engineOn, setEngineOn] = useState(true);
  const { engine, status, error: engineError, retry } = useEngine(engineOn);
  const [startFen, setStartFen] = useState(START_FEN);
  const [moves, setMoves] = useState<Move[]>([]);
  const [headers, setHeaders] = useState<Record<string, string>>({});
  const [ply, setPly] = useState(0);
  const [orientation, setOrientation] = useState<"white" | "black">("white");
  const [lines, setLines] = useState<EngineLine[]>([]);
  const [loadError, setLoadError] = useState("");
  const [elo, setElo] = useState(1200);
  const abortRef = useRef<AbortController | null>(null);

  const load = useCallback((fen: string, mv: Move[], hdrs: Record<string, string> = {}, goToEnd = true) => {
    setStartFen(fen);
    setMoves(mv);
    setHeaders(hdrs);
    setPly(goToEnd ? mv.length : 0);
    setOrientation(fen.split(" ")[1] === "b" && mv.length === 0 ? "black" : "white");
  }, []);

  useEffect(() => {
    const fen = params.get("fen");
    if (fen) {
      try {
        load(parseFen(fen), []);
      } catch (e) {
        setLoadError((e as Error).message);
      }
    } else if (params.get("source") === "handoff") {
      const h = getHandoff();
      if (h) {
        try {
          const g = parsePgn(h.pgn);
          load(g.startFen, g.moves, g.headers, false);
        } catch (e) {
          setLoadError((e as Error).message);
        }
      }
    }
  }, [params, load]);

  const fens = useMemo(() => {
    const c = new Chess(startFen);
    return [startFen, ...moves.map((m) => (c.move({ from: m.from, to: m.to, promotion: m.promotion }), c.fen()))];
  }, [startFen, moves]);
  const fen = fens[ply];
  const chess = useMemo(() => new Chess(fen), [fen]);
  const stm = chess.turn();

  // Live engine: top 3 lines, deepening up to MAX_DEPTH.
  useEffect(() => {
    abortRef.current?.abort();
    setLines([]);
    if (!engine || !engineOn || chess.isGameOver()) return;
    const ac = new AbortController();
    abortRef.current = ac;
    engine
      .search(fen, {
        depth: MAX_DEPTH,
        multipv: Math.min(3, chess.moves().length),
        signal: ac.signal,
        configure: (e) => e.setFullStrength(),
        onInfo: (l) => {
          if (!ac.signal.aborted) setLines(l);
        },
      })
      .catch(() => undefined);
    return () => ac.abort();
  }, [engine, engineOn, fen, chess]);

  // Keyboard navigation.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT")) return;
      if (e.key === "ArrowLeft") setPly((p) => Math.max(0, p - 1));
      else if (e.key === "ArrowRight") setPly((p) => Math.min(moves.length, p + 1));
      else if (e.key === "Home") setPly(0);
      else if (e.key === "End") setPly(moves.length);
      else return;
      e.preventDefault();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [moves.length]);

  const onMove = (from: string, to: string, promotion?: string) => {
    const c = new Chess(fen);
    let m: Move;
    try {
      m = c.move({ from, to, promotion });
    } catch {
      return false;
    }
    playSound(soundForSan(m.san, m.captured));
    const next = moves[ply];
    if (next && next.from === m.from && next.to === m.to && next.promotion === m.promotion) {
      setPly(ply + 1);
      return true;
    }
    // Branch: replace the rest of the line with the new move.
    setMoves([...moves.slice(0, ply), m]);
    setPly(ply + 1);
    return true;
  };

  const playLineMove = (uci: string) => onMove(uci.slice(0, 2), uci.slice(2, 4), uci[4]);

  const opening: Opening | null = useMemo(() => {
    for (let i = ply; i >= 0; i--) {
      const o = lookupOpening(fens[i]);
      if (o) return o;
    }
    return null;
  }, [fens, ply]);

  const result = chess.isCheckmate() ? (stm === "w" ? "0-1" : "1-0") : chess.isDraw() ? "1/2-1/2" : headers.Result && ply === moves.length ? headers.Result : "*";
  const pgn = buildPgn({ moves, startFen, result: moves.length && ply === moves.length ? result : headers.Result ?? "*", headers: { Event: headers.Event ?? "Analysis", White: headers.White ?? "?", Black: headers.Black ?? "?", ...(headers.Date ? { Date: headers.Date } : {}) } });

  const top = lines[0];
  const evalCp = chess.isCheckmate() ? (stm === "w" ? -10000 : 10000) : top ? scoreToWhiteCp(top.score, stm) : 0;
  const evalLabel = chess.isCheckmate() ? (stm === "w" ? "0-1" : "1-0") : chess.isDraw() ? "½" : top ? formatScore(top.score, stm) : engineOn ? "…" : "–";

  const review = () => {
    setHandoff({ pgn, title: gameTitle(headers) });
    router.push("/review?source=handoff");
  };

  const status_ = chess.isCheckmate() ? "Checkmate" : chess.isStalemate() ? "Stalemate" : chess.isInsufficientMaterial() ? "Insufficient material" : chess.isThreefoldRepetition() ? "Threefold repetition" : chess.isDrawByFiftyMoves() ? "50-move rule" : chess.inCheck() ? "Check" : "";

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Analysis board</h1>
      {loadError && <p role="alert" className="rounded-lg border border-bad/50 bg-bad/10 px-3 py-2 text-sm text-bad">{loadError}</p>}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[minmax(0,1fr)_400px]">
        <div className="mx-auto w-full max-w-[min(100%,calc(100vh-9rem))] space-y-3">
          <Board
            fen={fen}
            orientation={orientation}
            movable="both"
            onMove={onMove}
            lastMove={ply > 0 ? { from: moves[ply - 1].from, to: moves[ply - 1].to } : null}
            arrows={engineOn && top?.pv[0] ? [{ from: top.pv[0].slice(0, 2), to: top.pv[0].slice(2, 4), color: "rgba(70,180,80,0.8)" }] : []}
            side={engineOn ? <EvalBar whiteCp={evalCp} label={evalLabel} orientation={orientation} /> : undefined}
            id="analysis-board"
          />
          <div className="flex flex-wrap items-center gap-2" role="toolbar" aria-label="Move navigation">
            <button type="button" className="btn" onClick={() => setPly(0)} aria-label="First move">⏮</button>
            <button type="button" className="btn" onClick={() => setPly((p) => Math.max(0, p - 1))} aria-label="Previous move">◀</button>
            <button type="button" className="btn" onClick={() => setPly((p) => Math.min(moves.length, p + 1))} aria-label="Next move">▶</button>
            <button type="button" className="btn" onClick={() => setPly(moves.length)} aria-label="Last move">⏭</button>
            <button type="button" className="btn" onClick={() => setOrientation((o) => (o === "white" ? "black" : "white"))} aria-label="Flip board">⇅</button>
            <button type="button" className="btn" onClick={() => load(START_FEN, [])}>New board</button>
            {status_ && <span className="ml-auto text-sm font-semibold text-accent" role="status">{status_}</span>}
          </div>
          <ExportBar pgn={pgn} fen={fen} />
        </div>

        <aside className="space-y-3">
          <section className="card space-y-2" aria-labelledby="engine-heading">
            <div className="flex items-center gap-2">
              <h2 id="engine-heading" className="label mb-0">Engine</h2>
              <label className="ml-auto flex items-center gap-2 text-sm">
                <input type="checkbox" checked={engineOn} onChange={(e) => setEngineOn(e.target.checked)} className="h-4 w-4 accent-[var(--accent)]" />
                Live analysis
              </label>
            </div>
            {engineOn && status === "error" && <EngineError message={engineError} onRetry={retry} />}
            {engineOn && status === "loading" && <p className="text-sm text-muted" role="status">Loading Stockfish…</p>}
            {engineOn && status === "ready" && (
              <>
                <p className="text-xs text-muted" aria-live="off">Stockfish 17.1 · depth {top?.depth ?? 0}/{MAX_DEPTH}</p>
                <ol className="space-y-1">
                  {lines.map((l) => (
                    <li key={l.multipv} className="flex items-start gap-2 text-sm">
                      <span className={`w-14 shrink-0 rounded px-1 text-center font-mono font-bold ${scoreToWhiteCp(l.score, stm) >= 0 ? "bg-[#f1f1ee] text-[#1d1f24]" : "bg-[#2b2f36] text-[#f1f1ee]"}`}>
                        {formatScore(l.score, stm)}
                      </span>
                      <button type="button" className="min-w-0 text-left font-mono text-xs leading-5 hover:text-accent" onClick={() => playLineMove(l.pv[0])} title="Play the first move of this line">
                        {pvToSan(fen, l.pv, 10).join(" ")}
                      </button>
                    </li>
                  ))}
                  {lines.length === 0 && !chess.isGameOver() && <li className="text-sm text-muted">Thinking…</li>}
                  {chess.isGameOver() && <li className="text-sm text-muted">Game over in this position.</li>}
                </ol>
              </>
            )}
          </section>

          <section className="card space-y-1 p-2">
            <div className="px-2 text-xs text-muted">
              {opening ? (
                <>
                  <span className="font-mono">{opening.eco}</span> {opening.name}
                </>
              ) : startFen !== START_FEN ? (
                "Custom position"
              ) : (
                "Starting position"
              )}
            </div>
            <MoveList moves={moves.map((m) => ({ san: m.san }))} current={ply} onSelect={setPly} startFen={startFen} className="max-h-60" />
          </section>

          <section className="card space-y-2">
            <h2 className="label">Use this game</h2>
            <div className="flex flex-wrap gap-2">
              <button type="button" className="btn-primary" onClick={review} disabled={moves.length === 0}>Game Review</button>
            </div>
            <div className="flex flex-wrap items-end gap-2">
              <div className="min-w-0 flex-1">
                <label htmlFor="play-bot" className="label">Play from here vs {botForElo(elo).name} · {elo}</label>
                <input id="play-bot" type="range" min={ELO_MIN} max={ELO_MAX} step={ELO_STEP} value={elo} onChange={(e) => setElo(Number(e.target.value))} className="elo-slider w-full" style={{ ["--fill" as string]: `${((elo - ELO_MIN) / (ELO_MAX - ELO_MIN)) * 100}%` }} />
              </div>
              <button
                type="button"
                className="btn"
                disabled={chess.isGameOver()}
                onClick={() => router.push(`/play/computer?fen=${encodeURIComponent(fen)}&elo=${elo}`)}
              >
                Play
              </button>
            </div>
          </section>

          <ImportPanel
            onGame={(g) => {
              setLoadError("");
              load(g.startFen, g.moves, g.headers, false);
            }}
            onFen={(f) => {
              setLoadError("");
              load(f, []);
            }}
          />
        </aside>
      </div>
    </div>
  );
}
