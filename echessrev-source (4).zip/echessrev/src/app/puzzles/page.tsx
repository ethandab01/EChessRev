import type { Metadata } from "next";
import { PuzzlesClient } from "./PuzzlesClient";

export const metadata: Metadata = { title: "Puzzles" };

export default function PuzzlesPage() {
  return <PuzzlesClient />;
}
