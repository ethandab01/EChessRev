"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useSession } from "next-auth/react";
import { Chess } from "chess.js";
import { Board } from "@/components/Board";
import { Confetti } from "@/components/GameOverFx";
import { IconFlame } from "@/components/Icons";
import { checkPuzzleMove, puzzleRatingUpdate, themeLabels, type Puzzle } from "@/lib/chess/puzzles";
import { playSound, soundForSan } from "@/lib/client/sounds";
import { notifyPointsChanged, useMe } from "@/lib/client/useMe";

type Status = "loading" | "intro" | "playing" | "wrong" | "correct" | "solved" | "failed" | "error";

const GUEST_KEY = "echessrev:puzzles";
const THEMES = [
  { id: "", label: "All" },
  { id: "mate", label: "Checkmate" },
  { id: "fork", label: "Forks" },
  { id: "pin", label: "Pins" },
  { id: "sacrifice", label: "Sacrifices" },
  { id: "discoveredAttack", label: "Discoveries" },
  { id: "endgame", label: "Endgames" },
];

function loadGuest(): { rating: number; streak: number } {
  try {
    const s = JSON.parse(localStorage.getItem(GUEST_KEY) ?? "{}");
    return { rating: Number(s.rating) || 1200, streak: Number(s.streak) || 0 };
  } catch {
    return { rating: 1200, streak: 0 };
  }
}
function saveGuest(v: { rating: number; streak: number }) {
  try {
    localStorage.setItem(GUEST_KEY, JSON.stringify(v));
  } catch {
    /* ignore */
  }
}

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

export function PuzzlesClient() {
  const { status: authStatus } = useSession();
  const me = useMe();
  const signedIn = authStatus === "authenticated";

  const [puzzle, setPuzzle] = useState<Puzzle | null>(null);
  const [fen, setFen] = useState("");
  const [step, setStep] = useState(1);
  const [status, setStatus] = useState<Status>("loading");
  const [error, setError] = useState("");
  const [lastMove, setLastMove] = useState<{ from: string; to: string } | null>(null);
  const [badge, setBadge] = useState<{ square: string; ok: boolean; key: number } | null>(null);
  const [hint, setHint] = useState<string | null>(null);
  const [firstTry, setFirstTry] = useState(true);
  const [reported, setReported] = useState(false);
  const [rating, setRating] = useState(1200);
  const [streak, setStreak] = useState(0);
  const [delta, setDelta] = useState<number | null>(null);
  const [earned, setEarned] = useState(0);
  const [theme, setTheme] = useState("");
  const seen = useRef<string[]>([]);
  // ✓ / ✕ markers fade away on their own.
  useEffect(() => {
    if (!badge) return;
    const t = setTimeout(() => setBadge((b) => (b && b.key === badge.key ? null : b)), badge.ok ? 900 : 1100);
    return () => clearTimeout(t);
  }, [badge]);
  const token = useRef(0);

  // Sync rating/streak from account (or local storage for guests).
  useEffect(() => {
    if (me) {
      setRating(me.puzzleRating);
      setStreak(me.puzzleStreak);
    } else if (authStatus === "unauthenticated") {
      const g = loadGuest();
      setRating(g.rating);
      setStreak(g.streak);
    }
  }, [me, authStatus]);

  const orientation: "white" | "black" = puzzle ? (new Chess(puzzle.fen).turn() === "w" ? "black" : "white") : "white";
  const solverColor = orientation === "white" ? "w" : "b";

  const applyUci = (f: string, uci: string) => {
    const c = new Chess(f);
    const m = c.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), promotion: uci[4] });
    playSound(soundForSan(m.san, m.captured));
    setLastMove({ from: m.from, to: m.to });
    return c.fen();
  };

  const load = useCallback(async () => {
    const my = ++token.current;
    setStatus("loading");
    setError("");
    setBadge(null);
    setHint(null);
    setDelta(null);
    setEarned(0);
    setFirstTry(true);
    setReported(false);
    setLastMove(null);
    const params = new URLSearchParams({ rating: String(rating), exclude: seen.current.slice(-200).join(",") });
    if (theme) params.set("theme", theme);
    try {
      const res = await fetch(`/api/puzzles/next?${params}`);
      const j = await res.json();
      if (!res.ok) throw new Error(j.error ?? "Could not load a puzzle.");
      if (my !== token.current) return;
      const p: Puzzle = j.puzzle;
      seen.current.push(p.id);
      setPuzzle(p);
      setFen(p.fen);
      setStep(1);
      setStatus("intro");
      await sleep(650);
      if (my !== token.current) return;
      setFen(applyUci(p.fen, p.moves[0]));
      setStatus("playing");
    } catch (e) {
      setError((e as Error).message);
      setStatus("error");
    }
  }, [rating, theme]);

  useEffect(() => {
    if (authStatus === "loading") return;
    load();
    // Load once when auth state is known, and when the theme changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authStatus, theme]);

  /** Record the first resolution of this puzzle (rating, streak, points). */
  const report = async (solved: boolean) => {
    if (!puzzle || reported) return;
    setReported(true);
    if (signedIn) {
      try {
        const res = await fetch("/api/puzzles/attempt", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ puzzleId: puzzle.id, solved }) });
        const j = await res.json();
        if (res.ok) {
          setRating(j.rating);
          setStreak(j.streak);
          setDelta(j.repeat ? null : j.delta);
          setEarned(j.points ?? 0);
          notifyPointsChanged();
        }
      } catch {
        /* offline: ignore */
      }
    } else {
      const next = puzzleRatingUpdate(rating, puzzle.rating, solved);
      const nextStreak = solved ? streak + 1 : 0;
      setDelta(next - rating);
      setRating(next);
      setStreak(nextStreak);
      saveGuest({ rating: next, streak: nextStreak });
    }
  };

  const onMove = (from: string, to: string, promotion?: string): boolean => {
    if (!puzzle || (status !== "playing" && status !== "wrong" && status !== "correct")) return false;
    const uci = `${from}${to}${promotion ?? ""}`;
    const verdict = checkPuzzleMove(puzzle, step, fen, uci);
    if (verdict === "wrong") {
      playSound("illegal");
      setBadge({ square: to, ok: false, key: Date.now() });
      setStatus("wrong");
      if (firstTry) {
        setFirstTry(false);
        report(false);
      }
      return false;
    }
    const after = applyUci(fen, uci);
    setFen(after);
    setBadge({ square: to, ok: true, key: Date.now() });
    setHint(null);
    if (verdict === "solved") {
      setStatus("solved");
      playSound("promote");
      if (firstTry) report(true);
      return true;
    }
    setStatus("correct");
    const my = token.current;
    const reply = puzzle.moves[step + 1];
    setTimeout(() => {
      if (my !== token.current) return;
      setFen((f) => applyUci(f, reply));
      setStep(step + 2);
      setStatus("playing");
    }, 550);
    return true;
  };

  const showHint = () => {
    if (!puzzle) return;
    setHint(puzzle.moves[step].slice(0, 2));
    if (firstTry) {
      setFirstTry(false);
      report(false);
    }
  };

  const showSolution = async () => {
    if (!puzzle) return;
    if (firstTry) {
      setFirstTry(false);
      report(false);
    }
    const my = token.current;
    setStatus("failed");
    setHint(null);
    let f = fen;
    for (let i = step; i < puzzle.moves.length; i++) {
      if (my !== token.current) return;
      f = applyUci(f, puzzle.moves[i]);
      setFen(f);
      await sleep(650);
    }
  };

  const retry = async () => {
    if (!puzzle) return;
    const my = ++token.current;
    setBadge(null);
    setHint(null);
    setLastMove(null);
    setFen(puzzle.fen);
    setStep(1);
    setStatus("intro");
    await sleep(500);
    if (my !== token.current) return;
    setFen(applyUci(puzzle.fen, puzzle.moves[0]));
    setStatus("playing");
  };

  const banner: Record<Status, { text: string; cls: string }> = {
    loading: { text: "Loading puzzle…", cls: "bg-panel-2" },
    intro: { text: "Watch the opponent's move…", cls: "bg-panel-2" },
    playing: { text: `Your turn — find the best move for ${solverColor === "w" ? "White" : "Black"}`, cls: solverColor === "w" ? "bg-white text-black" : "bg-black text-white" },
    wrong: { text: "✕ That's not it. Try again!", cls: "bg-bad text-white" },
    correct: { text: "✓ Best move! Keep going…", cls: "bg-accent text-white" },
    solved: { text: firstTry ? "🎉 Solved!" : "✓ Solved (with help)", cls: "bg-accent text-white" },
    failed: { text: "Here's the solution", cls: "bg-panel-3" },
    error: { text: error, cls: "bg-bad text-white" },
  };
  const done = status === "solved" || status === "failed";
  const b = banner[status];

  return (
    <div className="grid grid-cols-1 gap-5 lg:grid-cols-[minmax(0,1fr)_360px]">
      <div className="mx-auto w-full max-w-[min(100%,calc(100vh-7rem))]">
        <div className="relative">
          <Board
            key={puzzle?.id ?? "empty"}
            fen={fen || "8/8/8/8/8/8/8/8 w - - 0 1"}
            orientation={orientation}
            movable={status === "playing" || status === "wrong" ? solverColor : null}
            onMove={onMove}
            lastMove={lastMove}
            highlights={hint ? { [hint]: "rgba(91, 186, 103, 0.75)" } : undefined}
            id="puzzle-board"
            typedMoves={false}
          />
          {badge && (
            <BadgeOverlay key={badge.key} square={badge.square} ok={badge.ok} orientation={orientation} />
          )}
          {status === "solved" && <Confetti count={firstTry ? 60 : 25} />}
        </div>
      </div>

      <aside className="space-y-3">
        <section className="card overflow-hidden p-0">
          <div key={status + step} className={`px-4 py-4 text-center text-lg font-extrabold transition-colors animate-fade-in ${b.cls}`} role="status" aria-live="polite">
            {b.text}
          </div>
          <div className="grid grid-cols-2 divide-x divide-line border-b border-line">
            <div className="p-4 text-center">
              <div className="text-xs font-bold uppercase tracking-wider text-muted">Your rating</div>
              <div className="flex items-center justify-center gap-2">
                <span className="text-3xl font-extrabold tabular-nums">{rating}</span>
                {delta !== null && delta !== 0 && (
                  <span key={rating} className={`text-sm font-extrabold animate-pop ${delta > 0 ? "text-ok" : "text-bad"}`}>{delta > 0 ? `+${delta}` : delta}</span>
                )}
              </div>
            </div>
            <div className="p-4 text-center">
              <div className="text-xs font-bold uppercase tracking-wider text-muted">Streak</div>
              <div className="flex items-center justify-center gap-1">
                <IconFlame size={26} className={streak > 0 ? "" : "opacity-30 grayscale"} />
                <span key={streak} className="text-3xl font-extrabold tabular-nums animate-pop">{streak}</span>
              </div>
            </div>
          </div>
          <div className="space-y-3 p-4">
            {puzzle && done && (
              <div className="space-y-2 rounded-lg bg-panel-2 p-3 text-sm animate-fade-in">
                <div className="flex justify-between"><span className="text-muted">Puzzle rating</span><span className="font-extrabold">{puzzle.rating}</span></div>
                {themeLabels(puzzle.themes).length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {themeLabels(puzzle.themes).slice(0, 5).map((t) => <span key={t} className="rounded-md bg-panel-3 px-2 py-0.5 text-xs font-bold">{t}</span>)}
                  </div>
                )}
                {earned > 0 && <div className="text-center text-lg font-extrabold text-gold animate-pop">+{earned} ◆</div>}
              </div>
            )}
            {done ? (
              <>
                <button type="button" className="btn-primary btn-xl w-full" onClick={load}>Next Puzzle</button>
                <button type="button" className="btn w-full py-2.5" onClick={retry}>↻ Try again</button>
              </>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <button type="button" className="btn py-3" onClick={showHint} disabled={status !== "playing" && status !== "wrong"}>💡 Hint</button>
                <button type="button" className="btn py-3" onClick={showSolution} disabled={status !== "playing" && status !== "wrong"}>Solution</button>
              </div>
            )}
            {status === "error" && <button type="button" className="btn w-full" onClick={load}>Try again</button>}
            {!signedIn && authStatus !== "loading" && (
              <p className="text-center text-xs text-muted"><Link href="/register" className="font-bold text-accent hover:underline">Sign up</Link> to save your puzzle rating and earn points.</p>
            )}
          </div>
        </section>

        <section className="card p-4">
          <h2 className="label">Themes</h2>
          <div className="flex flex-wrap gap-1.5">
            {THEMES.map((t) => (
              <button key={t.id} type="button" onClick={() => setTheme(t.id)} className={`chip px-3 py-1.5 text-xs ${theme === t.id ? "chip-on" : ""}`} aria-pressed={theme === t.id}>
                {t.label}
              </button>
            ))}
          </div>
        </section>
      </aside>
    </div>
  );
}

/** ✓ / ✕ marker that pops onto the destination square. */
function BadgeOverlay({ square, ok, orientation }: { square: string; ok: boolean; orientation: "white" | "black" }) {
  const f = "abcdefgh".indexOf(square[0]);
  const r = Number(square[1]);
  const x = orientation === "white" ? f : 7 - f;
  const y = orientation === "white" ? 8 - r : r - 1;
  return (
    <div className="pointer-events-none absolute z-20" style={{ left: `${((x + 1) / 8) * 100}%`, top: `${(y / 8) * 100}%`, transform: "translate(-65%, -35%)" }}>
      <span className={`flex h-8 w-8 items-center justify-center rounded-full text-base font-extrabold text-white shadow-lg animate-pop ${ok ? "bg-accent" : "bg-bad"}`} aria-hidden>
        {ok ? "✓" : "✕"}
      </span>
    </div>
  );
}
