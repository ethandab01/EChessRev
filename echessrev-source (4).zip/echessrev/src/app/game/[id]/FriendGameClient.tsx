"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Chess } from "chess.js";
import { Board } from "@/components/Board";
import { MoveList } from "@/components/MoveList";
import { GameOverFx } from "@/components/GameOverFx";
import { useMe } from "@/lib/client/useMe";
import { UserAvatar, NameWithFlair } from "@/components/UserAvatar";
import { RankBadge } from "@/components/RankBadge";
import { IconChevron } from "@/components/Icons";
import { TERMINATION_TEXT, type Termination } from "@/lib/chess/gameEnd";
import { rankFor } from "@/lib/chess/ranks";
import { buildPgn } from "@/lib/chess/pgn";
import { playSound, soundForSan } from "@/lib/client/sounds";
import { setHandoff } from "@/lib/client/handoff";
import { notifyPointsChanged } from "@/lib/client/useMe";

interface Player {
  id: string;
  username: string | null;
  rating: number;
  avatarIcon: string | null;
  flair: string | null;
}
interface G {
  id: string;
  kind: "friend" | "online";
  status: "pending" | "active" | "finished" | "declined" | "cancelled";
  timeControl: string;
  rated: boolean;
  moves: string[];
  fen: string;
  turn: "w" | "b";
  clocks: { w: number; b: number } | null;
  clockRunning: boolean;
  white: Player;
  black: Player;
  youAre: "w" | "b" | null;
  challengerId: string;
  drawOfferBy: "w" | "b" | null;
  result: string | null;
  termination: string | null;
  deltas: { w: number; b: number } | null;
}

function formatClock(ms: number) {
  const t = Math.max(0, ms);
  const s = t / 1000;
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return s < 10 ? `${m}:${sec.toString().padStart(2, "0")}.${Math.floor((t % 1000) / 100)}` : `${m}:${sec.toString().padStart(2, "0")}`;
}


export function FriendGameClient({ id }: { id: string }) {
  const router = useRouter();
  const me_ = useMe();
  const [game, setGame] = useState<G | null>(null);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [receivedAt, setReceivedAt] = useState(0);
  const [viewPly, setViewPly] = useState<number | null>(null);
  const [orientation, setOrientation] = useState<"white" | "black" | null>(null);
  const [confirmResign, setConfirmResign] = useState(false);
  const [showResult, setShowResult] = useState(true);
  const [ratingBefore, setRatingBefore] = useState<number | null>(null);
  const [, tick] = useState(0);
  const pending = useRef(false);
  const lastPlies = useRef<number | null>(null);

  const accept = useCallback((g: G) => {
    setGame((prev) => {
      // Sound for the opponent's new moves.
      if (prev && g.moves.length > prev.moves.length && lastPlies.current !== null) {
        const c = new Chess();
        let san = "";
        for (const u of g.moves) san = c.move({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] }).san;
        playSound(soundForSan(san));
      }
      if (prev && prev.status !== "finished" && g.status === "finished") {
        playSound("end");
        notifyPointsChanged();
      }
      return g;
    });
    lastPlies.current = g.moves.length;
    setReceivedAt(Date.now());
    if (g.youAre) {
      setOrientation((o) => o ?? (g.youAre === "b" ? "black" : "white"));
      setRatingBefore((r) => r ?? (g.status === "finished" && g.deltas ? (g.youAre === "w" ? g.white.rating - g.deltas.w : g.black.rating - g.deltas.b) : g.youAre === "w" ? g.white.rating : g.black.rating));
    }
  }, []);

  const fetchGame = useCallback(async () => {
    if (pending.current) return;
    try {
      const res = await fetch(`/api/friend-games/${id}`, { cache: "no-store" });
      const j = await res.json();
      if (!res.ok) throw new Error(j.error ?? "Could not load the game.");
      if (!pending.current) accept(j.game);
    } catch (e) {
      setError((e as Error).message);
    }
  }, [id, accept]);

  useEffect(() => {
    fetchGame();
  }, [fetchGame]);

  // Poll while the game is live; tick clocks.
  const live = game?.status === "active" || game?.status === "pending";
  useEffect(() => {
    if (!live) return;
    const poll = setInterval(fetchGame, 1000);
    const t = setInterval(() => tick((x) => x + 1), 200);
    return () => {
      clearInterval(poll);
      clearInterval(t);
    };
  }, [live, fetchGame]);

  const fens = useMemo(() => {
    if (!game) return [] as string[];
    const c = new Chess();
    const out = [c.fen()];
    for (const u of game.moves) {
      c.move({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] });
      out.push(c.fen());
    }
    return out;
  }, [game]);
  const sans = useMemo(() => {
    if (!game) return [] as Array<{ san: string; from: string; to: string }>;
    const c = new Chess();
    return game.moves.map((u) => {
      const m = c.move({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] });
      return { san: m.san, from: m.from, to: m.to };
    });
  }, [game]);

  const plyCount = game?.moves.length ?? 0;
  const shownPly = viewPly ?? plyCount;
  const navTo = useCallback((p: number) => {
    const t = Math.max(0, Math.min(plyCount, p));
    setViewPly(t >= plyCount ? null : t);
  }, [plyCount]);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA")) return;
      if (e.key === "ArrowLeft") navTo(shownPly - 1);
      else if (e.key === "ArrowRight") navTo(shownPly + 1);
      else if (e.key === "Home") navTo(0);
      else if (e.key === "End") navTo(plyCount);
      else return;
      e.preventDefault();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [navTo, shownPly, plyCount]);

  const post = async (path: string, body: object) => {
    pending.current = true;
    try {
      const res = await fetch(`/api/friend-games/${id}/${path}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const j = await res.json().catch(() => ({}));
      if (j.game) accept(j.game);
      if (!res.ok) setNotice(j.error ?? "Something went wrong.");
      return res.ok;
    } finally {
      pending.current = false;
    }
  };

  const onMove = (from: string, to: string, promotion?: string): boolean => {
    if (!game || game.status !== "active" || game.turn !== game.youAre || viewPly !== null) return false;
    const c = new Chess(game.fen);
    let m;
    try {
      m = c.move({ from, to, promotion });
    } catch {
      return false;
    }
    playSound(soundForSan(m.san, m.captured));
    const uci = `${m.from}${m.to}${m.promotion ?? ""}`;
    const ply = game.moves.length;
    // Optimistic update.
    setGame({ ...game, moves: [...game.moves, uci], fen: c.fen(), turn: c.turn(), drawOfferBy: null });
    lastPlies.current = ply + 1;
    setNotice("");
    post("move", { uci, ply });
    return true;
  };

  const action = (a: string) => {
    setConfirmResign(false);
    post("action", { action: a });
  };

  if (error && !game) {
    return (
      <div className="mx-auto mt-16 max-w-md text-center">
        <p className="text-lg font-bold">{error}</p>
        <Link href="/friends" className="btn mt-4">Back to friends</Link>
      </div>
    );
  }
  if (!game) return <div className="mx-auto mt-10 max-w-3xl"><div className="skeleton aspect-square w-full max-w-[600px]" /></div>;

  const me = game.youAre;
  const opp: "w" | "b" = me === "b" ? "w" : "b";
  const orient = orientation ?? "white";
  const top: "w" | "b" = orient === "white" ? "b" : "w";
  const bottom: "w" | "b" = top === "w" ? "b" : "w";
  const viewing = viewPly !== null;
  const shownMove = shownPly > 0 ? sans[shownPly - 1] : null;
  const elapsed = game.clockRunning ? Date.now() - receivedAt : 0;
  const clockFor = (c: "w" | "b") => (game.clocks ? game.clocks[c] - (game.status === "active" && game.turn === c ? elapsed : 0) : null);
  const player = (c: "w" | "b") => (c === "w" ? game.white : game.black);

  let outcome: "win" | "loss" | "draw" | null = null;
  if (game.status === "finished" && game.result && me) {
    outcome = game.result === "1/2-1/2" ? "draw" : (game.result === "1-0") === (me === "w") ? "win" : "loss";
  }
  const myDelta = game.deltas && me ? game.deltas[me] : null;
  const ratingAfter = me ? player(me).rating : 1200;
  const rankBefore = ratingBefore != null ? rankFor(ratingBefore) : null;
  const rankAfter = rankFor(ratingAfter);
  const rankChanged = rankBefore && rankBefore.name !== rankAfter.name && myDelta != null;

  const playerRow = (c: "w" | "b") => {
    const p = player(c);
    const ms = clockFor(c);
    const active = game.status === "active" && game.turn === c;
    return (
      <div className="flex items-center gap-3 py-2">
        <UserAvatar name={p.username ?? "?"} icon={p.avatarIcon} />
        <div className="min-w-0">
          <div className="flex items-center gap-2 truncate text-sm font-bold">
            <span><NameWithFlair name={p.username ?? "?"} flair={p.flair} /></span> <span className="font-normal text-muted">({p.rating})</span>
          </div>
          <div className="flex h-5 items-center gap-2">
            <RankBadge rating={p.rating} />
            {active && c !== me && <span className="text-xs text-muted">thinking…</span>}
          </div>
        </div>
        {ms !== null && (
          <div className={`ml-auto min-w-[96px] rounded-md px-3 py-1.5 text-right font-mono text-2xl font-bold tabular-nums ${active && game.clockRunning ? (ms < 10000 ? "bg-bad text-white animate-pulse" : "bg-fg text-bg") : "bg-panel-2 text-muted"}`} role="timer" aria-label={`${c === "w" ? "White" : "Black"} clock`}>
            {formatClock(ms)}
          </div>
        )}
      </div>
    );
  };

  const reviewGame = () => {
    const pgn = buildPgn({
      moves: sans,
      result: game.result ?? "*",
      headers: { Event: "EChessREV friend game", White: game.white.username ?? "?", Black: game.black.username ?? "?", ...(game.termination ? { Termination: game.termination } : {}) },
    });
    setHandoff({ pgn, title: `${game.white.username} vs ${game.black.username}` });
    router.push("/review?source=handoff");
  };

  const rematch = async () => {
    if (game.kind === "online") {
      router.push(`/play?quick=${game.timeControl}`);
      return;
    }
    const res = await fetch("/api/friend-games", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: player(opp).username, timeControl: game.timeControl, color: me === "w" ? "b" : "w", rated: game.rated }),
    });
    const j = await res.json().catch(() => ({}));
    if (res.ok) router.push(`/game/${j.id}`);
    else setNotice(j.error ?? "Could not send a rematch.");
  };

  const navBtn = (label: string, onClick: () => void, disabled: boolean, child: React.ReactNode) => (
    <button type="button" className="btn h-11 flex-1 p-0" onClick={onClick} disabled={disabled} aria-label={label} title={label}>{child}</button>
  );

  return (
    <div className="grid grid-cols-1 gap-5 lg:grid-cols-[minmax(0,1fr)_380px]">
      <div className="mx-auto w-full max-w-[min(100%,calc(100vh-10rem))]">
        {playerRow(top)}
        <div className="relative">
          <Board
            fen={viewing ? fens[shownPly] : game.fen}
            orientation={orient}
            movable={game.status === "active" && !viewing && me ? me : null}
            onMove={onMove}
            lastMove={shownMove}
            id="friend-board"
          />
          {outcome && <GameOverFx key={game.id} effect={me_?.winEffect} outcome={outcome} kingColor={outcome === "loss" ? me ?? "w" : opp} />}
          {outcome && showResult && (
            <div className="absolute inset-0 z-30 flex items-center justify-center p-4">
              <div className="w-full max-w-[310px] overflow-hidden rounded-xl bg-panel text-center shadow-2xl animate-pop" style={{ animationDelay: "0.35s" }} role="dialog" aria-label="Game over">
                <div className={`relative px-4 py-4 ${outcome === "win" ? "bg-accent text-white" : outcome === "loss" ? "bg-panel-3" : "bg-panel-2"}`}>
                  <button type="button" onClick={() => setShowResult(false)} className="absolute right-2 top-2 rounded p-1 opacity-80 hover:opacity-100" aria-label="Close and view board">✕</button>
                  <div className="text-2xl font-extrabold">{outcome === "win" ? "You Won!" : outcome === "loss" ? "You Lost" : "Draw"}</div>
                  <div className="text-sm opacity-85">{TERMINATION_TEXT[game.termination as Termination] ?? game.termination}</div>
                </div>
                <div className="space-y-3 p-4">
                  {myDelta != null ? (
                    <div className="flex items-center justify-center gap-2">
                      <span className="text-3xl font-extrabold tabular-nums">{ratingAfter}</span>
                      <span className={`rounded-md px-2 py-0.5 text-sm font-extrabold animate-pop ${myDelta >= 0 ? "bg-ok/15 text-ok" : "bg-bad/15 text-bad"}`} style={{ animationDelay: "0.8s" }}>{myDelta >= 0 ? `+${myDelta}` : myDelta}</span>
                    </div>
                  ) : (
                    <p className="text-sm text-muted">{game.rated ? "Too short to be rated." : "Casual game — no rating change."}</p>
                  )}
                  {rankChanged && (
                    <div className="rounded-lg p-2 text-sm font-extrabold animate-pop" style={{ animationDelay: "1.1s", background: `${rankAfter.color}22`, color: rankAfter.color }}>
                      {ratingAfter > (ratingBefore ?? 0) ? "Rank up!" : "Rank down"} {rankAfter.icon} {rankAfter.name}
                    </div>
                  )}
                  <button type="button" className="btn-primary w-full py-3 text-base" onClick={reviewGame} disabled={plyCount === 0}>Game Review</button>
                  <div className="grid grid-cols-2 gap-2">
                    <button type="button" className="btn py-2.5" onClick={rematch}>{game.kind === "online" ? "New opponent" : "Rematch"}</button>
                    <Link href={game.kind === "online" ? "/play" : "/friends"} className="btn py-2.5">{game.kind === "online" ? "Play" : "Friends"}</Link>
                  </div>
                </div>
              </div>
            </div>
          )}
          {game.status === "pending" && (
            <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/40 p-4 animate-fade-in">
              <div className="card w-full max-w-[320px] space-y-3 text-center shadow-2xl animate-pop">
                {game.challengerId === player(opp).id ? (
                  <>
                    <div className="text-lg font-extrabold">{player(opp).username} challenged you</div>
                    <div className="text-sm text-muted">{game.timeControl === "unlimited" ? "No clock" : game.timeControl} · you play {me === "w" ? "White" : "Black"} · {game.rated ? "Rated" : "Casual"}</div>
                    <div className="grid grid-cols-2 gap-2">
                      <button type="button" className="btn-primary py-2.5" onClick={() => action("accept")}>Accept</button>
                      <button type="button" className="btn py-2.5" onClick={() => action("decline")}>Decline</button>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="mx-auto h-10 w-10 animate-spin rounded-full border-4 border-panel-3 border-t-accent" aria-hidden />
                    <div className="text-lg font-extrabold">Waiting for {player(opp).username}…</div>
                    <div className="text-sm text-muted">The game starts as soon as they accept.</div>
                    <button type="button" className="btn w-full py-2.5" onClick={() => action("cancel")}>Cancel challenge</button>
                  </>
                )}
              </div>
            </div>
          )}
          {(game.status === "declined" || game.status === "cancelled") && (
            <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/40 p-4">
              <div className="card space-y-3 text-center">
                <div className="text-lg font-extrabold">{game.status === "declined" ? "Challenge declined" : game.termination === "aborted" ? "Game aborted" : "Challenge cancelled"}</div>
                <Link href="/friends" className="btn-primary w-full py-2.5">Back to friends</Link>
              </div>
            </div>
          )}
        </div>
        {playerRow(bottom)}
      </div>

      <aside className="flex flex-col gap-3">
        <section className="card flex min-h-[300px] flex-col p-0 lg:min-h-[420px]">
          <div className="flex items-center gap-2 border-b border-line px-4 py-3">
            <span className="text-sm font-extrabold">vs {player(opp).username}</span>
            <span className="ml-auto text-xs font-bold text-muted">{game.kind === "online" ? "Online" : "Friend"} · {game.rated ? "Rated" : "Casual"} · {game.timeControl === "unlimited" ? "∞" : game.timeControl}</span>
          </div>
          <MoveList moves={sans.map((m) => ({ san: m.san }))} current={shownPly} onSelect={navTo} className="max-h-[42vh] flex-1 px-2 py-2" />
          {viewing && (
            <button type="button" onClick={() => setViewPly(null)} className="mx-3 mb-2 rounded-lg bg-gold-soft px-3 py-1.5 text-xs font-bold text-gold animate-fade-in">
              Viewing move {shownPly} of {plyCount} — back to live ⏭
            </button>
          )}
          <div className="flex gap-1.5 border-t border-line p-3" role="toolbar" aria-label="Move navigation">
            {navBtn("First move", () => navTo(0), shownPly === 0, <span className="flex"><IconChevron dir="left" /><IconChevron dir="left" className="-ml-3" /></span>)}
            {navBtn("Previous move (←)", () => navTo(shownPly - 1), shownPly === 0, <IconChevron dir="left" size={24} />)}
            {navBtn("Next move (→)", () => navTo(shownPly + 1), !viewing, <IconChevron size={24} />)}
            {navBtn("Latest move", () => navTo(plyCount), !viewing, <span className="flex"><IconChevron /><IconChevron className="-ml-3" /></span>)}
          </div>
        </section>

        {game.status === "active" && game.drawOfferBy && game.drawOfferBy !== me && (
          <div className="card flex items-center gap-2 p-3 ring-2 ring-gold animate-pop" role="alert">
            <span className="flex-1 text-sm font-extrabold">{player(opp).username} offers a draw</span>
            <button type="button" className="btn-primary py-1.5" onClick={() => action("accept-draw")}>Accept</button>
            <button type="button" className="btn py-1.5" onClick={() => action("decline-draw")}>Decline</button>
          </div>
        )}
        {game.status === "active" && game.drawOfferBy === me && <p className="rounded-lg bg-panel px-3 py-2 text-sm text-muted">Draw offered — waiting for a reply.</p>}
        {game.status === "active" && game.turn === me && !viewing && <p className="rounded-lg bg-accent-soft px-3 py-2 text-center text-sm font-extrabold text-accent animate-fade-in">Your move</p>}
        {notice && <p className="rounded-lg bg-panel px-3 py-2 text-sm text-muted animate-fade-in" role="status">{notice}</p>}

        {game.status === "active" ? (
          <div className="grid grid-cols-2 gap-2">
            {plyCount < 2 ? (
              <button type="button" className="btn py-2.5" onClick={() => action("abort")}>✕ Abort</button>
            ) : (
              <button type="button" className="btn py-2.5" onClick={() => action("offer-draw")} disabled={game.drawOfferBy === me}>½ Draw</button>
            )}
            {confirmResign ? (
              <button type="button" className="btn bg-bad py-2.5 text-white hover:bg-bad" onClick={() => action("resign")}>Confirm resign</button>
            ) : (
              <button type="button" className="btn py-2.5" onClick={() => setConfirmResign(true)}>⚑ Resign</button>
            )}
            <button type="button" className="btn col-span-2 py-2.5" onClick={() => setOrientation((o) => (o === "black" ? "white" : "black"))}>⇅ Flip board</button>
          </div>
        ) : game.status === "finished" ? (
          <div className="grid grid-cols-2 gap-2">
            <button type="button" className="btn-primary col-span-2 py-3 text-base" onClick={reviewGame} disabled={plyCount === 0}>Game Review</button>
            <button type="button" className="btn py-2.5" onClick={rematch}>{game.kind === "online" ? "New opponent" : "Rematch"}</button>
            <Link href={game.kind === "online" ? "/play" : "/friends"} className="btn py-2.5">{game.kind === "online" ? "Play" : "Friends"}</Link>
          </div>
        ) : null}
      </aside>
    </div>
  );
}
