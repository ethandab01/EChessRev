import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { auth } from "@/auth";
import { FriendGameClient } from "./FriendGameClient";

export const metadata: Metadata = { title: "Friend game" };
export const dynamic = "force-dynamic";

export default async function GamePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const session = await auth();
  if (!session?.user?.id) redirect(`/login?callbackUrl=/game/${id}`);
  return <FriendGameClient id={id} />;
}
