import Link from "next/link";
import { auth } from "@/auth";
import { prisma } from "@/lib/server/db";
import { pointsFor } from "@/lib/server/points";
import { pickPuzzle } from "@/lib/server/puzzleDb";
import { parsePgn, START_FEN } from "@/lib/chess/pgn";
import { botForElo } from "@/lib/chess/bots";
import { Chess } from "chess.js";
import { MiniBoard } from "@/components/MiniBoard";
import { PlayPanel } from "@/components/PlayPanel";
import { IconFlame } from "@/components/Icons";
import { UserAvatar, NameWithFlair } from "@/components/UserAvatar";
import { wallet } from "@/lib/server/wallet";

export const dynamic = "force-dynamic";

function Card({ fen, orientation, children, delay = 0, label }: { fen: string; orientation?: "white" | "black"; children: React.ReactNode; delay?: number; label: string }) {
  return (
    <article className="flex flex-col overflow-hidden rounded-xl bg-panel animate-fade-up transition hover:-translate-y-1 hover:shadow-xl" style={{ animationDelay: `${delay}ms` }}>
      <MiniBoard fen={fen} orientation={orientation} label={label} />
      <div className="flex flex-1 flex-col gap-3 p-4">{children}</div>
    </article>
  );
}

export default async function Home() {
  const session = await auth();
  const userId = session?.user?.id;

  const user = userId ? await prisma.user.findUnique({ where: { id: userId }, select: { username: true, puzzleRating: true, puzzleStreak: true, avatarIcon: true, flair: true } }) : null;
  const puzzleRating = user?.puzzleRating ?? 1200;
  const puzzle = pickPuzzle(puzzleRating, new Set());
  let puzzleFen = START_FEN;
  let puzzleSide: "white" | "black" = "white";
  if (puzzle) {
    const c = new Chess(puzzle.fen);
    const u = puzzle.moves[0];
    c.move({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] });
    puzzleFen = c.fen();
    puzzleSide = c.turn() === "w" ? "white" : "black";
  }

  const lastGame = userId ? await prisma.game.findFirst({ where: { userId }, orderBy: { createdAt: "desc" } }) : null;
  let lastFen = START_FEN;
  if (lastGame) {
    try {
      const g = parsePgn(lastGame.pgn);
      lastFen = g.fens.at(-1) ?? g.startFen;
    } catch {
      /* keep start position */
    }
  }

  let friends: Array<{ name: string; points: number; me: boolean }> = [];
  let myPoints = 0;
  if (userId) {
    const rows = await prisma.friendship.findMany({
      where: { status: "accepted", OR: [{ requesterId: userId }, { addresseeId: userId }] },
      include: { requester: { select: { id: true, username: true } }, addressee: { select: { id: true, username: true } } },
    });
    const others = rows.map((r) => (r.requesterId === userId ? r.addressee : r.requester));
    const pts = await pointsFor([userId, ...others.map((o) => o.id)]);
    myPoints = pts.get(userId) ?? 0;
    friends = [...others.map((o) => ({ name: o.username ?? "?", points: pts.get(o.id) ?? 0, me: false })), { name: user?.username ?? "You", points: myPoints, me: true }]
      .sort((a, b) => b.points - a.points)
      .slice(0, 4);
  }

  const name = user?.username ?? null;
  const balance = userId ? (await wallet(userId)).balance : 0;

  return (
    <div className="space-y-5">
      {name ? (
        <div className="flex flex-wrap items-center gap-3">
          <UserAvatar name={name} icon={user?.avatarIcon} size={44} />
          <h1 className="text-xl font-extrabold"><NameWithFlair name={name} flair={user?.flair} /></h1>
          <span className="ml-auto flex items-center gap-4 text-sm font-bold">
            <span className="flex items-center gap-1" title="Puzzle streak"><IconFlame size={22} /> <span className="text-xl">{user?.puzzleStreak ?? 0}</span><span className="text-muted">streak</span></span>
            <Link href="/shop" className="text-xl text-gold hover:underline" title="Spendable points — visit the shop">◆ {balance.toLocaleString()}</Link>
          </span>
        </div>
      ) : (
        <div className="flex flex-wrap items-center gap-4 rounded-xl bg-panel p-5 animate-fade-up">
          <div>
            <h1 className="text-2xl font-extrabold sm:text-3xl">Play chess. Get better.</h1>
            <p className="mt-1 text-muted">Bots from 400 to 3200, puzzles, and a full review of every game.</p>
          </div>
          <div className="ml-auto flex gap-2">
            <Link href="/register" className="btn-primary px-6 py-3 text-base">Sign Up</Link>
            <Link href="/login" className="btn px-6 py-3 text-base">Log In</Link>
          </div>
        </div>
      )}

      <div className="grid gap-5 lg:grid-cols-[320px_1fr]">
        <PlayPanel />

        <div className="grid content-start gap-5 sm:grid-cols-2 xl:grid-cols-3">
          <Card fen={puzzleFen} orientation={puzzleSide} delay={60} label="Puzzle position">
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-gold-soft text-lg font-extrabold text-gold" aria-hidden>?!</span>
              <div>
                <div className="text-lg font-extrabold tabular-nums">{puzzleRating}</div>
                <div className="text-xs font-bold text-muted">Puzzle rating</div>
              </div>
              <span className="ml-auto flex items-center gap-1 font-extrabold"><IconFlame /> {user?.puzzleStreak ?? 0}</span>
            </div>
            <Link href="/puzzles" className="btn mt-auto w-full py-3 text-base">Solve Puzzles</Link>
          </Card>

          <Card fen={lastFen} orientation={lastGame?.userColor === "b" ? "black" : "white"} delay={120} label="Your last game">
            {lastGame ? (
              <div className="flex items-center gap-2">
                <span className={`rounded-md px-2 py-1 text-xs font-extrabold ${lastGame.outcome === "win" ? "bg-ok/15 text-ok" : lastGame.outcome === "loss" ? "bg-bad/15 text-bad" : "bg-panel-2 text-muted"}`}>
                  {lastGame.outcome.toUpperCase()}
                </span>
                <span className="truncate text-sm font-bold">vs {botForElo(lastGame.botElo).name} {lastGame.botElo}</span>
              </div>
            ) : (
              <p className="text-sm font-bold text-muted">{name ? "Your games will show up here." : "Paste any game to get a full review."}</p>
            )}
            <Link href={lastGame ? `/review?game=${lastGame.id}` : "/review"} className="btn mt-auto w-full py-3 text-base">Review Game</Link>
          </Card>

          <article className="flex flex-col rounded-xl bg-panel p-4 animate-fade-up sm:col-span-2 xl:col-span-1" style={{ animationDelay: "180ms" }}>
            <h2 className="mb-3 font-extrabold">Friends</h2>
            {!name ? (
              <p className="text-sm text-muted">Sign up to add friends and compete on a points leaderboard.</p>
            ) : friends.length <= 1 ? (
              <p className="text-sm text-muted">Add friends by username and race them for points.</p>
            ) : (
              <ol className="space-y-1.5">
                {friends.map((f, i) => (
                  <li key={f.name + i} className={`flex items-center gap-2 rounded-lg px-2 py-1.5 text-sm ${f.me ? "bg-accent-soft" : ""}`}>
                    <span className="w-5 text-center font-extrabold text-muted">{i + 1}</span>
                    <span className="flex-1 truncate font-bold">{f.name}</span>
                    <span className="font-bold text-gold">◆ {f.points}</span>
                  </li>
                ))}
              </ol>
            )}
            <Link href={name ? "/friends" : "/register"} className="btn mt-auto w-full py-3 text-base">{name ? "See Friends" : "Create Account"}</Link>
          </article>
        </div>
      </div>
    </div>
  );
}
