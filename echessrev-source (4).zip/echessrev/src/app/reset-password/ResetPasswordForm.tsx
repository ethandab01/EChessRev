"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";
import { signIn } from "next-auth/react";

export function ResetPasswordForm() {
  const params = useSearchParams();
  const router = useRouter();
  const token = params.get("token") ?? "";
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (password !== confirm) return setError("The passwords don't match.");
    setBusy(true);
    const res = await fetch("/api/password/reset", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token, password }) });
    const j = await res.json().catch(() => ({}));
    if (!res.ok) {
      setBusy(false);
      return setError(j.error ?? "Something went wrong.");
    }
    if (j.username) {
      const r = await signIn("credentials", { email: j.username, password, redirect: false });
      if (r && !r.error) {
        router.push("/");
        router.refresh();
        return;
      }
    }
    router.push("/login");
  };

  if (!/^[a-f0-9]{64}$/.test(token)) {
    return (
      <div className="mx-auto mt-6 max-w-sm card space-y-3">
        <h1 className="text-2xl font-extrabold">Link not valid</h1>
        <p className="text-muted">This reset link is incomplete. Request a new one.</p>
        <Link href="/forgot-password" className="btn-primary w-full py-2.5">Request a new link</Link>
      </div>
    );
  }
  return (
    <div className="mx-auto mt-6 max-w-sm animate-fade-up">
      <form onSubmit={submit} className="card space-y-3">
        <h1 className="text-2xl font-extrabold">Choose a new password</h1>
        <div>
          <label htmlFor="pw" className="label">New password</label>
          <input id="pw" type="password" autoComplete="new-password" minLength={8} required value={password} onChange={(e) => setPassword(e.target.value)} className="input" />
        </div>
        <div>
          <label htmlFor="pw2" className="label">Confirm password</label>
          <input id="pw2" type="password" autoComplete="new-password" minLength={8} required value={confirm} onChange={(e) => setConfirm(e.target.value)} className="input" />
        </div>
        {error && <p role="alert" className="text-sm text-bad">{error}</p>}
        <button type="submit" className="btn-primary w-full py-2.5" disabled={busy}>{busy ? "Saving…" : "Save password & log in"}</button>
      </form>
    </div>
  );
}
