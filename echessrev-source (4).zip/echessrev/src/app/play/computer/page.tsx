import type { Metadata } from "next";
import { Suspense } from "react";
import { PlayClient } from "./PlayClient";

export const metadata: Metadata = { title: "Play vs computer" };

export default function PlayPage() {
  return (
    <Suspense fallback={<p className="text-muted">Loading…</p>}>
      <PlayClient />
    </Suspense>
  );
}
