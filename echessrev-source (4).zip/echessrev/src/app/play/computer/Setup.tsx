"use client";

import { ELO_MAX, ELO_MIN, ELO_STEP, TIME_CONTROLS, botForElo, clampElo, speedOf } from "@/lib/chess/bots";
import { resultPoints } from "@/lib/chess/points";
import { BotAvatar } from "@/components/BotAvatar";

export interface SetupState {
  elo: number;
  color: "w" | "b" | "random";
  timeControl: string;
  takebacks: boolean;
  startFen: string | null;
}

const PRESETS = [600, 1200, 1800, 2400, 3200];

export function Setup({ value, onChange, onStart, fenError, signedIn }: { value: SetupState; onChange: (v: SetupState) => void; onStart: () => void; fenError?: string; signedIn: boolean }) {
  const set = (patch: Partial<SetupState>) => onChange({ ...value, ...patch });
  const bot = botForElo(value.elo);
  const fill = ((value.elo - ELO_MIN) / (ELO_MAX - ELO_MIN)) * 100;

  return (
    <div>
      <div className="card overflow-hidden p-0">
        {/* Opponent */}
        <div className="relative px-5 pb-5 pt-6 text-center" style={{ background: `radial-gradient(30rem 12rem at 50% 0%, hsl(${bot.hue} 70% 55% / 0.18), transparent 70%)` }}>
          <div className="mx-auto w-fit animate-float">
            <BotAvatar bot={bot} size={72} className="shadow-xl transition-all duration-300" />
          </div>
          <div key={bot.name} className="mt-4 text-sm font-semibold uppercase tracking-widest text-muted animate-fade-in">{bot.name}</div>
          <div className="mt-1 font-mono text-5xl font-extrabold tabular-nums tracking-tight" aria-live="polite">
            {value.elo}
          </div>
          <p key={bot.personality} className="mx-auto mt-2 max-w-xs text-sm text-muted animate-fade-in">{bot.personality}</p>

          <div className="mt-6 flex items-center gap-3">
            <button type="button" className="btn h-9 w-9 shrink-0 rounded-full p-0" aria-label="Lower Elo" onClick={() => set({ elo: clampElo(value.elo - ELO_STEP) })}>−</button>
            <label htmlFor="elo" className="sr-only">Bot Elo rating</label>
            <input
              id="elo"
              type="range"
              min={ELO_MIN}
              max={ELO_MAX}
              step={ELO_STEP}
              value={value.elo}
              onChange={(e) => set({ elo: clampElo(Number(e.target.value)) })}
              className="elo-slider w-full"
              style={{ ["--fill" as string]: `${fill}%` }}
              aria-valuetext={`${value.elo} Elo, ${bot.name}`}
            />
            <button type="button" className="btn h-9 w-9 shrink-0 rounded-full p-0" aria-label="Raise Elo" onClick={() => set({ elo: clampElo(value.elo + ELO_STEP) })}>+</button>
          </div>
          <div className="mt-3 flex flex-wrap justify-center gap-1.5">
            {PRESETS.map((p) => (
              <button key={p} type="button" onClick={() => set({ elo: p })} className={`rounded-full px-3 py-1 text-xs font-semibold transition ${value.elo === p ? "bg-accent text-white" : "bg-panel-2 text-muted hover:text-fg"}`}>
                {p === 3200 ? "Max" : p}
              </button>
            ))}
          </div>
          {signedIn && (
            <p className="mt-3 text-xs text-muted">
              Win: <span className="font-bold text-gold">+{resultPoints("win", value.elo)} ◆</span> · Draw: +{resultPoints("draw", value.elo)} ◆
            </p>
          )}
        </div>

        {/* Options */}
        <div className="space-y-5 border-t border-line px-5 py-5">
          <fieldset>
            <legend className="label">Play as</legend>
            <div className="grid grid-cols-3 gap-2">
              {(["w", "random", "b"] as const).map((c) => (
                <label key={c} className={`chip py-3.5 text-base ${value.color === c ? "chip-on" : ""}`}>
                  <input type="radio" name="color" value={c} checked={value.color === c} onChange={() => set({ color: c })} className="sr-only" />
                  {c === "w" ? "♔ White" : c === "b" ? "♚ Black" : "⚄ Random"}
                </label>
              ))}
            </div>
          </fieldset>
          <fieldset>
            <legend className="label">Time</legend>
            <div className="grid grid-cols-4 gap-2">
              {TIME_CONTROLS.map((t) => (
                <label key={t.id} className={`chip flex flex-col items-center justify-center py-4 ${t.id === "unlimited" ? "col-span-4 flex-row gap-2 py-3" : ""} ${value.timeControl === t.id ? "chip-on" : ""}`}>
                  <input type="radio" name="tc" value={t.id} checked={value.timeControl === t.id} onChange={() => set({ timeControl: t.id, takebacks: t.id === "unlimited" })} className="sr-only" />
                  <span className="text-xl font-extrabold tabular-nums">{t.id === "unlimited" ? "∞" : t.label}</span>
                  <span className="text-[11px] font-bold opacity-70">{t.id === "unlimited" ? "No clock" : speedOf(t)}</span>
                </label>
              ))}
            </div>
          </fieldset>
          <label className="flex cursor-pointer items-center justify-between gap-3 text-sm">
            <span>Allow takebacks</span>
            <span className="relative inline-flex">
              <input type="checkbox" role="switch" className="peer sr-only" checked={value.takebacks} onChange={(e) => set({ takebacks: e.target.checked })} />
              <span className="h-6 w-11 rounded-full bg-panel-3 transition peer-checked:bg-accent peer-focus-visible:outline-2 peer-focus-visible:outline-accent" />
              <span className="absolute left-0.5 top-0.5 h-5 w-5 rounded-full bg-white shadow transition peer-checked:translate-x-5" />
            </span>
          </label>
          {value.startFen && (
            <div className="rounded-xl border border-line bg-panel-2 p-3 text-xs">
              <div className="label">Starting from a custom position</div>
              <code className="break-all text-muted">{value.startFen}</code>
              <button type="button" className="mt-2 block text-accent hover:underline" onClick={() => set({ startFen: null })}>Use the normal starting position</button>
            </div>
          )}
          {fenError && <p role="alert" className="text-sm text-bad">{fenError}</p>}
          <button type="button" className="btn-primary btn-xl w-full" onClick={onStart}>
            Play
          </button>
        </div>
      </div>
    </div>
  );
}
