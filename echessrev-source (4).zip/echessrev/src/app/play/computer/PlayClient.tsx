"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useSession } from "next-auth/react";
import { Chess, type Move } from "chess.js";
import { Board } from "@/components/Board";
import { BotAvatar } from "@/components/BotAvatar";
import { MoveList } from "@/components/MoveList";
import { EngineError } from "@/components/EngineError";
import { Setup, type SetupState } from "./Setup";
import { GameOverFx } from "@/components/GameOverFx";
import { useMe } from "@/lib/client/useMe";
import { UserAvatar, NameWithFlair } from "@/components/UserAvatar";
import { IconChevron } from "@/components/Icons";
import { botForElo, clampElo, getBot, getTimeControl, type Bot } from "@/lib/chess/bots";
import { notifyPointsChanged } from "@/lib/client/useMe";
import { botAcceptsDraw, botStrength, pickWeakMove, thinkDelayMs, timeBudgetMs } from "@/lib/chess/botMove";
import { describeResult, detectGameEnd, timeoutResult, type GameOver } from "@/lib/chess/gameEnd";
import { buildPgn, parseFen, START_FEN } from "@/lib/chess/pgn";
import type { Score } from "@/lib/chess/types";
import { useEngine } from "@/lib/client/useEngine";
import type { StockfishEngine } from "@/lib/engine/engine";
import { playSound, soundForSan, isMuted, setMuted } from "@/lib/client/sounds";
import { clearSavedGame, loadSavedGame, saveGameState, type SavedGameState } from "@/lib/client/savedGame";
import { setHandoff } from "@/lib/client/handoff";

interface GameState {
  id: string;
  startFen: string;
  moves: Move[];
  userColor: "w" | "b";
  bot: Bot;
  tcId: string;
  takebacks: boolean;
  over: GameOver | null;
}

const SETUP_KEY = "echessrev:setup";

function replay(startFen: string, moves: Array<Pick<Move, "from" | "to" | "promotion">>): Chess {
  const c = new Chess(startFen);
  for (const m of moves) c.move({ from: m.from, to: m.to, promotion: m.promotion });
  return c;
}

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

function formatClock(ms: number) {
  const t = Math.max(0, ms);
  const totalSec = t / 1000;
  const m = Math.floor(totalSec / 60);
  const s = Math.floor(totalSec % 60);
  if (totalSec < 10) return `${m}:${s.toString().padStart(2, "0")}.${Math.floor((t % 1000) / 100)}`;
  return `${m}:${s.toString().padStart(2, "0")}`;
}

/** Choose the bot's move for `fen` according to its rating. */
async function computeBotMove(engine: StockfishEngine, fen: string, bot: Bot, clockMs: number | null, incMs: number): Promise<{ uci: string; score?: Score }> {
  const strength = botStrength(bot.elo);
  const delay = thinkDelayMs(fen, { remainingMs: clockMs, incrementMs: incMs });
  const t0 = performance.now();
  const legal = new Chess(fen).moves({ verbose: true }).map((m) => `${m.from}${m.to}${m.promotion ?? ""}`);
  let uci: string | undefined;
  let score: Score | undefined;
  if (strength.mode === "weak") {
    const res = await engine.search(fen, {
      depth: strength.depth,
      multipv: Math.min(strength.multipv, legal.length),
      configure: (e) => {
        e.setOption("UCI_LimitStrength", false);
        e.setOption("Skill Level", 0);
      },
    });
    uci = pickWeakMove(res.lines, legal, strength).move;
    score = res.lines[0]?.score;
  } else {
    const movetime = clockMs == null ? Math.max(300, delay) : Math.max(50, Math.min(delay, timeBudgetMs(clockMs, incMs)));
    const res = await engine.search(fen, {
      movetime,
      multipv: 1,
      configure: (e) => {
        if (strength.mode === "full") e.setFullStrength();
        else {
          e.setOption("Skill Level", 20);
          e.setOption("UCI_LimitStrength", true);
          e.setOption("UCI_Elo", strength.elo);
        }
      },
    });
    uci = res.bestmove ?? res.lines[0]?.pv[0];
    score = res.lines[0]?.score;
  }
  if (!uci || !legal.includes(uci)) uci = legal[Math.floor(Math.random() * legal.length)];
  const spent = performance.now() - t0;
  if (spent < delay) await sleep(delay - spent);
  return { uci, score };
}

export function PlayClient() {
  const params = useSearchParams();
  const router = useRouter();
  const { status: authStatus, data: session } = useSession();
  const { engine, status: engineStatus, error: engineError, retry } = useEngine();
  const me = useMe();

  const [setup, setSetup] = useState<SetupState>({ elo: 1200, color: "w", timeControl: "unlimited", takebacks: true, startFen: null });
  const [fenError, setFenError] = useState("");
  const [game, setGame] = useState<GameState | null>(null);
  const [resumable, setResumable] = useState<SavedGameState | null>(null);
  const [orientation, setOrientation] = useState<"white" | "black">("white");
  const [thinking, setThinking] = useState(false);
  const [notice, setNotice] = useState("");
  const [confirmResign, setConfirmResign] = useState(false);
  const [savedId, setSavedId] = useState<string | null>(null);
  const [earned, setEarned] = useState<number | null>(null);
  const [saveError, setSaveError] = useState("");
  const [muted, setMutedState] = useState(false);
  const [, setTick] = useState(0);
  /** Ply being viewed with the arrow buttons; null = live position. */
  const [viewPly, setViewPly] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(true);

  const gameRef = useRef<GameState | null>(null);
  gameRef.current = game;
  const clocksRef = useRef<{ w: number; b: number } | null>(null);
  const turnStartRef = useRef(0);
  const botTokenRef = useRef("");
  const lastBotScoreRef = useRef<Score | null>(null);

  useEffect(() => setMutedState(isMuted()), []);

  // Initial setup: URL params (?bot=&fen=) override remembered choices; offer to resume a saved game.
  useEffect(() => {
    let base = setup;
    try {
      const saved = localStorage.getItem(SETUP_KEY);
      if (saved) base = { ...base, ...JSON.parse(saved), startFen: null };
    } catch {
      /* ignore */
    }
    const eloParam = params.get("elo");
    const legacy = getBot(params.get("bot"));
    if (eloParam) base = { ...base, elo: clampElo(Number(eloParam)) };
    else if (legacy) base = { ...base, elo: legacy.elo };
    base = { ...base, elo: clampElo(base.elo) };
    const tcParam = params.get("tc");
    if (tcParam && getTimeControl(tcParam).id === tcParam) base = { ...base, timeControl: tcParam, takebacks: tcParam === "unlimited" };
    const colorParam = params.get("color");
    if (colorParam === "w" || colorParam === "b" || colorParam === "random") base = { ...base, color: colorParam };
    const fen = params.get("fen");
    if (fen) {
      try {
        base = { ...base, startFen: parseFen(fen) };
      } catch (e) {
        setFenError((e as Error).message);
      }
    }
    setSetup(base);
    if (params.get("start") === "1") {
      clearSavedGame();
      window.history.replaceState(null, "", "/play/computer");
      startGame(undefined, base);
      return;
    }
    const s = loadSavedGame();
    if (s && getBot(s.botId)) setResumable(s);
  }, []);

  const chess = useMemo(() => (game ? replay(game.startFen, game.moves) : new Chess()), [game]);
  const tc = getTimeControl(game?.tcId ?? setup.timeControl);
  const timed = tc.id !== "unlimited";
  const botColor: "w" | "b" | null = game ? (game.userColor === "w" ? "b" : "w") : null;

  const currentClocks = useCallback((): { w: number; b: number } | null => {
    const c = clocksRef.current;
    const g = gameRef.current;
    if (!c || !g) return null;
    if (g.over) return { ...c };
    const stm = replay(g.startFen, g.moves).turn();
    const elapsed = performance.now() - turnStartRef.current;
    return { ...c, [stm]: c[stm] - elapsed };
  }, []);

  const finish = useCallback((over: GameOver) => {
    const g = gameRef.current;
    if (!g || g.over) return;
    const now = currentClocks();
    if (now && clocksRef.current) clocksRef.current = { w: Math.max(0, now.w), b: Math.max(0, now.b) };
    botTokenRef.current = "";
    setThinking(false);
    setConfirmResign(false);
    setViewPly(null);
    setGame({ ...g, over });
    playSound("end");
  }, [currentClocks]);

  const applyMove = useCallback(
    (from: string, to: string, promotion?: string): boolean => {
      const g = gameRef.current;
      if (!g || g.over) return false;
      const c = replay(g.startFen, g.moves);
      let m: Move;
      try {
        m = c.move({ from, to, promotion });
      } catch {
        playSound("illegal");
        return false;
      }
      if (clocksRef.current) {
        const elapsed = performance.now() - turnStartRef.current;
        const mover = m.color;
        const remaining = clocksRef.current[mover] - elapsed;
        if (remaining <= 0) {
          // Flag fell before the move landed.
          finish(timeoutResult(c, mover));
          return false;
        }
        clocksRef.current = { ...clocksRef.current, [mover]: remaining + getTimeControl(g.tcId).increment * 1000 };
      }
      turnStartRef.current = performance.now();
      playSound(soundForSan(m.san, m.captured));
      const over = detectGameEnd(c);
      const next: GameState = { ...g, moves: [...g.moves, m], over: null };
      gameRef.current = next;
      setGame(next);
      if (over) {
        setViewPly(null);
        if (over.termination !== "checkmate") playSound("end");
        setGame({ ...next, over });
        gameRef.current = { ...next, over };
      }
      return true;
    },
    [finish],
  );

  const startGame = (from?: SavedGameState, override?: SetupState) => {
    const setup_ = override ?? setup;
    const bot = (from ? getBot(from.botId) : undefined) ?? botForElo(setup_.elo);
    const tcId = from?.timeControl ?? setup_.timeControl;
    const t = getTimeControl(tcId);
    const userColor: "w" | "b" = from?.userColor ?? (setup_.color === "random" ? (Math.random() < 0.5 ? "w" : "b") : setup_.color);
    const startFen = from?.startFen ?? setup_.startFen ?? START_FEN;
    let moves: Move[] = [];
    if (from) {
      const c = new Chess(startFen);
      try {
        moves = from.moves.map((u) => c.move({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] }));
      } catch {
        clearSavedGame();
        setResumable(null);
        setNotice("The saved game could not be restored.");
        return;
      }
    } else {
      try {
        localStorage.setItem(SETUP_KEY, JSON.stringify({ elo: setup_.elo, color: setup_.color, timeControl: setup_.timeControl, takebacks: setup_.takebacks }));
      } catch {
        /* ignore */
      }
    }
    clocksRef.current = t.id === "unlimited" ? null : from?.clocks ?? { w: t.initial * 1000, b: t.initial * 1000 };
    turnStartRef.current = performance.now();
    lastBotScoreRef.current = null;
    botTokenRef.current = "";
    setSavedId(null);
    setEarned(null);
    setSaveError("");
    setNotice("");
    setResumable(null);
    setViewPly(null);
    setShowResult(true);
    setOrientation(userColor === "w" ? "white" : "black");
    const g: GameState = {
      id: Math.random().toString(36).slice(2),
      startFen,
      moves,
      userColor,
      bot,
      tcId,
      takebacks: from?.takebacks ?? setup_.takebacks,
      over: null,
    };
    gameRef.current = g;
    setGame(g);
    const c = replay(startFen, moves);
    const over = detectGameEnd(c);
    if (over) setGame({ ...g, over });
  };

  // Clock ticker + flag detection.
  useEffect(() => {
    if (!game || game.over || !clocksRef.current) return;
    const id = setInterval(() => {
      setTick((t) => t + 1);
      const now = currentClocks();
      const g = gameRef.current;
      if (!now || !g || g.over) return;
      const stm = replay(g.startFen, g.moves).turn();
      if (now[stm] <= 0) finish(timeoutResult(replay(g.startFen, g.moves), stm));
    }, 100);
    return () => clearInterval(id);
  }, [game, currentClocks, finish]);

  // Bot's turn.
  useEffect(() => {
    if (!game || game.over || !engine || botColor === null) return;
    if (chess.turn() !== botColor) return;
    const token = `${game.id}:${game.moves.length}`;
    if (botTokenRef.current === token) return;
    botTokenRef.current = token;
    setThinking(true);
    const fen = chess.fen();
    const clockMs = clocksRef.current ? currentClocks()?.[botColor] ?? null : null;
    computeBotMove(engine, fen, game.bot, clockMs, getTimeControl(game.tcId).increment * 1000)
      .then(({ uci, score }) => {
        if (botTokenRef.current !== token) return;
        lastBotScoreRef.current = score ?? null;
        setThinking(false);
        applyMove(uci.slice(0, 2), uci.slice(2, 4), uci[4]);
      })
      .catch(() => {
        if (botTokenRef.current === token) {
          setThinking(false);
          botTokenRef.current = "";
        }
      });
  }, [game, engine, chess, botColor, applyMove, currentClocks]);

  // Persist in-progress games; clear when finished.
  useEffect(() => {
    if (!game) return;
    if (game.over) {
      clearSavedGame();
      return;
    }
    saveGameState({
      version: 1,
      startFen: game.startFen,
      moves: game.moves.map((m) => `${m.from}${m.to}${m.promotion ?? ""}`),
      userColor: game.userColor,
      botId: game.bot.id,
      timeControl: game.tcId,
      clocks: currentClocks(),
      takebacks: game.takebacks,
      savedAt: Date.now(),
    });
  }, [game, currentClocks]);

  // Save clocks when the tab is hidden/closed so a resumed timed game keeps its time.
  useEffect(() => {
    const onHide = () => {
      const g = gameRef.current;
      if (!g || g.over) return;
      saveGameState({
        version: 1,
        startFen: g.startFen,
        moves: g.moves.map((m) => `${m.from}${m.to}${m.promotion ?? ""}`),
        userColor: g.userColor,
        botId: g.bot.id,
        timeControl: g.tcId,
        clocks: currentClocks(),
        takebacks: g.takebacks,
        savedAt: Date.now(),
      });
    };
    window.addEventListener("pagehide", onHide);
    return () => window.removeEventListener("pagehide", onHide);
  }, [currentClocks]);

  const userName = session?.user?.username ?? session?.user?.name ?? "You";
  const pgn = useMemo(() => {
    if (!game) return "";
    const botLabel = `${game.bot.name} (bot ${game.bot.elo})`;
    return buildPgn({
      moves: game.moves,
      startFen: game.startFen,
      result: game.over?.result ?? "*",
      headers: {
        Event: `EChessREV vs ${game.bot.name}`,
        White: game.userColor === "w" ? userName : botLabel,
        Black: game.userColor === "b" ? userName : botLabel,
        TimeControl: game.tcId === "unlimited" ? "-" : `${getTimeControl(game.tcId).initial}+${getTimeControl(game.tcId).increment}`,
        ...(game.over ? { Termination: game.over.termination } : {}),
      },
    });
  }, [game, userName]);

  // Auto-save finished games for signed-in users.
  const savedForRef = useRef<string>("");
  useEffect(() => {
    if (!game?.over || authStatus !== "authenticated" || savedForRef.current === game.id) return;
    if (game.moves.length === 0) return;
    savedForRef.current = game.id;
    fetch("/api/games", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        pgn,
        result: game.over.result,
        termination: game.over.termination,
        userColor: game.userColor,
        botId: game.bot.id,
        timeControl: game.tcId,
      }),
    })
      .then(async (r) => {
        const j = await r.json();
        if (!r.ok) throw new Error(j.error ?? "Save failed");
        setSavedId(j.id);
        setEarned(j.points ?? 0);
        notifyPointsChanged();
      })
      .catch((e: Error) => setSaveError(`Could not save this game: ${e.message}`));
  }, [game, authStatus, pgn]);

  const offerDraw = async () => {
    const g = gameRef.current;
    if (!g || g.over) return;
    const c = replay(g.startFen, g.moves);
    if (c.moveNumber() <= 30) {
      setNotice(`${g.bot.name} declines: it's too early for a draw (move 30 hasn't passed).`);
      return;
    }
    let score = lastBotScoreRef.current;
    if (engine) {
      try {
        const res = await engine.search(c.fen(), { depth: 12, multipv: 1, configure: (e) => e.setFullStrength() });
        score = res.lines[0]?.score ?? score;
      } catch {
        /* fall back to the last known eval */
      }
    }
    if (gameRef.current?.id !== g.id || gameRef.current.over) return;
    if (botAcceptsDraw(score?.cp ?? null, score?.mate, c.moveNumber())) {
      setNotice(`${g.bot.name} accepts the draw.`);
      finish({ result: "1/2-1/2", termination: "agreement" });
    } else setNotice(`${g.bot.name} declines the draw.`);
  };

  const takeback = () => {
    const g = gameRef.current;
    if (!g || g.over || !g.takebacks) return;
    const c = replay(g.startFen, g.moves);
    // If the bot is thinking, undo only the user's move; otherwise undo the bot's reply and the user's move.
    const undo = c.turn() === g.userColor ? 2 : 1;
    if (g.moves.length < undo) return;
    const remaining = g.moves.slice(0, g.moves.length - undo);
    // Don't undo past the bot's first move when the user plays Black.
    if (remaining.length === 0 && new Chess(g.startFen).turn() !== g.userColor) return;
    botTokenRef.current = "";
    engine?.stop();
    setThinking(false);
    turnStartRef.current = performance.now();
    const next = { ...g, moves: remaining };
    gameRef.current = next;
    setGame(next);
    setViewPly(null);
    setNotice("Move taken back.");
  };

  const analyze = () => {
    if (!game) return;
    setHandoff({ pgn, gameId: savedId ?? undefined, title: `${userName} vs ${game.bot.name}` });
    router.push(savedId ? `/review?game=${savedId}` : "/review?source=handoff");
  };

  const analyzeOnBoard = () => {
    if (!game) return;
    setHandoff({ pgn });
    router.push("/analysis?source=handoff");
  };

  // Move navigation (arrows / keyboard) — view earlier positions without changing the game.
  const liveFens = useMemo(() => {
    if (!game) return [] as string[];
    const c = new Chess(game.startFen);
    return [game.startFen, ...game.moves.map((m) => (c.move({ from: m.from, to: m.to, promotion: m.promotion }), c.fen()))];
  }, [game]);
  const plyCount = game?.moves.length ?? 0;
  const shownPly = viewPly ?? plyCount;
  const navTo = useCallback(
    (p: number) => {
      const t = Math.max(0, Math.min(plyCount, p));
      setViewPly(t >= plyCount ? null : t);
      if (game && t > 0 && t !== shownPly) playSound(soundForSan(game.moves[t - 1].san, game.moves[t - 1].captured));
    },
    [plyCount, shownPly, game],
  );
  useEffect(() => {
    if (!game) return;
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT")) return;
      if (e.key === "ArrowLeft") navTo(shownPly - 1);
      else if (e.key === "ArrowRight") navTo(shownPly + 1);
      else if (e.key === "Home") navTo(0);
      else if (e.key === "End") navTo(plyCount);
      else return;
      e.preventDefault();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [game, navTo, shownPly, plyCount]);

  // ── Render ────────────────────────────────────────────────────────────────
  const previewBot = botForElo(setup.elo);
  const setupColorOrientation: "white" | "black" = setup.color === "b" ? "black" : "white";

  if (!game) {
    return (
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-[minmax(0,1fr)_380px]">
        <div className="mx-auto w-full max-w-[min(100%,calc(100vh-8rem))]">
          <div className="flex items-center gap-3 py-2">
            <BotAvatar bot={previewBot} size={36} />
            <span className="text-sm font-bold">{previewBot.name} <span className="text-muted">({previewBot.elo})</span></span>
          </div>
          <Board fen={setup.startFen ?? START_FEN} orientation={setupColorOrientation} movable={null} typedMoves={false} id="preview-board" />
          <div className="flex items-center gap-3 py-2">
            <UserAvatar name={userName} icon={me?.avatarIcon} size={36} />
            <span className="text-sm font-bold"><NameWithFlair name={userName} flair={me?.flair} /></span>
          </div>
        </div>
        <div className="space-y-3">
          {resumable && (
            <div className="card flex flex-wrap items-center gap-3 p-4 animate-pop">
              <BotAvatar bot={getBot(resumable.botId)!} size={36} />
              <span className="flex-1 text-sm font-bold">Unfinished game vs {getBot(resumable.botId)!.name}</span>
              <button type="button" className="btn-primary" onClick={() => startGame(resumable)}>Resume</button>
              <button type="button" className="btn" onClick={() => { clearSavedGame(); setResumable(null); }}>Discard</button>
            </div>
          )}
          {notice && <p className="text-sm text-muted" role="status">{notice}</p>}
          <Setup value={setup} onChange={setSetup} onStart={() => startGame()} fenError={fenError} signedIn={authStatus === "authenticated"} />
        </div>
      </div>
    );
  }

  const clocks = currentClocks();
  const topColor: "w" | "b" = orientation === "white" ? "b" : "w";
  const bottomColor: "w" | "b" = topColor === "w" ? "b" : "w";
  const viewing = viewPly !== null;
  const shownMove = shownPly > 0 ? game.moves[shownPly - 1] : null;
  const resultInfo = game.over ? describeResult(game.over, game.userColor) : null;

  const playerRow = (color: "w" | "b") => {
    const isBot = color === botColor;
    const active = !game.over && chess.turn() === color;
    const ms = clocks?.[color] ?? null;
    return (
      <div className="flex items-center gap-3 py-2">
        {isBot ? <BotAvatar bot={game.bot} size={38} /> : (
          <UserAvatar name={userName} icon={me?.avatarIcon} size={38} />
        )}
        <div className="min-w-0">
          <div className="truncate text-sm font-bold">
            {isBot ? game.bot.name : <NameWithFlair name={userName} flair={me?.flair} />} {isBot && <span className="font-normal text-muted">({game.bot.elo})</span>}
          </div>
          {isBot && thinking ? (
            <div className="flex h-4 items-center gap-1" aria-live="polite">
              <span className="sr-only">thinking</span>
              {[0, 1, 2].map((i) => (
                <span key={i} aria-hidden className="h-1.5 w-1.5 animate-bounce rounded-full bg-accent" style={{ animationDelay: `${i * 0.15}s` }} />
              ))}
            </div>
          ) : (
            <div className="h-4 text-xs text-muted">{color === "w" ? "White" : "Black"}</div>
          )}
        </div>
        {ms !== null && (
          <div
            className={`ml-auto min-w-[96px] rounded-md px-3 py-1.5 text-right font-mono text-2xl font-bold tabular-nums transition ${active ? (ms < 10000 ? "bg-bad text-white animate-pulse" : "bg-fg text-bg") : "bg-panel-2 text-muted"}`}
            role="timer"
            aria-label={`${color === "w" ? "White" : "Black"} clock`}
          >
            {formatClock(ms)}
          </div>
        )}
      </div>
    );
  };

  const navBtn = (label: string, onClick: () => void, disabled: boolean, child: React.ReactNode) => (
    <button type="button" className="btn h-11 flex-1 p-0" onClick={onClick} disabled={disabled} aria-label={label} title={label}>
      {child}
    </button>
  );

  return (
    <div className="grid grid-cols-1 gap-5 lg:grid-cols-[minmax(0,1fr)_380px]">
      <div className="mx-auto w-full max-w-[min(100%,calc(100vh-10rem))]">
        {playerRow(topColor)}
        <div className={`relative ${viewing ? "opacity-95" : ""}`}>
          <Board
            fen={viewing ? liveFens[shownPly] : chess.fen()}
            orientation={orientation}
            movable={game.over || viewing ? null : game.userColor}
            onMove={(f, t, p) => (chess.turn() === game.userColor ? applyMove(f, t, p) : false)}
            lastMove={shownMove ? { from: shownMove.from, to: shownMove.to } : null}
            id="play-board"
          />
          {resultInfo && <GameOverFx key={game.id} effect={me?.winEffect} outcome={resultInfo.outcome} kingColor={resultInfo.outcome === "loss" ? game.userColor : botColor ?? "b"} />}
          {resultInfo && showResult && (
            <div className="absolute inset-0 z-30 flex items-center justify-center p-4">
              <div className="w-full max-w-[300px] overflow-hidden rounded-xl bg-panel text-center shadow-2xl animate-pop" style={{ animationDelay: "0.35s" }} role="dialog" aria-label="Game over">
                <div className={`relative px-4 py-4 ${resultInfo.outcome === "win" ? "bg-accent" : resultInfo.outcome === "loss" ? "bg-panel-3" : "bg-panel-2"}`}>
                  <button type="button" onClick={() => setShowResult(false)} className="absolute right-2 top-2 rounded p-1 text-white/80 hover:text-white" aria-label="Close and view board">✕</button>
                  <div className={`text-2xl font-extrabold ${resultInfo.outcome === "win" ? "text-white" : ""}`}>
                    {resultInfo.outcome === "win" ? "You Won!" : resultInfo.outcome === "loss" ? "You Lost" : "Draw"}
                  </div>
                  <div className={`text-sm ${resultInfo.outcome === "win" ? "text-white/85" : "text-muted"}`}>{resultInfo.headline.replace(/^(You won|You lost|Draw) ?/, "")}</div>
                </div>
                <div className="space-y-3 p-4">
                  <div className="flex items-center justify-center gap-4">
                    <UserAvatar name={userName} icon={me?.avatarIcon} size={48} />
                    <span className="font-mono text-lg font-extrabold">{game.over!.result.replace("1/2-1/2", "½-½")}</span>
                    <BotAvatar bot={game.bot} size={48} />
                  </div>
                  {authStatus === "authenticated" && earned !== null && earned > 0 && (
                    <div className="mx-auto w-fit rounded-full bg-gold-soft px-4 py-1 text-lg font-extrabold text-gold animate-pop" style={{ animationDelay: "0.7s" }}>+{earned} ◆</div>
                  )}
                  {saveError && <p className="text-xs text-bad">{saveError}</p>}
                  {game.moves.length > 0 && <button type="button" className="btn-primary w-full py-3 text-base" onClick={analyze}>Game Review</button>}
                  <div className="grid grid-cols-2 gap-2">
                    <button type="button" className="btn py-2.5" onClick={() => setGame(null)}>New Bot</button>
                    <button type="button" className="btn py-2.5" onClick={() => startGame()}>Rematch</button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
        {playerRow(bottomColor)}
      </div>

      <aside className="flex flex-col gap-3">
        {engineStatus === "error" && <EngineError message={engineError} onRetry={retry} />}
        {engineStatus === "loading" && <div className="skeleton h-10" role="status" aria-label="Loading engine" />}
        <section className="card flex min-h-[300px] flex-col p-0 lg:min-h-[420px]">
          <div className="flex items-center gap-2 border-b border-line px-4 py-3">
            <BotAvatar bot={game.bot} size={28} />
            <span className="text-sm font-extrabold">vs {game.bot.name} {game.bot.elo}</span>
            <span className="ml-auto text-xs font-bold text-muted">{timed ? tc.label : "∞"}</span>
          </div>
          <MoveList moves={game.moves.map((m) => ({ san: m.san }))} current={shownPly} onSelect={navTo} startFen={game.startFen} className="max-h-[42vh] flex-1 px-2 py-2" />
          {viewing && (
            <button type="button" onClick={() => setViewPly(null)} className="mx-3 mb-2 rounded-lg bg-gold-soft px-3 py-1.5 text-xs font-bold text-gold animate-fade-in">
              Viewing move {shownPly} of {plyCount} — back to live ⏭
            </button>
          )}
          <div className="flex gap-1.5 border-t border-line p-3" role="toolbar" aria-label="Move navigation">
            {navBtn("First move (Home)", () => navTo(0), shownPly === 0, <span className="flex"><IconChevron dir="left" /><IconChevron dir="left" className="-ml-3" /></span>)}
            {navBtn("Previous move (←)", () => navTo(shownPly - 1), shownPly === 0, <IconChevron dir="left" size={24} />)}
            {navBtn("Next move (→)", () => navTo(shownPly + 1), !viewing, <IconChevron size={24} />)}
            {navBtn("Latest move (End)", () => navTo(plyCount), !viewing, <span className="flex"><IconChevron /><IconChevron className="-ml-3" /></span>)}
          </div>
        </section>
        {notice && <p className="rounded-lg bg-panel px-3 py-2 text-sm text-muted animate-fade-in" role="status" aria-live="polite">{notice}</p>}
        {!game.over ? (
          <div className="grid grid-cols-2 gap-2">
            {game.takebacks && <button type="button" className="btn py-2.5" onClick={takeback} disabled={game.moves.length === 0}>↶ Takeback</button>}
            <button type="button" className="btn py-2.5" onClick={offerDraw}>½ Draw</button>
            {confirmResign ? (
              <>
                <button type="button" className="btn bg-bad py-2.5 text-white hover:bg-bad" onClick={() => finish({ result: game.userColor === "w" ? "0-1" : "1-0", termination: "resignation" })}>Confirm resign</button>
                <button type="button" className="btn py-2.5" onClick={() => setConfirmResign(false)}>Cancel</button>
              </>
            ) : (
              <button type="button" className="btn py-2.5" onClick={() => setConfirmResign(true)}>⚑ Resign</button>
            )}
            <button type="button" className="btn py-2.5" onClick={() => setOrientation((o) => (o === "white" ? "black" : "white"))} aria-label="Flip board">⇅ Flip</button>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2">
            {game.moves.length > 0 && <button type="button" className="btn-primary col-span-2 py-3 text-base" onClick={analyze}>Game Review</button>}
            <button type="button" className="btn py-2.5" onClick={() => startGame()}>Rematch</button>
            <button type="button" className="btn py-2.5" onClick={() => setGame(null)}>New Bot</button>
            <button type="button" className="btn py-2.5" onClick={analyzeOnBoard}>Analysis</button>
            <button type="button" className="btn py-2.5" onClick={() => setOrientation((o) => (o === "white" ? "black" : "white"))}>⇅ Flip</button>
          </div>
        )}
        <button type="button" className="self-start text-xs font-bold text-muted hover:text-fg" aria-pressed={muted} onClick={() => { setMuted(!muted); setMutedState(!muted); }}>
          {muted ? "🔇 Sound off" : "🔊 Sound on"}
        </button>
      </aside>
    </div>
  );
}
