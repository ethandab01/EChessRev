"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useSession } from "next-auth/react";
import { useCallback, useEffect, useRef, useState } from "react";
import { ONLINE_TIME_CONTROLS, getTimeControl, isValidTimeControl, speedOf } from "@/lib/chess/bots";
import { useOnlineCounts } from "@/lib/client/usePresence";
import { IconFriends, IconPlay } from "@/components/Icons";
import { RankBadge } from "@/components/RankBadge";

interface SeekRow {
  id: string;
  username: string | null;
  rating: number;
  timeControl: string;
  speed: string;
  rated: boolean;
  mine: boolean;
}
interface ActiveGame {
  id: string;
  opponent: { username: string | null };
  yourTurn: boolean;
  timeControl: string;
}

const SPEED_ICON: Record<string, string> = { Bullet: "🚀", Blitz: "🔥", Rapid: "🐇", Classical: "🐢", Unlimited: "∞" };

export function PlayHub() {
  const router = useRouter();
  const params = useSearchParams();
  const { status } = useSession();
  const signedIn = status === "authenticated";
  const counts = useOnlineCounts();
  const [tab, setTab] = useState<"quick" | "lobby">("quick");
  const [rated, setRated] = useState(true);
  const [seeking, setSeeking] = useState<{ seekId: string; tc: string; since: number; lobby: boolean } | null>(null);
  const [lobby, setLobby] = useState<SeekRow[]>([]);
  const [active, setActive] = useState<ActiveGame[]>([]);
  const [error, setError] = useState("");
  const [custom, setCustom] = useState<{ open: boolean; minutes: number; inc: number; lobby: boolean }>({ open: false, minutes: 5, inc: 3, lobby: false });
  const [, tick] = useState(0);
  const started = useRef(false);

  const go = useCallback((gameId: string) => router.push(`/game/${gameId}`), [router]);

  const seek = useCallback(
    async (tc: string, opts: { quick?: boolean } = {}) => {
      setError("");
      if (!signedIn) {
        router.push(`/login?callbackUrl=${encodeURIComponent(`/play?quick=${tc}`)}`);
        return;
      }
      const res = await fetch("/api/seeks", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ timeControl: tc, rated, quick: opts.quick ?? true }) });
      const j = await res.json().catch(() => ({}));
      if (!res.ok) return setError(j.error ?? "Couldn't start searching.");
      if (j.gameId) return go(j.gameId);
      setSeeking({ seekId: j.seekId, tc, since: Date.now(), lobby: opts.quick === false });
    },
    [signedIn, rated, router, go],
  );

  const cancel = useCallback(async () => {
    if (!seeking) return;
    const res = await fetch(`/api/seeks/${seeking.seekId}`, { method: "DELETE" });
    const j = await res.json().catch(() => ({}));
    if (j.gameId) return go(j.gameId);
    setSeeking(null);
  }, [seeking, go]);

  // ?quick=5+3 (from the home page) starts searching right away.
  useEffect(() => {
    const q = params.get("quick");
    if (!q || started.current || status === "loading") return;
    started.current = true;
    window.history.replaceState(null, "", "/play");
    if (isValidTimeControl(q) && q !== "unlimited") seek(q);
  }, [params, status, seek]);

  // While seeking: keep the seek alive and watch for a match.
  useEffect(() => {
    if (!seeking) return;
    const t = setInterval(async () => {
      tick((x) => x + 1);
      const res = await fetch(`/api/seeks/${seeking.seekId}`, { cache: "no-store" });
      const j = await res.json().catch(() => ({}));
      if (j.gameId) go(j.gameId);
      else if (res.status === 404) setSeeking(null);
    }, 1200);
    return () => clearInterval(t);
  }, [seeking, go]);

  // Lobby list + your ongoing games.
  useEffect(() => {
    const load = async () => {
      const r = await fetch("/api/seeks", { cache: "no-store" });
      if (r.ok) setLobby((await r.json()).seeks);
      if (signedIn) {
        const g = await fetch("/api/friend-games", { cache: "no-store" });
        if (g.ok) setActive((await g.json()).active);
      }
    };
    load();
    const t = setInterval(load, 3000);
    return () => clearInterval(t);
  }, [signedIn]);

  const join = async (id: string) => {
    if (!signedIn) return router.push("/login?callbackUrl=/play");
    const res = await fetch(`/api/seeks/${id}/join`, { method: "POST" });
    const j = await res.json().catch(() => ({}));
    if (j.gameId) go(j.gameId);
    else setError(j.error ?? "Couldn't join that game.");
  };

  const elapsed = seeking ? Math.floor((Date.now() - seeking.since) / 1000) : 0;
  const customTc = `${custom.minutes}+${custom.inc}`;

  return (
    <div className="grid grid-cols-1 gap-5 lg:grid-cols-[minmax(0,1fr)_320px]">
      <div className="min-w-0">
        <div className="mb-3 flex flex-wrap items-center gap-3">
          <h1 className="text-2xl font-extrabold">Play Online</h1>
          {counts && (
            <span className="flex items-center gap-2 rounded-full bg-panel px-3 py-1 text-sm font-bold">
              <span className="relative flex h-2.5 w-2.5"><span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-accent opacity-60" /><span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-accent" /></span>
              {counts.players.toLocaleString()} players online · {counts.games.toLocaleString()} games in play
            </span>
          )}
        </div>

        <div className="mb-3 flex items-center gap-1 border-b border-line" role="tablist" aria-label="Play online">
          {(["quick", "lobby"] as const).map((t) => (
            <button key={t} type="button" role="tab" aria-selected={tab === t} onClick={() => setTab(t)} className={`relative px-5 py-3 text-sm font-extrabold transition ${tab === t ? "text-accent" : "text-muted hover:text-fg"}`}>
              {t === "quick" ? "Quick pairing" : `Lobby${lobby.filter((s) => !s.mine).length ? ` (${lobby.filter((s) => !s.mine).length})` : ""}`}
              {tab === t && <span className="absolute inset-x-2 -bottom-px h-0.5 rounded-full bg-accent animate-fade-in" />}
            </button>
          ))}
          <div className="ml-auto flex rounded-lg bg-panel p-1 text-xs font-extrabold" role="radiogroup" aria-label="Rated or casual">
            {[true, false].map((r) => (
              <button key={String(r)} type="button" role="radio" aria-checked={rated === r} onClick={() => setRated(r)} className={`rounded-md px-3 py-1.5 transition ${rated === r ? "bg-panel-3 text-fg" : "text-muted"}`}>
                {r ? "Rated" : "Casual"}
              </button>
            ))}
          </div>
        </div>

        {error && <p role="alert" className="mb-3 rounded-lg bg-bad/15 px-3 py-2 text-sm font-bold text-bad">{error}</p>}

        <div className="relative">
          {tab === "quick" ? (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              {ONLINE_TIME_CONTROLS.map((tc, i) => (
                <button
                  key={tc}
                  type="button"
                  onClick={() => seek(tc)}
                  disabled={!!seeking}
                  className="group flex aspect-[5/3] flex-col items-center justify-center rounded-xl bg-panel transition duration-150 hover:-translate-y-0.5 hover:bg-panel-2 hover:shadow-lg active:translate-y-0 animate-fade-up disabled:opacity-50"
                  style={{ animationDelay: `${i * 25}ms`, boxShadow: "inset 0 -4px 0 rgba(0,0,0,0.2)" }}
                  aria-label={`${tc} ${speedOf(getTimeControl(tc))}`}
                >
                  <span className="text-3xl font-light tabular-nums sm:text-4xl">{tc}</span>
                  <span className="mt-1 text-base text-muted sm:text-lg">{speedOf(getTimeControl(tc))}</span>
                </button>
              ))}
              <button
                type="button"
                onClick={() => setCustom({ ...custom, open: true, lobby: false })}
                disabled={!!seeking}
                className="flex aspect-[5/3] flex-col items-center justify-center rounded-xl bg-panel text-2xl text-muted transition hover:-translate-y-0.5 hover:bg-panel-2 hover:text-fg animate-fade-up disabled:opacity-50"
                style={{ animationDelay: "280ms", boxShadow: "inset 0 -4px 0 rgba(0,0,0,0.2)" }}
              >
                Custom
              </button>
            </div>
          ) : (
            <div className="overflow-hidden rounded-xl bg-panel">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-xs uppercase tracking-wider text-muted">
                    <th scope="col" className="px-4 py-3 font-bold">Player</th>
                    <th scope="col" className="px-2 py-3 font-bold">Rating</th>
                    <th scope="col" className="px-2 py-3 font-bold">Time</th>
                    <th scope="col" className="px-4 py-3 font-bold">Mode</th>
                  </tr>
                </thead>
                <tbody>
                  {lobby.length === 0 && (
                    <tr>
                      <td colSpan={4} className="px-4 py-10 text-center text-muted">
                        No open games right now. Create one and wait for an opponent, or use Quick pairing.
                      </td>
                    </tr>
                  )}
                  {lobby.map((s) => (
                    <tr
                      key={s.id}
                      onClick={() => !s.mine && join(s.id)}
                      onKeyDown={(e) => e.key === "Enter" && !s.mine && join(s.id)}
                      tabIndex={s.mine ? -1 : 0}
                      className={`border-t border-line transition animate-fade-in ${s.mine ? "bg-accent-soft" : "cursor-pointer hover:bg-accent hover:text-white"}`}
                      aria-label={s.mine ? "Your open game" : `Play ${s.username}, ${s.timeControl}`}
                    >
                      <td className="px-4 py-3 font-bold">{s.username}{s.mine && <span className="ml-2 text-xs text-muted">(you)</span>}</td>
                      <td className="px-2 py-3 tabular-nums"><span className="mr-2">{s.rating}</span><RankBadge rating={s.rating} /></td>
                      <td className="px-2 py-3 font-mono">{s.timeControl}</td>
                      <td className="px-4 py-3"><span aria-hidden className="mr-1.5">{SPEED_ICON[s.speed]}</span>{s.rated ? "Rated" : "Casual"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {seeking && (
            <div className="absolute inset-0 z-10 flex items-center justify-center rounded-xl bg-bg/80 backdrop-blur-sm animate-fade-in" role="status" aria-live="polite">
              <div className="card w-full max-w-sm space-y-4 text-center shadow-2xl animate-pop">
                <div className="relative mx-auto h-16 w-16">
                  <span className="absolute inset-0 animate-ping rounded-full bg-accent/30" />
                  <span className="absolute inset-2 animate-spin rounded-full border-4 border-panel-3 border-t-accent" />
                </div>
                <div>
                  <div className="text-xl font-extrabold">{seeking.lobby ? "Waiting in the lobby…" : "Finding an opponent…"}</div>
                  <div className="mt-1 font-mono text-muted">{seeking.tc} · {speedOf(getTimeControl(seeking.tc))} · {rated ? "Rated" : "Casual"}</div>
                  <div className="mt-1 text-sm tabular-nums text-muted">{Math.floor(elapsed / 60)}:{String(elapsed % 60).padStart(2, "0")}</div>
                </div>
                <button type="button" className="btn w-full py-2.5" onClick={cancel}>Cancel</button>
              </div>
            </div>
          )}
        </div>
      </div>

      <aside className="space-y-3 lg:pt-[92px]">
        <button type="button" className="btn w-full justify-start gap-3 py-4 text-base" onClick={() => setCustom({ ...custom, open: true, lobby: true })} disabled={!!seeking}>
          <span aria-hidden className="text-xl">＋</span> Create lobby game
        </button>
        <Link href="/friends" className="btn w-full justify-start gap-3 py-4 text-base">
          <IconFriends className="text-accent" /> Challenge a friend
        </Link>
        <Link href="/play/computer" className="btn w-full justify-start gap-3 py-4 text-base">
          <IconPlay className="text-accent" /> Play against computer
        </Link>

        {active.length > 0 && (
          <section className="card space-y-2 p-4">
            <h2 className="label">Your ongoing games</h2>
            {active.map((g) => (
              <Link key={g.id} href={`/game/${g.id}`} className={`flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-bold ${g.yourTurn ? "bg-accent-soft text-accent" : "bg-panel-2"}`}>
                <span className="flex-1 truncate">vs {g.opponent.username}</span>
                <span className="text-xs">{g.yourTurn ? "Your move" : g.timeControl}</span>
              </Link>
            ))}
          </section>
        )}

        {!signedIn && status !== "loading" && (
          <div className="card space-y-2 p-4 text-sm">
            <p className="font-bold">Sign in to play real people.</p>
            <p className="text-muted">Online games are rated and count toward your rank. You can always play the computer as a guest.</p>
            <div className="grid grid-cols-2 gap-2 pt-1">
              <Link href="/register" className="btn-primary py-2">Sign Up</Link>
              <Link href="/login?callbackUrl=/play" className="btn py-2">Log In</Link>
            </div>
          </div>
        )}
        {counts && (
          <p className="px-1 text-sm text-muted">
            <strong className="text-fg">{counts.players.toLocaleString()}</strong> players<br />
            <strong className="text-fg">{counts.games.toLocaleString()}</strong> games in play
          </p>
        )}
      </aside>

      {custom.open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 animate-fade-in" role="dialog" aria-modal="true" aria-label="Custom game" onClick={() => setCustom({ ...custom, open: false })}>
          <div className="card w-full max-w-md space-y-5 shadow-2xl animate-pop" onClick={(e) => e.stopPropagation()}>
            <h2 className="text-xl font-extrabold">{custom.lobby ? "Create a lobby game" : "Custom game"}</h2>
            <div>
              <label htmlFor="cmin" className="label">Minutes per side: {custom.minutes}</label>
              <input id="cmin" type="range" min={1} max={60} value={custom.minutes} onChange={(e) => setCustom({ ...custom, minutes: Number(e.target.value) })} className="elo-slider w-full" style={{ ["--fill" as string]: `${((custom.minutes - 1) / 59) * 100}%` }} />
            </div>
            <div>
              <label htmlFor="cinc" className="label">Increment in seconds: {custom.inc}</label>
              <input id="cinc" type="range" min={0} max={30} value={custom.inc} onChange={(e) => setCustom({ ...custom, inc: Number(e.target.value) })} className="elo-slider w-full" style={{ ["--fill" as string]: `${(custom.inc / 30) * 100}%` }} />
            </div>
            <div className="rounded-lg bg-panel-2 p-3 text-center">
              <span className="font-mono text-3xl font-light">{customTc}</span> <span className="text-muted">{speedOf(getTimeControl(customTc))} · {rated ? "Rated" : "Casual"}</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button type="button" className="btn py-3" onClick={() => setCustom({ ...custom, open: false })}>Cancel</button>
              <button
                type="button"
                className="btn-primary py-3"
                onClick={() => {
                  setCustom({ ...custom, open: false });
                  seek(customTc, { quick: !custom.lobby });
                }}
              >
                {custom.lobby ? "Create game" : "Find opponent"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
