import type { Metadata } from "next";
import { Suspense } from "react";
import { PlayHub } from "./PlayHub";

export const metadata: Metadata = { title: "Play" };

export default function PlayPage() {
  return (
    <Suspense fallback={<div className="skeleton h-96" />}>
      <PlayHub />
    </Suspense>
  );
}
