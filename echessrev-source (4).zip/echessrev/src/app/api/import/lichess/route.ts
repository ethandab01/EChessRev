import { NextResponse } from "next/server";
import { parseLichessGameId } from "@/lib/chess/lichess";
import { clientIp, envInt, rateLimit } from "@/lib/server/rateLimit";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const ip = clientIp(req.headers);
  const rl = rateLimit(`lichess:${ip}`, envInt("RATE_LIMIT_LICHESS", 20), 60_000);
  if (!rl.ok) {
    return NextResponse.json(
      { error: `Too many imports. Try again in ${rl.retryAfterSec}s.` },
      { status: 429, headers: { "Retry-After": String(rl.retryAfterSec) } },
    );
  }
  const url = new URL(req.url).searchParams.get("url") ?? "";
  const id = parseLichessGameId(url);
  if (!id) {
    return NextResponse.json({ error: "That doesn't look like a Lichess game URL (expected https://lichess.org/<gameId>)." }, { status: 400 });
  }
  try {
    const res = await fetch(`https://lichess.org/game/export/${id}?clocks=false&evals=false&literate=false`, {
      headers: { Accept: "application/x-chess-pgn" },
      cache: "no-store",
      signal: AbortSignal.timeout(10_000),
    });
    if (res.status === 404) return NextResponse.json({ error: `Lichess game "${id}" was not found.` }, { status: 404 });
    if (res.status === 429) return NextResponse.json({ error: "Lichess is rate-limiting requests. Wait a minute and try again." }, { status: 429 });
    if (!res.ok) return NextResponse.json({ error: `Lichess returned an error (${res.status}).` }, { status: 502 });
    const pgn = await res.text();
    return NextResponse.json({ id, pgn });
  } catch {
    return NextResponse.json({ error: "Could not reach Lichess. Check your connection and try again." }, { status: 502 });
  }
}
