import { NextResponse } from "next/server";
import { prisma } from "@/lib/server/db";
import { requireUserId } from "@/lib/server/session";
import { pickPuzzle } from "@/lib/server/puzzleDb";

export const dynamic = "force-dynamic";

/** Next puzzle near the player's puzzle rating (guests pass ?rating=). */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const userId = await requireUserId();
  const exclude = new Set((url.searchParams.get("exclude") ?? "").split(",").filter(Boolean).slice(0, 500));
  const theme = url.searchParams.get("theme") || undefined;
  let rating = Math.min(3000, Math.max(400, Number(url.searchParams.get("rating")) || 1200));
  if (userId) {
    const user = await prisma.user.findUnique({ where: { id: userId }, select: { puzzleRating: true } });
    rating = user?.puzzleRating ?? rating;
    const done = await prisma.puzzleAttempt.findMany({ where: { userId }, select: { puzzleId: true }, orderBy: { createdAt: "desc" }, take: 3000 });
    for (const d of done) exclude.add(d.puzzleId);
  }
  const puzzle = pickPuzzle(rating, exclude, theme);
  if (!puzzle) return NextResponse.json({ error: "You've done every puzzle! Impressive." }, { status: 404 });
  return NextResponse.json({ puzzle });
}
