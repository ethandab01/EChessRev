import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/server/db";
import { requireUserId } from "@/lib/server/session";
import { getPuzzle } from "@/lib/server/puzzleDb";
import { puzzlePoints, puzzleRatingUpdate } from "@/lib/chess/puzzles";

const schema = z.object({ puzzleId: z.string().min(1).max(20), solved: z.boolean() });

/** Record the first attempt at a puzzle: updates puzzle rating, streak and points. */
export async function POST(req: Request) {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid attempt" }, { status: 400 });
  const puzzle = getPuzzle(parsed.data.puzzleId);
  if (!puzzle) return NextResponse.json({ error: "Unknown puzzle" }, { status: 404 });

  const user = await prisma.user.findUnique({ where: { id: userId }, select: { puzzleRating: true, puzzleStreak: true } });
  if (!user) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const existing = await prisma.puzzleAttempt.findUnique({ where: { userId_puzzleId: { userId, puzzleId: puzzle.id } } });
  if (existing) {
    return NextResponse.json({ rating: user.puzzleRating, delta: 0, streak: user.puzzleStreak, points: 0, repeat: true });
  }
  const { solved } = parsed.data;
  const ratingAfter = puzzleRatingUpdate(user.puzzleRating, puzzle.rating, solved);
  const points = puzzlePoints(puzzle.rating, solved);
  const streak = solved ? user.puzzleStreak + 1 : 0;
  await prisma.$transaction([
    prisma.puzzleAttempt.create({ data: { userId, puzzleId: puzzle.id, solved, ratingBefore: user.puzzleRating, ratingAfter, points } }),
    prisma.user.update({ where: { id: userId }, data: { puzzleRating: ratingAfter, puzzleStreak: streak } }),
  ]);
  return NextResponse.json({ rating: ratingAfter, delta: ratingAfter - user.puzzleRating, streak, points, repeat: false });
}
