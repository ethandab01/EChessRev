import { NextResponse } from "next/server";
import { requireUserId } from "@/lib/server/session";
import { wallet } from "@/lib/server/wallet";
import { prisma } from "@/lib/server/db";

export const dynamic = "force-dynamic";

export async function GET() {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const [points, pending, user] = await Promise.all([
    wallet(userId),
    prisma.friendship.count({ where: { addresseeId: userId, status: "pending" } }),
    prisma.user.findUnique({ where: { id: userId }, select: { puzzleRating: true, puzzleStreak: true, username: true, friendRating: true, boardTheme: true, avatarIcon: true, flair: true, winEffect: true } }),
  ]);
  const games = await prisma.friendGame.findMany({
    where: { OR: [{ whiteId: userId }, { blackId: userId }], status: { in: ["pending", "active"] } },
    select: { status: true, challengerId: true, whiteId: true, moves: true },
  });
  const challenges = games.filter((g) => g.status === "pending" && g.challengerId !== userId).length;
  const yourTurn = games.filter((g) => {
    if (g.status !== "active") return false;
    const plies = g.moves.split(" ").filter(Boolean).length;
    return (plies % 2 === 0) === (g.whiteId === userId);
  }).length;
  return NextResponse.json({
    points: points.balance,
    earned: points.earned,
    boardTheme: user?.boardTheme ?? "classic",
    avatarIcon: user?.avatarIcon ?? null,
    flair: user?.flair ?? null,
    winEffect: user?.winEffect ?? "confetti",
    pendingFriendRequests: pending, puzzleRating: user?.puzzleRating ?? 1200, puzzleStreak: user?.puzzleStreak ?? 0, username: user?.username ?? null, friendRating: user?.friendRating ?? 1200, challenges,
    yourTurn,
  });
}
