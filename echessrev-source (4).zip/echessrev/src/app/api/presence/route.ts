import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/server/db";
import { requireUserId } from "@/lib/server/session";
import { aliveSince } from "@/lib/server/seeks";

export const dynamic = "force-dynamic";

const ONLINE_WINDOW_MS = 60_000;

async function counts() {
  const since = new Date(Date.now() - ONLINE_WINDOW_MS);
  const [players, games, seeks] = await Promise.all([
    prisma.presence.count({ where: { lastSeen: { gte: since } } }),
    prisma.friendGame.count({ where: { status: "active", updatedAt: { gte: new Date(Date.now() - 30 * 60_000) } } }),
    prisma.seek.count({ where: { gameId: null, lastPing: { gte: aliveSince() } } }),
  ]);
  return { players, games, seeks };
}

export async function GET() {
  return NextResponse.json(await counts());
}

const schema = z.object({ clientId: z.string().regex(/^[a-zA-Z0-9_-]{8,64}$/) });

/** Heartbeat from each open tab (every ~25 s). */
export async function POST(req: Request) {
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid" }, { status: 400 });
  const userId = await requireUserId();
  const now = new Date();
  await prisma.presence.upsert({
    where: { id: parsed.data.clientId },
    create: { id: parsed.data.clientId, userId, lastSeen: now },
    update: { userId, lastSeen: now },
  });
  if (Math.random() < 0.05) await prisma.presence.deleteMany({ where: { lastSeen: { lt: new Date(Date.now() - 10 * 60_000) } } });
  return NextResponse.json(await counts());
}
