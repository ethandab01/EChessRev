import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/server/db";
import { requireUserId } from "@/lib/server/session";
import { getBot, isValidTimeControl } from "@/lib/chess/bots";
import { parsePgn } from "@/lib/chess/pgn";
import { resultPoints } from "@/lib/chess/points";

const schema = z.object({
  pgn: z.string().min(1).max(200_000),
  result: z.enum(["1-0", "0-1", "1/2-1/2"]),
  termination: z.enum([
    "checkmate",
    "resignation",
    "timeout",
    "stalemate",
    "threefold",
    "fifty-move",
    "insufficient",
    "agreement",
    "timeout-insufficient",
  ]),
  userColor: z.enum(["w", "b"]),
  botId: z.string(),
  timeControl: z.string().refine(isValidTimeControl, "Unknown time control"),
});

export async function GET() {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const games = await prisma.game.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
    take: 200,
    select: { id: true, points: true, bonusPoints: true, result: true, outcome: true, termination: true, userColor: true, botName: true, botElo: true, timeControl: true, moveCount: true, createdAt: true, reviewDepth: true },
  });
  return NextResponse.json({ games });
}

export async function POST(req: Request) {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid game" }, { status: 400 });
  const d = parsed.data;
  const bot = getBot(d.botId);
  if (!bot) return NextResponse.json({ error: "Unknown bot" }, { status: 400 });
  let moveCount = 0;
  let startFen: string | null = null;
  try {
    const g = parsePgn(d.pgn);
    moveCount = g.moves.length;
    startFen = g.customStart ? g.startFen : null;
  } catch (e) {
    return NextResponse.json({ error: `Invalid PGN: ${(e as Error).message}` }, { status: 400 });
  }
  const outcome =
    d.result === "1/2-1/2" ? "draw" : (d.result === "1-0") === (d.userColor === "w") ? "win" : "loss";
  const game = await prisma.game.create({
    data: {
      userId,
      pgn: d.pgn,
      startFen,
      result: d.result,
      outcome,
      termination: d.termination,
      userColor: d.userColor,
      botId: bot.id,
      botName: bot.name,
      botElo: bot.elo,
      timeControl: d.timeControl,
      moveCount,
      points: resultPoints(outcome, bot.elo),
    },
    select: { id: true, points: true },
  });
  return NextResponse.json({ id: game.id, points: game.points }, { status: 201 });
}
