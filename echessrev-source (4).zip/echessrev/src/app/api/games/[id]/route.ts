import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/server/db";
import { requireUserId } from "@/lib/server/session";
import { reviewBonus } from "@/lib/chess/points";
import type { Classification } from "@/lib/chess/types";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const { id } = await ctx.params;
  const game = await prisma.game.findFirst({ where: { id, userId } });
  if (!game) return NextResponse.json({ error: "Game not found" }, { status: 404 });
  return NextResponse.json({ game: { ...game, review: game.review ? JSON.parse(game.review) : null } });
}

const reviewSchema = z.object({ review: z.unknown(), depth: z.number().int().min(8).max(30) });

export async function PUT(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const { id } = await ctx.params;
  const parsed = reviewSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid review" }, { status: 400 });
  const json = JSON.stringify(parsed.data.review);
  if (json.length > 4_000_000) return NextResponse.json({ error: "Review too large" }, { status: 413 });
  const game = await prisma.game.findFirst({ where: { id, userId } });
  if (!game) return NextResponse.json({ error: "Game not found" }, { status: 404 });

  // One-time bonus for the user's own Brilliant/Great/Best moves.
  let bonus: ReturnType<typeof reviewBonus> | null = null;
  if (game.bonusPoints === null) {
    const review = parsed.data.review as { counts?: Record<string, Record<string, unknown>> } | null;
    const raw = review?.counts?.[game.userColor] ?? {};
    const maxMoves = Math.ceil(game.moveCount / 2);
    const counts: Partial<Record<Classification, number>> = {};
    for (const c of ["brilliant", "great", "best"] as Classification[]) {
      const n = Number(raw[c]);
      counts[c] = Number.isFinite(n) ? Math.min(maxMoves, Math.max(0, Math.floor(n))) : 0;
    }
    bonus = reviewBonus(counts);
  }
  await prisma.game.update({
    where: { id },
    data: { review: json, reviewDepth: parsed.data.depth, ...(bonus ? { bonusPoints: bonus.total } : {}) },
  });
  return NextResponse.json({ ok: true, bonus });
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const { id } = await ctx.params;
  const res = await prisma.game.deleteMany({ where: { id, userId } });
  if (res.count === 0) return NextResponse.json({ error: "Game not found" }, { status: 404 });
  return NextResponse.json({ ok: true });
}
