import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/server/db";
import { requireUserId } from "@/lib/server/session";
import { getTimeControl, isValidTimeControl, speedOf } from "@/lib/chess/bots";
import { aliveSince, claimSeek, sweepSeeks } from "@/lib/server/seeks";

export const dynamic = "force-dynamic";

/** Lobby: open games waiting for an opponent. */
export async function GET() {
  const userId = await requireUserId();
  await sweepSeeks();
  const seeks = await prisma.seek.findMany({
    where: { gameId: null, lastPing: { gte: aliveSince() } },
    include: { user: { select: { username: true, friendRating: true } } },
    orderBy: { createdAt: "asc" },
    take: 100,
  });
  return NextResponse.json({
    seeks: seeks.map((s) => ({
      id: s.id,
      username: s.user.username,
      rating: s.user.friendRating,
      timeControl: s.timeControl,
      speed: speedOf(getTimeControl(s.timeControl)),
      rated: s.rated,
      mine: s.userId === userId,
    })),
  });
}

const schema = z.object({ timeControl: z.string().refine((t) => isValidTimeControl(t) && t !== "unlimited", "Pick a timed control"), rated: z.boolean().default(true), quick: z.boolean().default(true) });

/**
 * Quick pairing: join a matching open game if there is one, otherwise create a seek and wait.
 * With quick=false, always create a new lobby seek.
 */
export async function POST(req: Request) {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ error: "Sign in to play online." }, { status: 401 });
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid request" }, { status: 400 });
  const { timeControl, rated, quick } = parsed.data;
  await sweepSeeks();
  if (quick) {
    const candidates = await prisma.seek.findMany({
      where: { gameId: null, timeControl, rated, userId: { not: userId }, lastPing: { gte: aliveSince() } },
      orderBy: { createdAt: "asc" },
      take: 5,
    });
    for (const c of candidates) {
      const gameId = await claimSeek(c, userId);
      if (gameId) return NextResponse.json({ gameId });
    }
  }
  await prisma.seek.deleteMany({ where: { userId, gameId: null } });
  const seek = await prisma.seek.create({ data: { userId, timeControl, rated } });
  return NextResponse.json({ seekId: seek.id }, { status: 201 });
}
