import { NextResponse } from "next/server";
import { prisma } from "@/lib/server/db";
import { requireUserId } from "@/lib/server/session";

export const dynamic = "force-dynamic";

/** Owner polls this while waiting: keeps the seek alive and reports the game once matched. */
export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const { id } = await ctx.params;
  const seek = await prisma.seek.findFirst({ where: { id, userId } });
  if (!seek) return NextResponse.json({ error: "Seek not found" }, { status: 404 });
  if (seek.gameId) {
    await prisma.seek.delete({ where: { id } }).catch(() => undefined);
    return NextResponse.json({ gameId: seek.gameId });
  }
  await prisma.seek.update({ where: { id }, data: { lastPing: new Date() } });
  return NextResponse.json({ waiting: true });
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const { id } = await ctx.params;
  const seek = await prisma.seek.findFirst({ where: { id, userId } });
  if (seek?.gameId) return NextResponse.json({ gameId: seek.gameId });
  await prisma.seek.deleteMany({ where: { id, userId, gameId: null } });
  return NextResponse.json({ ok: true });
}
