import { NextResponse } from "next/server";
import { prisma } from "@/lib/server/db";
import { requireUserId } from "@/lib/server/session";
import { aliveSince, claimSeek } from "@/lib/server/seeks";

/** Join a specific lobby game. */
export async function POST(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ error: "Sign in to play online." }, { status: 401 });
  const { id } = await ctx.params;
  const seek = await prisma.seek.findFirst({ where: { id, gameId: null, lastPing: { gte: aliveSince() } } });
  if (!seek) return NextResponse.json({ error: "That game was already taken." }, { status: 409 });
  if (seek.userId === userId) return NextResponse.json({ error: "That's your own game." }, { status: 400 });
  const gameId = await claimSeek(seek, userId);
  if (!gameId) return NextResponse.json({ error: "That game was already taken." }, { status: 409 });
  return NextResponse.json({ gameId });
}
