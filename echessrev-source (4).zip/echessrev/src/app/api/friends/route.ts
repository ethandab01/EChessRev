import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/server/db";
import { requireUserId } from "@/lib/server/session";
import { pointsFor } from "@/lib/server/points";
import { clientIp, rateLimit } from "@/lib/server/rateLimit";

export const dynamic = "force-dynamic";

/** Friends (with points), incoming and outgoing requests. */
export async function GET() {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const rows = await prisma.friendship.findMany({
    where: { OR: [{ requesterId: userId }, { addresseeId: userId }] },
    include: {
      requester: { select: { id: true, username: true, createdAt: true, friendRating: true, avatarIcon: true, flair: true } },
      addressee: { select: { id: true, username: true, createdAt: true, friendRating: true, avatarIcon: true, flair: true } },
    },
    orderBy: { createdAt: "desc" },
  });
  const otherIds = rows.map((r) => (r.requesterId === userId ? r.addresseeId : r.requesterId));
  const pts = await pointsFor([userId, ...otherIds]);
  const shape = (r: (typeof rows)[number]) => {
    const other = r.requesterId === userId ? r.addressee : r.requester;
    return { id: r.id, user: { id: other.id, username: other.username, points: pts.get(other.id) ?? 0, rating: other.friendRating, avatarIcon: other.avatarIcon, flair: other.flair } };
  };
  const meRow = await prisma.user.findUnique({ where: { id: userId }, select: { friendRating: true } });
  return NextResponse.json({
    me: { points: pts.get(userId) ?? 0, rating: meRow?.friendRating ?? 1200 },
    friends: rows.filter((r) => r.status === "accepted").map(shape),
    incoming: rows.filter((r) => r.status === "pending" && r.addresseeId === userId).map(shape),
    outgoing: rows.filter((r) => r.status === "pending" && r.requesterId === userId).map(shape),
  });
}

const schema = z.object({ username: z.string().trim().min(1).max(40) });

/** Send a friend request by username (accepts automatically if they already asked you). */
export async function POST(req: Request) {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  if (!rateLimit(`friend:${userId}:${clientIp(req.headers)}`, 30, 60 * 60_000).ok) {
    return NextResponse.json({ error: "Too many friend requests. Try again later." }, { status: 429 });
  }
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Enter a username." }, { status: 400 });
  const target = await prisma.user.findUnique({ where: { username: parsed.data.username } });
  if (!target) return NextResponse.json({ error: `No player called "${parsed.data.username}".` }, { status: 404 });
  if (target.id === userId) return NextResponse.json({ error: "You can't add yourself." }, { status: 400 });

  const existing = await prisma.friendship.findFirst({
    where: { OR: [{ requesterId: userId, addresseeId: target.id }, { requesterId: target.id, addresseeId: userId }] },
  });
  if (existing?.status === "accepted") return NextResponse.json({ error: `You're already friends with ${target.username}.` }, { status: 409 });
  if (existing && existing.requesterId === userId) return NextResponse.json({ error: "Request already sent." }, { status: 409 });
  if (existing) {
    await prisma.friendship.update({ where: { id: existing.id }, data: { status: "accepted" } });
    return NextResponse.json({ status: "accepted" });
  }
  await prisma.friendship.create({ data: { requesterId: userId, addresseeId: target.id } });
  return NextResponse.json({ status: "pending" }, { status: 201 });
}
