import { NextResponse } from "next/server";
import crypto from "node:crypto";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "@/lib/server/db";
import { clientIp, rateLimit } from "@/lib/server/rateLimit";

const schema = z.object({ token: z.string().regex(/^[a-f0-9]{64}$/), password: z.string().min(8, "Password must be at least 8 characters.").max(200) });

export async function POST(req: Request) {
  if (!rateLimit(`reset:${clientIp(req.headers)}`, 20, 60 * 60_000).ok) {
    return NextResponse.json({ error: "Too many attempts. Try again later." }, { status: 429 });
  }
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid request." }, { status: 400 });
  const tokenHash = crypto.createHash("sha256").update(parsed.data.token).digest("hex");
  const row = await prisma.passwordResetToken.findUnique({ where: { tokenHash } });
  if (!row || row.usedAt || row.expires < new Date()) {
    return NextResponse.json({ error: "This reset link is invalid or has expired. Request a new one." }, { status: 400 });
  }
  const passwordHash = await bcrypt.hash(parsed.data.password, 12);
  await prisma.$transaction([
    prisma.user.update({ where: { id: row.userId }, data: { passwordHash } }),
    prisma.passwordResetToken.update({ where: { id: row.id }, data: { usedAt: new Date() } }),
    prisma.passwordResetToken.deleteMany({ where: { userId: row.userId, id: { not: row.id } } }),
  ]);
  const user = await prisma.user.findUnique({ where: { id: row.userId }, select: { username: true } });
  return NextResponse.json({ ok: true, username: user?.username });
}
