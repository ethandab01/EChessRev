import { NextResponse } from "next/server";
import crypto from "node:crypto";
import { z } from "zod";
import { prisma } from "@/lib/server/db";
import { clientIp, rateLimit } from "@/lib/server/rateLimit";
import { sendEmail, siteUrl } from "@/lib/server/email";

const schema = z.object({ email: z.string().trim().toLowerCase().pipe(z.email()) });

/** Always answers the same way, so it can't be used to discover which emails have accounts. */
export async function POST(req: Request) {
  const ip = clientIp(req.headers);
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Enter a valid email address." }, { status: 400 });
  const { email } = parsed.data;
  if (!rateLimit(`forgot:${ip}`, 10, 60 * 60_000).ok || !rateLimit(`forgot:${email}`, 3, 60 * 60_000).ok) {
    return NextResponse.json({ error: "Too many reset requests. Try again later." }, { status: 429 });
  }
  const user = await prisma.user.findUnique({ where: { email } });
  if (user) {
    const token = crypto.randomBytes(32).toString("hex");
    const tokenHash = crypto.createHash("sha256").update(token).digest("hex");
    await prisma.passwordResetToken.deleteMany({ where: { userId: user.id } });
    await prisma.passwordResetToken.create({ data: { userId: user.id, tokenHash, expires: new Date(Date.now() + 60 * 60_000) } });
    const link = `${siteUrl(req)}/reset-password?token=${token}`;
    const name = user.username ?? "there";
    try {
      await sendEmail({
        to: email,
        subject: "Reset your EChessREV password",
        text: `Hi ${name},\n\nSomeone asked to reset your EChessREV password. Open this link within an hour to choose a new one:\n\n${link}\n\nIf this wasn't you, ignore this email — your password won't change.`,
        html: `<div style="font-family:system-ui,sans-serif;max-width:480px;margin:auto;padding:24px"><h2 style="margin:0 0 12px">Reset your password</h2><p>Hi ${name},</p><p>Someone asked to reset your EChessREV password. This link works for one hour:</p><p><a href="${link}" style="display:inline-block;background:#4fae5c;color:#fff;padding:12px 20px;border-radius:8px;text-decoration:none;font-weight:700">Choose a new password</a></p><p style="color:#666;font-size:13px">If this wasn't you, ignore this email — your password won't change.</p></div>`,
      });
    } catch {
      return NextResponse.json({ error: "We couldn't send the email right now. Try again in a few minutes." }, { status: 502 });
    }
  }
  return NextResponse.json({ ok: true });
}
