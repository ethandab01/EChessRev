import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "@/lib/server/db";
import { clientIp, rateLimit } from "@/lib/server/rateLimit";

const schema = z.object({
  email: z.string().trim().toLowerCase().pipe(z.email({ error: "Enter a valid email address." })),
  username: z
    .string()
    .trim()
    .regex(/^[a-zA-Z0-9_-]{3,20}$/, "Username must be 3–20 characters: letters, numbers, _ or -."),
  password: z.string().min(8, "Password must be at least 8 characters.").max(200),
});

export async function POST(req: Request) {
  const ip = clientIp(req.headers);
  const rl = rateLimit(`register:${ip}`, 10, 60 * 60_000);
  if (!rl.ok) {
    return NextResponse.json({ error: `Too many sign-ups from this address. Try again in ${rl.retryAfterSec}s.` }, { status: 429 });
  }
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid input." }, { status: 400 });
  }
  const { email, username, password } = parsed.data;
  const existing = await prisma.user.findFirst({ where: { OR: [{ email }, { username }] } });
  if (existing) {
    return NextResponse.json(
      { error: existing.email === email ? "An account with that email already exists." : "That username is taken." },
      { status: 409 },
    );
  }
  const passwordHash = await bcrypt.hash(password, 12);
  await prisma.user.create({ data: { email, username, name: username, passwordHash } });
  return NextResponse.json({ ok: true }, { status: 201 });
}
