import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/server/db";
import { requireUserId } from "@/lib/server/session";
import { EQUIP_FIELD, SHOP_BY_ID } from "@/lib/shop";

const schema = z.object({ category: z.enum(["board", "avatar", "flair", "effect"]), itemId: z.string().max(40).nullable() });

export async function POST(req: Request) {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ error: "Sign in to use the shop." }, { status: 401 });
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  const { category, itemId } = parsed.data;
  let value: string | null;
  if (itemId === null) {
    if (category === "board") value = "classic";
    else if (category === "effect") value = "confetti";
    else value = null;
  } else {
    const item = SHOP_BY_ID.get(itemId);
    if (!item || item.category !== category) return NextResponse.json({ error: "Unknown item." }, { status: 404 });
    if (item.price > 0) {
      const owned = await prisma.purchase.findUnique({ where: { userId_itemId: { userId, itemId } } });
      if (!owned) return NextResponse.json({ error: "Buy it first." }, { status: 403 });
    }
    value = itemId === "board-classic" ? "classic" : itemId === "effect-confetti" ? "confetti" : itemId;
  }
  await prisma.user.update({ where: { id: userId }, data: { [EQUIP_FIELD[category]]: value } });
  return NextResponse.json({ ok: true });
}
