import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/server/db";
import { requireUserId } from "@/lib/server/session";
import { wallet } from "@/lib/server/wallet";
import { SHOP_BY_ID } from "@/lib/shop";

export async function POST(req: Request) {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ error: "Sign in to use the shop." }, { status: 401 });
  const parsed = z.object({ itemId: z.string().max(40) }).safeParse(await req.json().catch(() => null));
  const item = parsed.success ? SHOP_BY_ID.get(parsed.data.itemId) : undefined;
  if (!item) return NextResponse.json({ error: "Unknown item." }, { status: 404 });
  if (item.price === 0) return NextResponse.json({ error: "That item is free — just equip it." }, { status: 400 });
  const exists = await prisma.purchase.findUnique({ where: { userId_itemId: { userId, itemId: item.id } } });
  if (exists) return NextResponse.json({ error: "You already own this." }, { status: 409 });
  const w = await wallet(userId);
  if (w.balance < item.price) return NextResponse.json({ error: `You need ${item.price - w.balance} more ◆.` }, { status: 402 });
  try {
    await prisma.purchase.create({ data: { userId, itemId: item.id, price: item.price } });
  } catch {
    return NextResponse.json({ error: "You already own this." }, { status: 409 });
  }
  return NextResponse.json({ ok: true, balance: w.balance - item.price });
}
