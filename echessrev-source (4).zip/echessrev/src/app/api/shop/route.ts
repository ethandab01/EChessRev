import { NextResponse } from "next/server";
import { prisma } from "@/lib/server/db";
import { requireUserId } from "@/lib/server/session";
import { wallet } from "@/lib/server/wallet";
import { SHOP_ITEMS } from "@/lib/shop";

export const dynamic = "force-dynamic";

export async function GET() {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ items: SHOP_ITEMS, owned: [], equipped: {}, balance: 0, signedIn: false });
  const [w, purchases, user] = await Promise.all([
    wallet(userId),
    prisma.purchase.findMany({ where: { userId }, select: { itemId: true } }),
    prisma.user.findUnique({ where: { id: userId }, select: { boardTheme: true, avatarIcon: true, flair: true, winEffect: true } }),
  ]);
  const owned = [...SHOP_ITEMS.filter((i) => i.price === 0).map((i) => i.id), ...purchases.map((p) => p.itemId)];
  return NextResponse.json({
    items: SHOP_ITEMS,
    owned,
    equipped: {
      board: user?.boardTheme === "classic" ? "board-classic" : user?.boardTheme,
      avatar: user?.avatarIcon ?? null,
      flair: user?.flair ?? null,
      effect: user?.winEffect === "confetti" ? "effect-confetti" : user?.winEffect,
    },
    ...w,
    signedIn: true,
  });
}
