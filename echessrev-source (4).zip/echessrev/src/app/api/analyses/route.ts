import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/server/db";
import { requireUserId } from "@/lib/server/session";
import { parsePgn } from "@/lib/chess/pgn";

const schema = z.object({
  title: z.string().trim().min(1).max(200),
  pgn: z.string().min(1).max(200_000),
  review: z.unknown(),
  depth: z.number().int().min(8).max(30),
});

export async function GET() {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const analyses = await prisma.analysis.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
    take: 200,
    select: { id: true, title: true, depth: true, createdAt: true },
  });
  return NextResponse.json({ analyses });
}

export async function POST(req: Request) {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid analysis" }, { status: 400 });
  try {
    parsePgn(parsed.data.pgn);
  } catch (e) {
    return NextResponse.json({ error: `Invalid PGN: ${(e as Error).message}` }, { status: 400 });
  }
  const review = JSON.stringify(parsed.data.review);
  if (review.length > 4_000_000) return NextResponse.json({ error: "Review too large" }, { status: 413 });
  const a = await prisma.analysis.create({
    data: { userId, title: parsed.data.title, pgn: parsed.data.pgn, review, depth: parsed.data.depth },
    select: { id: true },
  });
  return NextResponse.json({ id: a.id }, { status: 201 });
}
