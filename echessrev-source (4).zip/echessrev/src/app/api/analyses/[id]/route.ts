import { NextResponse } from "next/server";
import { prisma } from "@/lib/server/db";
import { requireUserId } from "@/lib/server/session";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const { id } = await ctx.params;
  const a = await prisma.analysis.findFirst({ where: { id, userId } });
  if (!a) return NextResponse.json({ error: "Analysis not found" }, { status: 404 });
  return NextResponse.json({ analysis: { ...a, review: JSON.parse(a.review) } });
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const { id } = await ctx.params;
  const res = await prisma.analysis.deleteMany({ where: { id, userId } });
  if (res.count === 0) return NextResponse.json({ error: "Analysis not found" }, { status: 404 });
  return NextResponse.json({ ok: true });
}
