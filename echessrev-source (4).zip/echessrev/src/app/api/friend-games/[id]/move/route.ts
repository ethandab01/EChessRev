import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUserId } from "@/lib/server/session";
import { loadGame, playMove, serialize } from "@/lib/server/friendGames";

const schema = z.object({ uci: z.string().regex(/^[a-h][1-8][a-h][1-8][qrbn]?$/), ply: z.number().int().min(0) });

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const { id } = await ctx.params;
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid move" }, { status: 400 });
  const g = await loadGame(id);
  if (!g) return NextResponse.json({ error: "Game not found" }, { status: 404 });
  const r = await playMove(g, userId, parsed.data.uci, parsed.data.ply);
  const fresh = await loadGame(id);
  if (r.error) return NextResponse.json({ error: r.error, game: fresh ? serialize(fresh, userId) : null }, { status: r.status ?? 400 });
  return NextResponse.json({ game: fresh ? serialize(fresh, userId) : null });
}
