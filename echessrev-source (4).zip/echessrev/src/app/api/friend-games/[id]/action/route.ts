import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/server/db";
import { requireUserId } from "@/lib/server/session";
import { getTimeControl } from "@/lib/chess/bots";
import { finishGame, liveClocks, loadGame, serialize } from "@/lib/server/friendGames";

const schema = z.object({ action: z.enum(["accept", "decline", "cancel", "resign", "offer-draw", "accept-draw", "decline-draw", "abort"]) });

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const { id } = await ctx.params;
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  const g = await loadGame(id);
  if (!g || (g.whiteId !== userId && g.blackId !== userId)) return NextResponse.json({ error: "Game not found" }, { status: 404 });
  const color = g.whiteId === userId ? "w" : "b";
  const plies = g.moves.split(" ").filter(Boolean).length;
  const fail = (msg: string) => NextResponse.json({ error: msg, game: serialize(g, userId) }, { status: 409 });

  switch (parsed.data.action) {
    case "accept": {
      if (g.status !== "pending" || g.challengerId === userId) return fail("This challenge can't be accepted.");
      const tc = getTimeControl(g.timeControl);
      const ms = tc.id === "unlimited" ? null : tc.initial * 1000;
      await prisma.friendGame.updateMany({ where: { id, status: "pending" }, data: { status: "active", whiteMs: ms, blackMs: ms, lastMoveAt: null } });
      break;
    }
    case "decline":
    case "cancel":
      if (g.status !== "pending") return fail("This challenge is no longer open.");
      await prisma.friendGame.updateMany({ where: { id, status: "pending" }, data: { status: parsed.data.action === "decline" ? "declined" : "cancelled" } });
      break;
    case "abort":
      if (g.status !== "active" || plies >= 2) return fail("Games can only be aborted before both players have moved.");
      await prisma.friendGame.updateMany({ where: { id, status: "active" }, data: { status: "cancelled", termination: "aborted" } });
      break;
    case "resign":
      if (g.status !== "active") return fail("This game is over.");
      await finishGame(g, { result: color === "w" ? "0-1" : "1-0", termination: "resignation" }, liveClocks(g));
      break;
    case "offer-draw":
      if (g.status !== "active") return fail("This game is over.");
      await prisma.friendGame.update({ where: { id }, data: { drawOfferBy: userId } });
      break;
    case "accept-draw":
      if (g.status !== "active" || !g.drawOfferBy || g.drawOfferBy === userId) return fail("There's no draw offer to accept.");
      await finishGame(g, { result: "1/2-1/2", termination: "agreement" }, liveClocks(g));
      break;
    case "decline-draw":
      if (g.status === "active" && g.drawOfferBy && g.drawOfferBy !== userId) await prisma.friendGame.update({ where: { id }, data: { drawOfferBy: null } });
      break;
  }
  const fresh = await loadGame(id);
  return NextResponse.json({ game: fresh ? serialize(fresh, userId) : null });
}
