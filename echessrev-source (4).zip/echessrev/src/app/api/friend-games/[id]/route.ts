import { NextResponse } from "next/server";
import { requireUserId } from "@/lib/server/session";
import { loadGame, serialize } from "@/lib/server/friendGames";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const { id } = await ctx.params;
  const g = await loadGame(id);
  if (!g || (g.whiteId !== userId && g.blackId !== userId)) return NextResponse.json({ error: "Game not found" }, { status: 404 });
  return NextResponse.json({ game: serialize(g, userId) });
}
