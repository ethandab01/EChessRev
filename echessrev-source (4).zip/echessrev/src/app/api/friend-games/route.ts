import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/server/db";
import { requireUserId } from "@/lib/server/session";
import { isValidTimeControl } from "@/lib/chess/bots";
import { replay } from "@/lib/server/friendGames";

export const dynamic = "force-dynamic";

const userSel = { select: { id: true, username: true, friendRating: true } } as const;

/** My challenges, active games and recent finished games against friends. */
export async function GET() {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const games = await prisma.friendGame.findMany({
    where: { OR: [{ whiteId: userId }, { blackId: userId }], status: { in: ["pending", "active", "finished"] } },
    include: { white: userSel, black: userSel },
    orderBy: { updatedAt: "desc" },
    take: 60,
  });
  const me = await prisma.user.findUnique({ where: { id: userId }, select: { friendRating: true } });
  const shape = (g: (typeof games)[number]) => {
    const color = g.whiteId === userId ? "w" : "b";
    const opp = color === "w" ? g.black : g.white;
    const turn = replay(g.moves).turn();
    return {
      id: g.id,
      status: g.status,
      timeControl: g.timeControl,
      rated: g.rated,
      color,
      opponent: { id: opp.id, username: opp.username, rating: opp.friendRating },
      yourTurn: g.status === "active" && turn === color,
      incoming: g.status === "pending" && g.challengerId !== userId,
      result: g.result,
      termination: g.termination,
      delta: color === "w" ? g.whiteDelta : g.blackDelta,
      plies: g.moves.split(" ").filter(Boolean).length,
      updatedAt: g.updatedAt.toISOString(),
    };
  };
  const all = games.map(shape);
  return NextResponse.json({
    rating: me?.friendRating ?? 1200,
    incoming: all.filter((g) => g.status === "pending" && g.incoming),
    outgoing: all.filter((g) => g.status === "pending" && !g.incoming),
    active: all.filter((g) => g.status === "active"),
    finished: all.filter((g) => g.status === "finished").slice(0, 20),
  });
}

const schema = z.object({
  username: z.string().trim().min(1).max(40),
  timeControl: z.string().refine(isValidTimeControl, "Unknown time control"),
  color: z.enum(["w", "b", "random"]),
  rated: z.boolean().default(true),
});

/** Challenge a friend. */
export async function POST(req: Request) {
  const userId = await requireUserId();
  if (!userId) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid challenge" }, { status: 400 });
  const friend = await prisma.user.findUnique({ where: { username: parsed.data.username } });
  if (!friend || friend.id === userId) return NextResponse.json({ error: "Player not found." }, { status: 404 });
  const friendship = await prisma.friendship.findFirst({
    where: { status: "accepted", OR: [{ requesterId: userId, addresseeId: friend.id }, { requesterId: friend.id, addresseeId: userId }] },
  });
  if (!friendship) return NextResponse.json({ error: "You can only challenge friends." }, { status: 403 });
  const open = await prisma.friendGame.count({
    where: { status: "pending", challengerId: userId, OR: [{ whiteId: friend.id }, { blackId: friend.id }] },
  });
  if (open > 0) return NextResponse.json({ error: `You already have a challenge waiting for ${friend.username}.` }, { status: 409 });
  const iAmWhite = parsed.data.color === "random" ? Math.random() < 0.5 : parsed.data.color === "w";
  const game = await prisma.friendGame.create({
    data: {
      whiteId: iAmWhite ? userId : friend.id,
      blackId: iAmWhite ? friend.id : userId,
      challengerId: userId,
      timeControl: parsed.data.timeControl,
      rated: parsed.data.rated,
    },
    select: { id: true },
  });
  return NextResponse.json({ id: game.id }, { status: 201 });
}
