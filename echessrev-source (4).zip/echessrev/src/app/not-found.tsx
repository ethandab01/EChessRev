import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto mt-16 max-w-md text-center">
      <h1 className="text-3xl font-bold">Page not found</h1>
      <p className="mt-2 text-muted">That square is empty.</p>
      <Link href="/" className="btn-primary mt-6">Back home</Link>
    </div>
  );
}
