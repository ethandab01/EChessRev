// Copies the single-threaded "lite" Stockfish WASM build from node_modules into
// public/engine so it can be loaded as a Web Worker without COOP/COEP headers.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const src = path.join(root, "node_modules", "stockfish", "src");
const dest = path.join(root, "public", "engine");

if (!fs.existsSync(src)) {
  console.warn("[copy-engine] node_modules/stockfish not found; skipping");
  process.exit(0);
}
const files = fs.readdirSync(src);
const js = files.find((f) => /^stockfish-.*-lite-single-[0-9a-f]+\.js$/.test(f));
const wasm = files.find((f) => /^stockfish-.*-lite-single-[0-9a-f]+\.wasm$/.test(f));
if (!js || !wasm) {
  console.error("[copy-engine] could not find lite-single build in", src);
  process.exit(1);
}
fs.mkdirSync(dest, { recursive: true });
fs.copyFileSync(path.join(src, js), path.join(dest, "stockfish.js"));
fs.copyFileSync(path.join(src, wasm), path.join(dest, "stockfish.wasm"));
console.log(`[copy-engine] ${js} -> public/engine/stockfish.js (+ .wasm)`);
