// Builds src/data/puzzles.json from a Lichess puzzle CSV (the Lichess puzzle database is CC0:
// https://database.lichess.org/#puzzles). Usage: node scripts/build-puzzles.mjs path/to/puzzles.csv
// Columns: PuzzleId,FEN,Moves,Rating,RatingDeviation,Popularity,NbPlays,Themes,GameUrl,OpeningTags
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { Chess } from "chess.js";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const file = process.argv[2];
if (!file) {
  console.error("Usage: node scripts/build-puzzles.mjs <lichess_db_puzzle.csv>");
  process.exit(1);
}
const lines = fs.readFileSync(file, "utf8").split(/\r?\n/).slice(1).filter(Boolean);
const out = [];
let skipped = 0;
for (const line of lines) {
  const [id, fen, moves, rating, , popularity, nbPlays, themes] = line.split(",");
  if (Number(popularity) < 60 || Number(nbPlays) < 100) {
    skipped++;
    continue;
  }
  try {
    const c = new Chess(fen);
    for (const u of moves.split(" ")) c.move({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] });
  } catch {
    skipped++;
    continue;
  }
  out.push([id, fen, moves, Number(rating), themes]);
}
out.sort((a, b) => a[3] - b[3]);
fs.writeFileSync(path.join(root, "src", "data", "puzzles.json"), JSON.stringify(out));
console.log(`[build-puzzles] wrote ${out.length} puzzles (skipped ${skipped})`);
