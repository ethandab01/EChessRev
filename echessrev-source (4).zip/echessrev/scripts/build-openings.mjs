// Builds src/data/openings.json from the public-domain lichess-org/chess-openings
// dataset (CC0). Each entry is keyed by EPD (FEN without move counters) so
// transpositions are recognised.  Run: npm run openings:build
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { Chess } from "chess.js";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const BASE = "https://raw.githubusercontent.com/lichess-org/chess-openings/master/";

function epd(fen) {
  return fen.split(" ").slice(0, 4).join(" ");
}

const out = {};
for (const letter of ["a", "b", "c", "d", "e"]) {
  const res = await fetch(`${BASE}${letter}.tsv`);
  if (!res.ok) throw new Error(`Failed to fetch ${letter}.tsv: ${res.status}`);
  const lines = (await res.text()).split("\n").slice(1).filter(Boolean);
  for (const line of lines) {
    const [eco, name, pgn] = line.split("\t");
    const chess = new Chess();
    chess.loadPgn(pgn);
    const key = epd(chess.fen());
    // Keep the shortest (most general) line name for a given position.
    if (!out[key] || out[key].plies > chess.history().length) {
      out[key] = { eco, name, plies: chess.history().length };
    }
  }
}
const compact = Object.fromEntries(Object.entries(out).map(([k, v]) => [k, [v.eco, v.name]]));
fs.mkdirSync(path.join(root, "src", "data"), { recursive: true });
fs.writeFileSync(path.join(root, "src", "data", "openings.json"), JSON.stringify(compact));
console.log(`[build-openings] wrote ${Object.keys(compact).length} positions`);
